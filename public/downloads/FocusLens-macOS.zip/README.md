# FocusLens 🔭

**Local-only macOS productivity tracker.** No data ever leaves your machine.

FocusLens monitors how you use your Mac, stores everything in a local SQLite
database, and tells you plainly what is wrong with your productivity and how
to fix it.

---

## System Requirements

| Requirement | Minimum |
|---|---|
| macOS | 12 Monterey or later |
| Python | 3.9+ (3.11+ recommended) |
| Chip | Intel x86_64 or Apple Silicon (arm64) |

---

## Required macOS Permissions

You **must** grant these before running FocusLens:

| Permission | Why it's needed | Where to grant |
|---|---|---|
| **Accessibility** | Read active app name and window title | System Settings → Privacy & Security → Accessibility |
| **Automation** | AppleScript → browser tab domain (Safari/Chrome/Arc/Brave) | System Settings → Privacy & Security → Automation |

> **Note:** FocusLens will detect missing permissions and print clear instructions
> instead of crashing. Browser domain tracking degrades gracefully to `NULL` if
> Automation is not granted.

---

## Quick Start

```bash
# 1. Clone / copy the project
cd focuslens

# 2. Bootstrap the environment (one-time)
chmod +x setup.sh && ./setup.sh

# 3. Activate the virtual environment
source .venv/bin/activate

# 4. Grant permissions (see above), then start the collector
python -m focuslens.collector

# 5. Press Ctrl-C to stop
```

The live display looks like:
```
▶  Tracking started (session 1)
   DB: ~/Library/Application Support/FocusLens/focuslens.db
   Press Ctrl-C to stop

⏱  00:02:47  |  samples: 56  |  stats: 5
```

---

## Project Structure

```
focuslens/
├── setup.sh                       # One-shot environment bootstrap
├── requirements.txt
├── config/
│   ├── blocklist.yaml             # Apps/titles that are NEVER stored
│   └── categories.yaml            # App/domain → Productive/Neutral/Distracting
├── focuslens/
│   ├── collector/
│   │   ├── __init__.py            # CLI entry point
│   │   ├── __main__.py            # `python -m focuslens.collector`
│   │   ├── permissions.py         # macOS permission detection
│   │   ├── sampler.py             # 3-second sample loop
│   │   ├── browser.py             # AppleScript domain extractor
│   │   ├── system_stats.py        # 30-second CPU/RAM/battery/thermal loop
│   │   └── session.py             # Session lifecycle
│   ├── db/
│   │   ├── store.py               # Thread-safe SQLite wrapper
│   │   └── schema.sql             # Table definitions
│   ├── metrics/                   # Phase 2 – metrics engine
│   ├── dashboard/                 # Phase 3 – Streamlit UI
│   ├── insights/                  # Phase 4 – rule-based diagnosis
│   └── menubar/                   # Phase 3 – rumps menu bar
└── tests/
    ├── test_db.py
    ├── test_sampler.py
    ├── test_browser.py
    └── test_session.py
```

---

## Data Collected

### Every 3 seconds (`samples` table)

| Column | Description | Privacy |
|---|---|---|
| `ts` | Unix timestamp | — |
| `active_app` | Frontmost app name (e.g. "Safari") | App name only |
| `window_title` | Front window title | `<blocked>` if on blocklist |
| `browser_domain` | Active tab domain (e.g. "github.com") | Domain only, never full URL |
| `idle_seconds` | Seconds since last key/mouse event | Count only |
| `screen_locked` | 0 = unlocked, 1 = locked | — |
| `kb_events` | Keyboard event count **delta** | Count only, never content |
| `mouse_events` | Mouse event count **delta** | Count only |

### Every 30 seconds (`system_stats` table)

| Column | Description |
|---|---|
| `cpu_pct` | CPU utilisation % |
| `ram_pct` | RAM utilisation % |
| `battery_pct` | Battery % (or NULL if plugged in without battery) |
| `thermal_state` | nominal / fair / serious / critical |

---

## Privacy Guarantees

- ✅ **Keystroke content is never recorded** – only event counts
- ✅ **Full URLs are never stored** – domain only
- ✅ **Blocklist** – configure apps/title patterns whose data is stored as `<blocked>`
- ✅ **No network calls** – Phases 1–4 are fully local
- ✅ **Delete all data** – `store.delete_all_data()` wipes every row

---

## Configuration

### `config/blocklist.yaml`

Patterns matched **case-insensitively**. Supports both exact app names and
regex patterns for window titles.

```yaml
blocked_apps:
  - "1Password"
  - "Keychain Access"

blocked_title_patterns:
  - ".*password.*"
  - ".*private.*"
```

### `config/categories.yaml`

Maps app names and browser domains to `productive`, `neutral`, or `distracting`.
Used in Phase 2 for the metrics engine.

```yaml
apps:
  "Visual Studio Code": productive
  "YouTube": distracting

domains:
  "github.com": productive
  "reddit.com": distracting

default: neutral
```

---

## Running Tests

```bash
source .venv/bin/activate
pytest tests/ -v
```

Tests are pure Python – no macOS APIs are called (all system calls are mocked).

---

## CLI Options

```
python -m focuslens.collector --help

optional arguments:
  --debug          Verbose logging
  --db PATH        Path to SQLite DB (default: ~/Library/Application Support/FocusLens/focuslens.db)
  --interval N     Override the sample interval in seconds (default: 3)
```

---

## Database Location

```
~/Library/Application Support/FocusLens/focuslens.db
```

Inspect it directly:
```bash
sqlite3 ~/Library/Application\ Support/FocusLens/focuslens.db \
  "SELECT datetime(ts,'unixepoch','localtime'), active_app, window_title FROM samples ORDER BY ts DESC LIMIT 20;"
```

---

---

## Running the Application

FocusLens offers three distinct ways to use your tracker:

### 1. Menu Bar App (Recommended)
Runs in your macOS menu bar with a live timer ticker, pause/resume, start/stop, and one-click dashboard launch:
```bash
./run_menubar.sh
# Or: python -m focuslens.menubar
```

### 2. Streamlit Dashboard
Interactive analytics dashboard showing daily timelines, hourly scores, deep-work blocks, top distracting sites, 7-day trends, rule-based diagnostic cards, and AI coaching:
```bash
./run_dashboard.sh
# Or: python -m focuslens.dashboard
# Opens in browser at http://localhost:8501
```

### 3. Command-Line Collector & AI CLI
Headless terminal tracker with real-time status and instant stop summary:
```bash
python -m focuslens.collector
```

Generate an on-demand AI executive report directly from the terminal:
```bash
python -m focuslens.ai --provider auto
# Providers: auto (Ollama -> Claude -> Offline), ollama, claude, offline
```

---

## Roadmap

| Phase | Status | Description |
|---|---|---|
| **1 – Collector** | ✅ Complete | 3-second sampler, permissions, blocklist, SQLite WAL |
| **2 – Metrics** | ✅ Complete | Focus score, deep-work blocks, context switches, break detection |
| **3 – Dashboard & Menu Bar** | ✅ Complete | Streamlit UI + Plotly charts + rumps macOS menu bar app |
| **4 – Insights Engine** | ✅ Complete | 12 rule-based diagnoses ("what went wrong today") + fixes |
| **5 – AI Report** | ✅ Complete | Privacy-first AI Coach via local Ollama, Claude, or built-in offline synthesizer |

---

## Privacy Architecture

FocusLens is designed strictly for local-first personal use:
- **No telemetry/network requests** in phases 1–4.
- **Window titles and URLs are NEVER passed to AI models** in Phase 5 — only aggregated bucket totals, app names (post-blocklist), and domain roots.
- **Blocklist** ensures sensitive apps and windows matching configured regexes are completely filtered out before database insertion.
- **One-click complete purge**: "Delete All My Data" in both menu bar and dashboard safely truncates all local tables.

---

## Running Tests

```bash
source .venv/bin/activate
pytest tests/ -v
```

All 204 unit and integration tests run in ~1.2s without requiring active macOS permissions or network access.
