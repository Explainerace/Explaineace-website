"""
scripts/make_icon.py
~~~~~~~~~~~~~~~~~~~~
Generates a modern, high-resolution macOS application icon for FocusLens:
`resources/FocusLens.icns` using Pillow and macOS `iconutil`.
"""

import os
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).parents[1]
RES_DIR = ROOT / "resources"
RES_DIR.mkdir(exist_ok=True)
ICONSET = RES_DIR / "FocusLens.iconset"
ICONSET.mkdir(exist_ok=True)


def draw_master_icon(size: int = 1024) -> Image.Image:
    # High-res canvas with transparent background
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Rounded squircle base (macOS app icon style)
    margin = int(size * 0.08)
    radius = int(size * 0.22)
    box = [margin, margin, size - margin, size - margin]

    # Draw rounded background with rich gradient
    # Top: deep midnight blue (#0f172a) -> Bottom: indigo purple (#312e81)
    base_rect = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    rect_draw = ImageDraw.Draw(base_rect)
    rect_draw.rounded_rectangle(box, radius=radius, fill=(15, 23, 42, 255))

    # Add gradient overlay
    for y in range(margin, size - margin):
        ratio = (y - margin) / (size - 2 * margin)
        r = int(15 + ratio * (49 - 15))
        g = int(23 + ratio * (46 - 23))
        b = int(42 + ratio * (129 - 42))
        rect_draw.line([(margin, y), (size - margin, y)], fill=(r, g, b, 255))

    # Apply squircle mask
    mask = Image.new("L", (size, size), 0)
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.rounded_rectangle(box, radius=radius, fill=255)

    img.paste(base_rect, (0, 0), mask)
    draw = ImageDraw.Draw(img)

    # Concentric Focus Rings (FocusLens aperture / reticle)
    center = (size // 2, size // 2)
    r1 = int(size * 0.28)
    r2 = int(size * 0.20)
    r3 = int(size * 0.12)

    # Outer neon cyan ring
    draw.ellipse(
        [center[0] - r1, center[1] - r1, center[0] + r1, center[1] + r1],
        outline=(56, 189, 248, 180),
        width=int(size * 0.02),
    )

    # Middle green focus ring (productive green)
    draw.ellipse(
        [center[0] - r2, center[1] - r2, center[0] + r2, center[1] + r2],
        outline=(34, 197, 94, 230),
        width=int(size * 0.025),
    )

    # Inner glowing core
    draw.ellipse(
        [center[0] - r3, center[1] - r3, center[0] + r3, center[1] + r3],
        fill=(99, 102, 241, 220),
        outline=(255, 255, 255, 240),
        width=int(size * 0.015),
    )

    # Central lens pupil
    r_core = int(size * 0.05)
    draw.ellipse(
        [center[0] - r_core, center[1] - r_core, center[0] + r_core, center[1] + r_core],
        fill=(255, 255, 255, 255),
    )

    # Tick marks / crosshair indicators (subtle technical precision feel)
    tick_len = int(size * 0.04)
    w = int(size * 0.012)
    # Top
    draw.line([(center[0], center[1] - r1 - tick_len), (center[0], center[1] - r1 + tick_len)], fill=(56, 189, 248, 240), width=w)
    # Bottom
    draw.line([(center[0], center[1] + r1 - tick_len), (center[0], center[1] + r1 + tick_len)], fill=(56, 189, 248, 240), width=w)
    # Left
    draw.line([(center[0] - r1 - tick_len, center[1]), (center[0] - r1 + tick_len, center[1])], fill=(56, 189, 248, 240), width=w)
    # Right
    draw.line([(center[0] + r1 - tick_len, center[1]), (center[0] + r1 + tick_len, center[1])], fill=(56, 189, 248, 240), width=w)

    return img


def build_icns():
    master = draw_master_icon(1024)
    master_png = RES_DIR / "icon_1024x1024.png"
    master.save(master_png)

    # Standard macOS icon sizes
    sizes = [
        (16, "icon_16x16.png"),
        (32, "icon_16x16@2x.png"),
        (32, "icon_32x32.png"),
        (64, "icon_32x32@2x.png"),
        (128, "icon_128x128.png"),
        (256, "icon_128x128@2x.png"),
        (256, "icon_256x256.png"),
        (512, "icon_256x256@2x.png"),
        (512, "icon_512x512.png"),
        (1024, "icon_512x512@2x.png"),
    ]

    for px, filename in sizes:
        resized = master.resize((px, px), Image.Resampling.LANCZOS)
        resized.save(ICONSET / filename)

    # Compile with iconutil
    icns_path = RES_DIR / "FocusLens.icns"
    subprocess.run(["iconutil", "-c", "icns", str(ICONSET), "-o", str(icns_path)], check=True)
    print(f"✅ Generated macOS icon at {icns_path}")


if __name__ == "__main__":
    build_icns()
