#!/usr/bin/env bash
# Build FocusLens.app bundle
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
DIST_DIR="$PROJECT_ROOT/dist"
APP_BUNDLE="$DIST_DIR/FocusLens.app"
CONTENTS="$APP_BUNDLE/Contents"
MACOS_DIR="$CONTENTS/MacOS"
RESOURCES_DIR="$CONTENTS/Resources"

echo "🔨 Building FocusLens.app..."

# 1. Clean previous build
rm -rf "$APP_BUNDLE"
mkdir -p "$MACOS_DIR" "$RESOURCES_DIR"

# 2. Generate Icon if missing
if [ ! -f "$PROJECT_ROOT/resources/FocusLens.icns" ]; then
    echo "🎨 Generating app icon..."
    "$PROJECT_ROOT/.venv/bin/python" "$PROJECT_ROOT/scripts/make_icon.py"
fi

cp "$PROJECT_ROOT/resources/FocusLens.icns" "$RESOURCES_DIR/FocusLens.icns"

# 3. Create Info.plist
cat <<EOF > "$CONTENTS/Info.plist"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>
    <string>FocusLens</string>
    <key>CFBundleDisplayName</key>
    <string>FocusLens</string>
    <key>CFBundleIdentifier</key>
    <string>com.focuslens.tracker</string>
    <key>CFBundleVersion</key>
    <string>1.0.0</string>
    <key>CFBundleShortVersionString</key>
    <string>1.0.0</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleSignature</key>
    <string>????</string>
    <key>CFBundleExecutable</key>
    <string>FocusLens</string>
    <key>CFBundleIconFile</key>
    <string>FocusLens</string>
    <key>NSHighResolutionCapable</key>
    <true/>
    <key>NSSupportsAutomaticGraphicsSwitching</key>
    <true/>
    <key>LSMinimumSystemVersion</key>
    <string>12.0</string>
    <key>NSAppleEventsUsageDescription</key>
    <string>FocusLens requests permission to detect browser domains via AppleScript for productivity tracking.</string>
</dict>
</plist>
EOF

# 4. Create PkgInfo
echo -n "APPL????" > "$CONTENTS/PkgInfo"

# 5. Create Executable Launcher
cat <<EOF > "$MACOS_DIR/FocusLens"
#!/usr/bin/env bash
# FocusLens macOS application launcher
PROJECT_ROOT="$PROJECT_ROOT"
VENV="\$PROJECT_ROOT/.venv"

export PATH="\$VENV/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export PYTHONPATH="\$PROJECT_ROOT"

cd "\$PROJECT_ROOT"
exec "\$VENV/bin/python" -m focuslens.app
EOF

chmod +x "$MACOS_DIR/FocusLens"

echo "✅ Successfully built: $APP_BUNDLE"
