"""
Tests for focuslens.insights – each rule tested with crafted DayMetrics.

Strategy: build DayMetrics objects directly (no DB, no collector)
and verify that each rule fires at the right thresholds.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date as Date
from typing import List

import pytest

from focuslens.insights.engine import (
    InsightEngine,
    _avg_cpu,
    _pct,
    _summary,
    _thermal_worst,
    _verdict,
    STRETCH_CRITICAL,
    STRETCH_WARNING,
    SWITCH_CRITICAL,
    SWITCH_WARNING,
    DISTRACT_CRITICAL,
    DISTRACT_WARNING,
    PRODUCTIVE_POSITIVE,
    SCORE_POSITIVE,
    MIN_TRACKED_MINUTES,
    NO_DW_THRESHOLD,
    SHALLOW_DW_MINUTES,
)
from focuslens.insights.models import DailyReport, Finding
from focuslens.metrics.models import AppUsage, DayMetrics, DeepWorkBlock, DomainUsage

TODAY = Date(2024, 3, 4)
ENGINE = InsightEngine()


# ── DayMetrics builder ────────────────────────────────────────────────────────

def _dm(
    productive_s: float = 0,
    neutral_s: float = 0,
    distracting_s: float = 0,
    idle_s: float = 0,
    focus_score: float = 50,
    deep_work_minutes: float = 0,
    n_deep_blocks: int = 0,
    context_switches: int = 0,
    context_switches_per_hour: float = 0,
    longest_stretch_min: float = 0,
    break_count: int = 0,
    top_distracting_domains: list | None = None,
    top_apps: list | None = None,
) -> DayMetrics:
    """Build a DayMetrics directly without going through the engine."""
    blocks = [
        DeepWorkBlock(
            start_ts=0,
            end_ts=deep_work_minutes * 60 / max(n_deep_blocks, 1),
            duration_minutes=deep_work_minutes / max(n_deep_blocks, 1),
            primary_app="Code",
        )
    ] * n_deep_blocks if n_deep_blocks > 0 else []

    return DayMetrics(
        date=TODAY,
        productive_seconds=productive_s,
        neutral_seconds=neutral_s,
        distracting_seconds=distracting_s,
        idle_seconds=idle_s,
        focus_score=focus_score,
        deep_work_blocks=blocks,
        context_switches=context_switches,
        context_switches_per_hour=context_switches_per_hour,
        longest_stretch_minutes=longest_stretch_min,
        break_count=break_count,
        top_distracting_domains=top_distracting_domains or [],
        top_apps=top_apps or [],
    )


def _ss(thermal: str = "nominal", cpu: float = 30.0) -> list[tuple]:
    """Build a single system_stats row."""
    return [(0.0, cpu, 50.0, 80.0, thermal)]


# ═══════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

class TestHelpers:
    def test_pct_normal(self):
        assert _pct(30, 100) == pytest.approx(30.0)

    def test_pct_zero_denom(self):
        assert _pct(50, 0) == 0.0

    def test_thermal_worst_nominal(self):
        assert _thermal_worst(_ss("nominal")) == "nominal"

    def test_thermal_worst_serious(self):
        rows = _ss("serious") + _ss("nominal")
        assert _thermal_worst(rows) == "serious"

    def test_thermal_worst_critical_beats_serious(self):
        rows = _ss("serious") + _ss("critical")
        assert _thermal_worst(rows) == "critical"

    def test_thermal_worst_empty(self):
        assert _thermal_worst([]) is None

    def test_avg_cpu_normal(self):
        rows = [(0, 80.0, 50, 80, "nominal"), (1, 60.0, 50, 80, "nominal")]
        assert _avg_cpu(rows) == pytest.approx(70.0)

    def test_avg_cpu_empty(self):
        assert _avg_cpu([]) == 0.0

    def test_avg_cpu_none_values_skipped(self):
        rows = [(0, None, 50, 80, "nominal"), (1, 80.0, 50, 80, "nominal")]
        assert _avg_cpu(rows) == pytest.approx(80.0)


# ═══════════════════════════════════════════════════════════════════════
# NOT ENOUGH DATA
# ═══════════════════════════════════════════════════════════════════════

class TestNotEnoughData:
    def test_short_session_skips_analysis(self):
        dm = _dm(productive_s=5 * 60)   # only 5 min
        report = ENGINE.analyse(dm)
        assert not report.has_enough_data
        assert report.findings == []

    def test_exactly_min_threshold_runs(self):
        dm = _dm(
            productive_s=MIN_TRACKED_MINUTES * 60,
            context_switches_per_hour=5,
        )
        report = ENGINE.analyse(dm)
        assert report.has_enough_data


# ═══════════════════════════════════════════════════════════════════════
# RULE: FRAGMENTED ATTENTION
# ═══════════════════════════════════════════════════════════════════════

class TestFragmentedAttention:
    def _make(self, sw_per_hr: float) -> DailyReport:
        dm = _dm(productive_s=3 * 3600, context_switches_per_hour=sw_per_hr)
        return ENGINE.analyse(dm)

    def test_no_finding_below_warning(self):
        report = self._make(10)
        ids = {f.rule_id for f in report.findings}
        assert "fragmented_attention" not in ids

    def test_warning_at_threshold(self):
        report = self._make(SWITCH_WARNING + 1)
        ids = {f.rule_id for f in report.findings}
        assert "fragmented_attention" in ids
        f = next(x for x in report.findings if x.rule_id == "fragmented_attention")
        assert f.severity == "warning"

    def test_critical_above_threshold(self):
        report = self._make(SWITCH_CRITICAL + 1)
        f = next(x for x in report.findings if x.rule_id == "fragmented_attention")
        assert f.severity == "critical"

    def test_finding_contains_value(self):
        report = self._make(25)
        f = next(x for x in report.findings if x.rule_id == "fragmented_attention")
        assert "25" in f.value or "25" in f.detail

    def test_fix_is_nonempty(self):
        report = self._make(25)
        f = next(x for x in report.findings if x.rule_id == "fragmented_attention")
        assert len(f.fix) > 20


# ═══════════════════════════════════════════════════════════════════════
# RULE: FATIGUE RISK
# ═══════════════════════════════════════════════════════════════════════

class TestFatigueRisk:
    def _make(self, stretch_min: float, breaks: int = 0) -> DailyReport:
        dm = _dm(
            productive_s=4 * 3600,
            longest_stretch_min=stretch_min,
            break_count=breaks,
        )
        return ENGINE.analyse(dm)

    def test_no_finding_short_stretch(self):
        report = self._make(60)
        ids = {f.rule_id for f in report.findings}
        assert "fatigue_risk" not in ids

    def test_warning_at_stretch_warning(self):
        report = self._make(STRETCH_WARNING + 1)
        f = next((x for x in report.findings if x.rule_id == "fatigue_risk"), None)
        assert f is not None and f.severity == "warning"

    def test_critical_at_stretch_critical(self):
        report = self._make(STRETCH_CRITICAL + 1)
        f = next(x for x in report.findings if x.rule_id == "fatigue_risk")
        assert f.severity == "critical"

    def test_finding_mentions_duration(self):
        report = self._make(200)
        f = next(x for x in report.findings if x.rule_id == "fatigue_risk")
        assert "200" in f.value or "200" in f.detail


# ═══════════════════════════════════════════════════════════════════════
# RULE: DISTRACTING TIME
# ═══════════════════════════════════════════════════════════════════════

class TestDistractingTime:
    def _make(self, distracting_pct: float, domains: list | None = None) -> DailyReport:
        active = 4 * 3600
        distracting_s = active * distracting_pct / 100
        productive_s = active - distracting_s
        dm = _dm(
            productive_s=productive_s,
            distracting_s=distracting_s,
            top_distracting_domains=domains or [],
        )
        return ENGINE.analyse(dm)

    def test_no_finding_below_warning(self):
        report = self._make(10)
        ids = {f.rule_id for f in report.findings}
        assert "distracting_time" not in ids

    def test_warning_at_threshold(self):
        report = self._make(DISTRACT_WARNING + 1)
        f = next((x for x in report.findings if x.rule_id == "distracting_time"), None)
        assert f is not None and f.severity == "warning"

    def test_critical_at_threshold(self):
        report = self._make(DISTRACT_CRITICAL + 1)
        f = next(x for x in report.findings if x.rule_id == "distracting_time")
        assert f.severity == "critical"

    def test_top_offenders_listed_in_detail(self):
        domains = [
            DomainUsage("youtube.com", 1800, "distracting"),
            DomainUsage("reddit.com", 900, "distracting"),
        ]
        report = self._make(30, domains)
        f = next(x for x in report.findings if x.rule_id == "distracting_time")
        assert "youtube.com" in f.detail

    def test_skipped_for_very_short_session(self):
        dm = _dm(productive_s=600, distracting_s=600)   # 10 min each
        report = ENGINE.analyse(dm)
        # Not enough active time for session (1200s < MIN_TRACKED * 60)
        # Actually 20 min > 30 min threshold? Let me check...
        # 1200s = 20min < MIN_TRACKED_MINUTES(30) * 60 = 1800s → no data
        assert not report.has_enough_data


# ═══════════════════════════════════════════════════════════════════════
# RULE: NO DEEP WORK
# ═══════════════════════════════════════════════════════════════════════

class TestNoDeepWork:
    def test_fires_for_long_session_with_no_blocks(self):
        dm = _dm(productive_s=(NO_DW_THRESHOLD + 10) * 60, n_deep_blocks=0)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "no_deep_work" in ids

    def test_does_not_fire_when_blocks_exist(self):
        dm = _dm(productive_s=3 * 3600, n_deep_blocks=2, deep_work_minutes=60)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "no_deep_work" not in ids

    def test_does_not_fire_for_short_session(self):
        # Only 45 min active (below NO_DW_THRESHOLD)
        dm = _dm(productive_s=45 * 60)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "no_deep_work" not in ids

    def test_finding_is_warning_severity(self):
        dm = _dm(productive_s=2 * 3600)
        report = ENGINE.analyse(dm)
        f = next((x for x in report.findings if x.rule_id == "no_deep_work"), None)
        assert f is not None
        assert f.severity == "warning"


# ═══════════════════════════════════════════════════════════════════════
# RULE: SHALLOW BLOCKS
# ═══════════════════════════════════════════════════════════════════════

class TestShallowBlocks:
    def test_fires_when_all_blocks_are_short(self):
        # 2 blocks, each 30 min (< SHALLOW_DW_MINUTES=40)
        dm = _dm(productive_s=3 * 3600, n_deep_blocks=2, deep_work_minutes=60)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "shallow_blocks" in ids

    def test_does_not_fire_when_blocks_are_long(self):
        # 1 block of 90 min (≥ SHALLOW_DW_MINUTES)
        dm = _dm(productive_s=3 * 3600, n_deep_blocks=1, deep_work_minutes=90)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "shallow_blocks" not in ids

    def test_does_not_fire_with_no_blocks(self):
        # no_deep_work fires instead
        dm = _dm(productive_s=2 * 3600, n_deep_blocks=0)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "shallow_blocks" not in ids

    def test_finding_is_info_severity(self):
        dm = _dm(productive_s=3 * 3600, n_deep_blocks=2, deep_work_minutes=60)
        report = ENGINE.analyse(dm)
        f = next((x for x in report.findings if x.rule_id == "shallow_blocks"), None)
        assert f is not None
        assert f.severity == "info"


# ═══════════════════════════════════════════════════════════════════════
# RULE: LOW PRODUCTIVE TIME
# ═══════════════════════════════════════════════════════════════════════

class TestLowProductiveTime:
    def test_fires_for_low_productive_pct(self):
        # Only 20% productive
        dm = _dm(productive_s=3600, neutral_s=3600, distracting_s=2 * 3600)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "low_productive_time" in ids

    def test_does_not_fire_for_good_productive_pct(self):
        # 80% productive
        dm = _dm(productive_s=3 * 3600, distracting_s=3600)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "low_productive_time" not in ids

    def test_does_not_fire_for_short_session(self):
        dm = _dm(productive_s=10 * 60, distracting_s=40 * 60)   # 50 min total but 20% prod
        # Session < 1h active → rule skips
        report = ENGINE.analyse(dm)
        # 50min active is < 60min threshold but also ≥ MIN_TRACKED → analyse runs
        ids = {f.rule_id for f in report.findings}
        # 10 / 50 = 20% < 30% threshold — but active < 3600 → no fire
        assert "low_productive_time" not in ids


# ═══════════════════════════════════════════════════════════════════════
# RULE: MACHINE BOTTLENECK
# ═══════════════════════════════════════════════════════════════════════

class TestMachineBottleneck:
    def test_fires_for_serious_thermal(self):
        dm = _dm(productive_s=2 * 3600)
        report = ENGINE.analyse(dm, sys_stats=_ss("serious"))
        ids = {f.rule_id for f in report.findings}
        assert "machine_bottleneck" in ids

    def test_fires_for_critical_thermal(self):
        dm = _dm(productive_s=2 * 3600)
        report = ENGINE.analyse(dm, sys_stats=_ss("critical"))
        ids = {f.rule_id for f in report.findings}
        assert "machine_bottleneck" in ids

    def test_does_not_fire_for_nominal(self):
        dm = _dm(productive_s=2 * 3600)
        report = ENGINE.analyse(dm, sys_stats=_ss("nominal"))
        ids = {f.rule_id for f in report.findings}
        assert "machine_bottleneck" not in ids

    def test_does_not_fire_for_fair(self):
        dm = _dm(productive_s=2 * 3600)
        report = ENGINE.analyse(dm, sys_stats=_ss("fair"))
        ids = {f.rule_id for f in report.findings}
        assert "machine_bottleneck" not in ids

    def test_finding_is_warning_severity(self):
        dm = _dm(productive_s=2 * 3600)
        report = ENGINE.analyse(dm, sys_stats=_ss("serious"))
        f = next(x for x in report.findings if x.rule_id == "machine_bottleneck")
        assert f.severity == "warning"


# ═══════════════════════════════════════════════════════════════════════
# POSITIVE RULES
# ═══════════════════════════════════════════════════════════════════════

class TestPositiveFindings:
    def test_strong_focus_fires_above_threshold(self):
        dm = _dm(
            productive_s=3 * 3600,
            focus_score=SCORE_POSITIVE + 1,
        )
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "strong_focus" in ids

    def test_strong_focus_does_not_fire_below_threshold(self):
        dm = _dm(productive_s=3 * 3600, focus_score=SCORE_POSITIVE - 1)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "strong_focus" not in ids

    def test_deep_work_champion_fires_above_90_min(self):
        dm = _dm(productive_s=3 * 3600, n_deep_blocks=1, deep_work_minutes=95)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "deep_work_champion" in ids

    def test_great_break_habits_fires(self):
        dm = _dm(
            productive_s=3 * 3600,
            break_count=3,
            longest_stretch_min=50,
        )
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "great_break_habits" in ids

    def test_great_break_habits_does_not_fire_if_no_breaks(self):
        dm = _dm(productive_s=3 * 3600, break_count=0, longest_stretch_min=200)
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "great_break_habits" not in ids

    def test_productive_majority_fires(self):
        dm = _dm(
            productive_s=3 * 3600,
            neutral_s=30 * 60,   # 80% productive
        )
        report = ENGINE.analyse(dm)
        ids = {f.rule_id for f in report.findings}
        assert "productive_majority" in ids

    def test_positive_findings_severity(self):
        dm = _dm(
            productive_s=3 * 3600,
            focus_score=80,
            n_deep_blocks=1,
            deep_work_minutes=95,
        )
        report = ENGINE.analyse(dm)
        for f in report.positives:
            assert f.severity == "positive"


# ═══════════════════════════════════════════════════════════════════════
# VERDICT & SUMMARY
# ═══════════════════════════════════════════════════════════════════════

class TestVerdict:
    def test_excellent_when_high_score_no_issues(self):
        v = _verdict(80, 0, 0, 2)
        assert "Excellent" in v or "🌟" in v

    def test_rough_day_when_two_criticals(self):
        v = _verdict(30, 2, 0, 0)
        assert "Rough" in v or "🔴" in v

    def test_challenging_day_one_critical(self):
        v = _verdict(35, 1, 1, 0)
        assert "Challenging" in v or "🟠" in v

    def test_good_day_when_score_above_60(self):
        v = _verdict(65, 0, 1, 1)
        assert "Good" in v or "👍" in v


class TestSummary:
    def test_summary_nonempty_for_valid_day(self):
        dm = _dm(productive_s=3 * 3600, focus_score=65)
        report = ENGINE.analyse(dm)
        assert len(report.summary) > 20

    def test_summary_mentions_score(self):
        dm = _dm(productive_s=3 * 3600, focus_score=72)
        report = ENGINE.analyse(dm)
        assert "72" in report.summary

    def test_summary_mentions_top_issue(self):
        dm = _dm(
            productive_s=3 * 3600,
            context_switches_per_hour=35,   # critical
        )
        report = ENGINE.analyse(dm)
        # Summary should reference the fragmented attention issue
        assert "fragmented" in report.summary.lower() or "switch" in report.summary.lower()


# ═══════════════════════════════════════════════════════════════════════
# INTEGRATION: FULL REPORT
# ═══════════════════════════════════════════════════════════════════════

class TestFullReport:
    def test_report_has_date(self):
        dm = _dm(productive_s=2 * 3600)
        report = ENGINE.analyse(dm)
        assert report.date == TODAY

    def test_max_negatives_respected(self):
        from focuslens.insights.engine import MAX_NEGATIVES
        # Trigger many negative rules at once
        dm = _dm(
            productive_s=1800,
            distracting_s=3 * 3600,          # distracting_time
            context_switches_per_hour=35,     # fragmented
            longest_stretch_min=200,          # fatigue
        )
        report = ENGINE.analyse(dm, sys_stats=_ss("critical"))  # + bottleneck
        assert len(report.negatives) <= MAX_NEGATIVES

    def test_max_positives_respected(self):
        from focuslens.insights.engine import MAX_POSITIVES
        dm = _dm(
            productive_s=4 * 3600,
            focus_score=85,
            n_deep_blocks=1,
            deep_work_minutes=100,
            break_count=3,
            longest_stretch_min=50,
        )
        report = ENGINE.analyse(dm)
        assert len(report.positives) <= MAX_POSITIVES

    def test_sorted_findings_critical_first(self):
        dm = _dm(
            productive_s=3 * 3600,
            context_switches_per_hour=35,   # critical
            longest_stretch_min=100,        # warning
        )
        report = ENGINE.analyse(dm)
        sf = report.sorted_findings()
        # All criticals before all warnings
        severities = [f.severity for f in sf if f.severity in ("critical", "warning")]
        for i in range(len(severities) - 1):
            if severities[i] == "warning":
                assert severities[i + 1] != "critical"

    def test_finding_has_all_fields(self):
        dm = _dm(productive_s=2 * 3600, context_switches_per_hour=25)
        report = ENGINE.analyse(dm)
        for f in report.findings:
            assert f.rule_id
            assert f.severity in ("critical", "warning", "info", "positive")
            assert f.title
            assert f.detail
            assert f.fix
            assert f.metric
            assert f.value

    def test_no_sys_stats_does_not_crash(self):
        dm = _dm(productive_s=2 * 3600)
        report = ENGINE.analyse(dm)   # no sys_stats arg
        assert isinstance(report, DailyReport)

    def test_all_idle_session_handled(self):
        dm = _dm(idle_s=2 * 3600)   # 0 active time
        report = ENGINE.analyse(dm)
        # Active time is 0 → below MIN_TRACKED
        assert not report.has_enough_data

    def test_overall_verdict_nonempty(self):
        dm = _dm(productive_s=2 * 3600, focus_score=60)
        report = ENGINE.analyse(dm)
        assert len(report.overall_verdict) > 5
