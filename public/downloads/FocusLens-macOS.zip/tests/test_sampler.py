"""
Tests for focuslens.collector.sampler – Blocklist and domain helpers.
Uses only pure-Python logic (no macOS APIs called).
"""

import re
import tempfile
from pathlib import Path

import pytest
import yaml

from focuslens.collector.sampler import Blocklist, _BLOCKED_PLACEHOLDER


# ── Fixtures ─────────────────────────────────────────────────────────────────

def _write_blocklist(tmp_path: Path, data: dict) -> Path:
    p = tmp_path / "blocklist.yaml"
    p.write_text(yaml.dump(data))
    return p


# ── Blocklist tests ───────────────────────────────────────────────────────────

class TestBlocklist:
    def test_empty_blocklist_passes_everything(self, tmp_path):
        path = _write_blocklist(tmp_path, {})
        bl = Blocklist(path)
        assert bl.filter_title("Safari", "GitHub") == "GitHub"

    def test_blocked_app_name(self, tmp_path):
        path = _write_blocklist(tmp_path, {"blocked_apps": ["1Password"]})
        bl = Blocklist(path)
        assert bl.filter_title("1Password", "Login vault") == _BLOCKED_PLACEHOLDER

    def test_blocked_app_name_case_insensitive(self, tmp_path):
        path = _write_blocklist(tmp_path, {"blocked_apps": ["1password"]})
        bl = Blocklist(path)
        assert bl.filter_title("1Password", "some title") == _BLOCKED_PLACEHOLDER

    def test_blocked_title_pattern(self, tmp_path):
        path = _write_blocklist(tmp_path, {"blocked_title_patterns": [".*password.*"]})
        bl = Blocklist(path)
        assert bl.filter_title("Chrome", "Reset password – Gmail") == _BLOCKED_PLACEHOLDER

    def test_blocked_title_pattern_case_insensitive(self, tmp_path):
        path = _write_blocklist(tmp_path, {"blocked_title_patterns": [".*PASSWORD.*"]})
        bl = Blocklist(path)
        assert bl.filter_title("Chrome", "Reset password page") == _BLOCKED_PLACEHOLDER

    def test_non_blocked_title_preserved(self, tmp_path):
        path = _write_blocklist(
            tmp_path,
            {"blocked_apps": ["1Password"], "blocked_title_patterns": [".*secret.*"]}
        )
        bl = Blocklist(path)
        assert bl.filter_title("Safari", "GitHub – Pull request #42") == "GitHub – Pull request #42"

    def test_multiple_patterns(self, tmp_path):
        path = _write_blocklist(
            tmp_path,
            {"blocked_title_patterns": [".*private.*", ".*incognito.*", ".*vault.*"]}
        )
        bl = Blocklist(path)
        assert bl.filter_title("Safari", "Private Window – DuckDuckGo") == _BLOCKED_PLACEHOLDER
        assert bl.filter_title("Safari", "Incognito Tab – Google") == _BLOCKED_PLACEHOLDER
        assert bl.filter_title("Safari", "My Vault – Bitwarden") == _BLOCKED_PLACEHOLDER
        assert bl.filter_title("Safari", "GitHub PR Review") == "GitHub PR Review"

    def test_none_app_is_not_blocked(self, tmp_path):
        path = _write_blocklist(tmp_path, {"blocked_apps": ["1Password"]})
        bl = Blocklist(path)
        assert bl.filter_title(None, "Some Window") == "Some Window"

    def test_none_title_returns_none(self, tmp_path):
        path = _write_blocklist(tmp_path, {})
        bl = Blocklist(path)
        assert bl.filter_title("Safari", None) is None

    def test_missing_blocklist_file(self, tmp_path):
        """A missing blocklist file should not crash – use empty blocklist."""
        bl = Blocklist(tmp_path / "nonexistent.yaml")
        assert bl.filter_title("Safari", "GitHub") == "GitHub"

    def test_invalid_regex_pattern_skipped(self, tmp_path):
        """Bad regex patterns should be skipped without crashing."""
        path = _write_blocklist(
            tmp_path,
            {"blocked_title_patterns": ["[invalid", ".*valid.*"]}
        )
        bl = Blocklist(path)
        # Bad pattern skipped; valid pattern still applied
        assert bl.filter_title("Safari", "valid match") == _BLOCKED_PLACEHOLDER
        assert bl.filter_title("Safari", "no match") == "no match"

    def test_is_app_blocked(self, tmp_path):
        path = _write_blocklist(tmp_path, {"blocked_apps": ["Keychain Access"]})
        bl = Blocklist(path)
        assert bl.is_app_blocked("Keychain Access") is True
        assert bl.is_app_blocked("Safari") is False

    def test_is_title_blocked(self, tmp_path):
        path = _write_blocklist(tmp_path, {"blocked_title_patterns": [".*secret.*"]})
        bl = Blocklist(path)
        assert bl.is_title_blocked("my secret key") is True
        assert bl.is_title_blocked("normal title") is False
