"""
tests.fixtures.sample_builder
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Helpers for building synthetic sample rows for tests.
No DB required – rows are plain tuples matching the SELECT column order:
  (ts, active_app, window_title, browser_domain,
   idle_seconds, screen_locked, kb_events, mouse_events)
"""

from __future__ import annotations

from datetime import datetime

# Fixed reference date for all tests (a Monday)
TEST_DATE_STR = "2024-03-04"
BASE_TS = datetime(2024, 3, 4, 9, 0, 0).timestamp()   # 09:00:00 local


def make_row(
    offset_seconds: float = 0,
    app: str = "Code",
    title: str = "main.py",
    domain: str | None = None,
    idle: float = 0.0,
    locked: bool = False,
    kb: int = 5,
    mouse: int = 2,
) -> tuple:
    """Return a single sample row tuple."""
    return (
        BASE_TS + offset_seconds,
        app,
        title,
        domain,
        idle,
        1 if locked else 0,
        kb,
        mouse,
    )


def productive_block(
    start_offset: float,
    duration_seconds: float,
    app: str = "Code",
    interval: float = 3.0,
) -> list[tuple]:
    """Generate a run of productive samples."""
    rows = []
    t = start_offset
    while t < start_offset + duration_seconds:
        rows.append(make_row(t, app=app))
        t += interval
    return rows


def distracting_block(
    start_offset: float,
    duration_seconds: float,
    app: str = "Safari",
    domain: str = "youtube.com",
    interval: float = 3.0,
) -> list[tuple]:
    """Generate a run of distracting samples."""
    rows = []
    t = start_offset
    while t < start_offset + duration_seconds:
        rows.append(make_row(t, app=app, domain=domain))
        t += interval
    return rows


def idle_block(
    start_offset: float,
    duration_seconds: float,
    interval: float = 3.0,
) -> list[tuple]:
    """Generate a run of idle samples (idle_seconds=120, no app)."""
    rows = []
    t = start_offset
    while t < start_offset + duration_seconds:
        rows.append(make_row(t, app=None, title=None, idle=120.0, kb=0, mouse=0))
        t += interval
    return rows


def locked_block(
    start_offset: float,
    duration_seconds: float,
    interval: float = 3.0,
) -> list[tuple]:
    """Generate a run of screen-locked samples."""
    rows = []
    t = start_offset
    while t < start_offset + duration_seconds:
        rows.append(make_row(t, locked=True, idle=120.0, kb=0, mouse=0))
        t += interval
    return rows
