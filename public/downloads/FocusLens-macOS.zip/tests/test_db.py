"""
Tests for focuslens.db.store
Uses an in-memory SQLite database (via tmp path) so no real file is created.
"""

import time
import tempfile
from pathlib import Path

import pytest

from focuslens.db.store import Store


@pytest.fixture()
def store(tmp_path):
    """Provide a fresh Store backed by a temp file."""
    db = Store(tmp_path / "test.db")
    yield db
    db.close()


class TestSessions:
    def test_start_returns_id(self, store):
        sid = store.start_session(time.time())
        assert isinstance(sid, int)
        assert sid >= 1

    def test_stop_session(self, store):
        now = time.time()
        sid = store.start_session(now)
        store.stop_session(sid, now + 60)
        counts = store.row_counts()
        assert counts["sessions"] == 1

    def test_multiple_sessions(self, store):
        for _ in range(5):
            sid = store.start_session(time.time())
            store.stop_session(sid, time.time() + 10)
        assert store.row_counts()["sessions"] == 5


class TestSamples:
    def test_insert_sample(self, store):
        sid = store.start_session(time.time())
        store.insert_sample(
            session_id=sid,
            ts=time.time(),
            active_app="Safari",
            window_title="GitHub",
            browser_domain="github.com",
            idle_seconds=0.5,
            screen_locked=False,
            kb_events=10,
            mouse_events=5,
        )
        assert store.row_counts()["samples"] == 1

    def test_blocked_title_stored_verbatim(self, store):
        """Store layer is blind to blocklist – it stores whatever string it's given."""
        sid = store.start_session(time.time())
        store.insert_sample(
            session_id=sid, ts=time.time(),
            active_app="1Password", window_title="<blocked>",
            browser_domain=None, idle_seconds=0, screen_locked=False,
            kb_events=0, mouse_events=0,
        )
        assert store.row_counts()["samples"] == 1

    def test_many_samples(self, store):
        sid = store.start_session(time.time())
        ts = time.time()
        for i in range(100):
            store.insert_sample(
                session_id=sid, ts=ts + i * 3,
                active_app="Code", window_title="main.py",
                browser_domain=None, idle_seconds=0,
                screen_locked=False, kb_events=i, mouse_events=0,
            )
        assert store.row_counts()["samples"] == 100

    def test_screen_locked_bool(self, store):
        sid = store.start_session(time.time())
        store.insert_sample(
            session_id=sid, ts=time.time(),
            active_app=None, window_title=None,
            browser_domain=None, idle_seconds=999,
            screen_locked=True, kb_events=0, mouse_events=0,
        )
        assert store.row_counts()["samples"] == 1


class TestSystemStats:
    def test_insert_system_stat(self, store):
        sid = store.start_session(time.time())
        store.insert_system_stat(
            session_id=sid, ts=time.time(),
            cpu_pct=42.0, ram_pct=60.0,
            battery_pct=80.0, thermal_state="nominal",
        )
        assert store.row_counts()["system_stats"] == 1

    def test_nullable_fields(self, store):
        sid = store.start_session(time.time())
        store.insert_system_stat(
            session_id=sid, ts=time.time(),
            cpu_pct=None, ram_pct=None,
            battery_pct=None, thermal_state=None,
        )
        assert store.row_counts()["system_stats"] == 1


class TestDeleteAll:
    def test_delete_removes_all_rows(self, store):
        sid = store.start_session(time.time())
        for _ in range(10):
            store.insert_sample(
                session_id=sid, ts=time.time(),
                active_app="Safari", window_title="Google",
                browser_domain="google.com", idle_seconds=0,
                screen_locked=False, kb_events=1, mouse_events=1,
            )
            store.insert_system_stat(
                session_id=sid, ts=time.time(),
                cpu_pct=10.0, ram_pct=50.0,
                battery_pct=90.0, thermal_state="nominal",
            )
        before = store.row_counts()
        assert before["samples"] == 10
        assert before["system_stats"] == 10

        store.delete_all_data()
        after = store.row_counts()
        assert after == {"sessions": 0, "samples": 0, "system_stats": 0}


class TestRowCounts:
    def test_initial_counts_are_zero(self, store):
        assert store.row_counts() == {"sessions": 0, "samples": 0, "system_stats": 0}
