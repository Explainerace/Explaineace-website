"""
Tests for focuslens.dashboard.helpers – no Streamlit or Plotly required.
"""

from __future__ import annotations

import pytest

from focuslens.dashboard.helpers import (
    CATEGORY_COLORS,
    TimelineSegment,
    fmt_seconds,
    focus_score_color,
    focus_score_label,
    merge_to_segments,
)
from tests.fixtures.sample_builder import (
    BASE_TS,
    distracting_block,
    idle_block,
    make_row,
    productive_block,
)


# ── fmt_seconds ───────────────────────────────────────────────────────────────

class TestFmtSeconds:
    def test_seconds_only(self):
        assert fmt_seconds(45) == "45s"

    def test_minutes_only(self):
        assert fmt_seconds(90) == "1m"

    def test_hours_and_minutes(self):
        assert fmt_seconds(3661) == "1h 01m"

    def test_two_hours(self):
        assert fmt_seconds(7200) == "2h 00m"

    def test_zero(self):
        assert fmt_seconds(0) == "0s"

    def test_exactly_one_minute(self):
        assert fmt_seconds(60) == "1m"


# ── focus_score_color ─────────────────────────────────────────────────────────

class TestFocusScoreColor:
    def test_high_is_green(self):
        assert focus_score_color(85) == "#22c55e"

    def test_medium_is_amber(self):
        assert focus_score_color(55) == "#f59e0b"

    def test_low_is_red(self):
        assert focus_score_color(20) == "#ef4444"

    def test_boundary_70_is_green(self):
        assert focus_score_color(70) == "#22c55e"

    def test_boundary_40_is_amber(self):
        assert focus_score_color(40) == "#f59e0b"


class TestFocusScoreLabel:
    def test_high(self):
        assert "High" in focus_score_label(75)

    def test_medium(self):
        assert "Medium" in focus_score_label(55)

    def test_low(self):
        assert "Low" in focus_score_label(30)


# ── merge_to_segments ─────────────────────────────────────────────────────────

class TestMergeToSegments:
    def test_empty_returns_empty(self):
        assert merge_to_segments([], []) == []

    def test_single_sample_returns_one_segment(self):
        rows = [make_row(0, app="Code")]
        cats = ["productive"]
        segs = merge_to_segments(rows, cats)
        assert len(segs) == 1
        assert segs[0].category == "productive"

    def test_same_cat_merged_into_one_segment(self):
        rows = productive_block(0, 60)   # 20 samples
        cats = ["productive"] * len(rows)
        segs = merge_to_segments(rows, cats)
        assert len(segs) == 1

    def test_category_change_splits_segment(self):
        rows = productive_block(0, 30) + distracting_block(30, 30)
        cats = ["productive"] * (len(rows) // 2) + ["distracting"] * (len(rows) // 2)
        segs = merge_to_segments(rows, cats)
        assert len(segs) == 2
        assert segs[0].category == "productive"
        assert segs[1].category == "distracting"

    def test_large_gap_splits_segment(self):
        # Samples at t=0 and t=120 (gap=120s > gap_cap=30s) → 2 segments
        rows = [make_row(0, app="Code"), make_row(120, app="Code")]
        cats = ["productive", "productive"]
        segs = merge_to_segments(rows, cats, gap_cap=30.0)
        assert len(segs) == 2

    def test_duration_calculated_correctly(self):
        # 10 samples at 3s interval = ~30s span
        rows = productive_block(0, 30, interval=3)
        cats = ["productive"] * len(rows)
        segs = merge_to_segments(rows, cats)
        assert len(segs) == 1
        # duration = end_ts - start_ts + one sample width (3s)
        assert segs[0].duration_seconds > 25

    def test_segment_has_correct_category(self):
        rows = [make_row(0, app="Safari", domain="youtube.com")]
        cats = ["distracting"]
        segs = merge_to_segments(rows, cats)
        assert segs[0].category == "distracting"

    def test_three_categories_three_segments(self):
        rows = (
            productive_block(0, 30)
            + distracting_block(30, 30)
            + idle_block(60, 30)
        )
        cats = (
            ["productive"] * len(productive_block(0, 30))
            + ["distracting"] * len(distracting_block(30, 30))
            + ["idle"] * len(idle_block(60, 30))
        )
        segs = merge_to_segments(rows, cats)
        assert len(segs) == 3
        assert {s.category for s in segs} == {"productive", "distracting", "idle"}

    def test_start_and_end_ts(self):
        rows = [make_row(100, app="Code"), make_row(103, app="Code")]
        cats = ["productive", "productive"]
        segs = merge_to_segments(rows, cats)
        expected_start = BASE_TS + 100
        expected_end = BASE_TS + 103 + 3   # last ts + one sample width
        assert segs[0].start_ts == expected_start
        assert segs[0].end_ts == expected_end


# ── category colors ───────────────────────────────────────────────────────────

class TestCategoryColors:
    def test_all_categories_have_colors(self):
        for cat in ("productive", "neutral", "distracting", "idle"):
            assert cat in CATEGORY_COLORS
            assert CATEGORY_COLORS[cat].startswith("#")

    def test_colors_are_valid_hex(self):
        import re
        hex_re = re.compile(r"^#[0-9a-fA-F]{6}$")
        for color in CATEGORY_COLORS.values():
            assert hex_re.match(color), f"Invalid hex color: {color}"


# ── demo data & tracker control ───────────────────────────────────────────────

class TestDemoData:
    def test_inject_demo_day(self, tmp_path):
        from datetime import date
        from focuslens.dashboard.demo_data import inject_demo_day
        from focuslens.db.store import Store

        store = Store(tmp_path / "test.db")
        count = inject_demo_day(store, date(2024, 3, 4))
        assert count > 1000

        samples = store.fetch_samples_for_day("2024-03-04")
        assert len(samples) == count
        stats = store.fetch_system_stats_for_day("2024-03-04")
        assert len(stats) > 10


class TestTrackerControl:
    def test_tracker_pid_and_status(self):
        from focuslens.dashboard.tracker_ctl import get_collector_pid, is_tracker_running
        # Initially or if no collector, should be int or None
        pid = get_collector_pid()
        assert pid is None or isinstance(pid, int)
        assert isinstance(is_tracker_running(), bool)
