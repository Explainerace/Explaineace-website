"""
Tests for focuslens.saas (Auth, Goals, Gamification & Teams).
"""

from __future__ import annotations

import pytest
from datetime import date

from focuslens.db.store import Store
from focuslens.saas.auth import AuthManager
from focuslens.saas.goals import GoalManager
from focuslens.saas.teams import TeamAnalyticsManager
from focuslens.metrics.models import DayMetrics, DeepWorkBlock


@pytest.fixture
def store(tmp_path):
    return Store(tmp_path / "saas_test.db")


def test_auth_registration_and_login(store):
    auth = AuthManager(store)
    user = auth.register("sarah@example.com", "SecretPass123!", plan_tier="pro")

    assert user.id is not None
    assert user.email == "sarah@example.com"
    assert user.api_key.startswith("fl_")
    assert user.is_pro_or_higher is True

    # Successful login
    auth_user = auth.authenticate("sarah@example.com", "SecretPass123!")
    assert auth_user is not None
    assert auth_user.id == user.id

    # Failed login
    wrong_pwd = auth.authenticate("sarah@example.com", "WrongPassword!")
    assert wrong_pwd is None


def test_auth_lookup_by_api_key(store):
    auth = AuthManager(store)
    user = auth.register("dev@focuslens.io", "Password99!", plan_tier="team")

    found = auth.get_by_api_key(user.api_key)
    assert found is not None
    assert found.email == "dev@focuslens.io"
    assert found.plan_tier == "team"

    assert auth.get_by_api_key("invalid_key") is None


def test_get_or_create_default_user(store):
    auth = AuthManager(store)
    u1 = auth.get_or_create_default_user()
    u2 = auth.get_or_create_default_user()
    assert u1.id == u2.id
    assert u1.email == "demo@focuslens.io"


def test_goal_evaluation_and_badges(store):
    auth = AuthManager(store)
    user = auth.register("alex@example.com", "Pass123!")
    gm = GoalManager(store)

    # Set custom goal
    gm.update_goals(user.id, deep_work_m=180, max_distract_m=45, target_score=75)

    dm = DayMetrics(
        date=date(2024, 3, 4),
        productive_seconds=14400.0,
        neutral_seconds=1800.0,
        distracting_seconds=1200.0,  # 20 min
        idle_seconds=600.0,
        focus_score=82.0,
        deep_work_blocks=[
            DeepWorkBlock(start_ts=0, end_ts=7200, duration_minutes=120, primary_app="Code"),
            DeepWorkBlock(start_ts=7200, end_ts=12000, duration_minutes=80, primary_app="Terminal"),
        ],
        context_switches=10,
        context_switches_per_hour=2.5,
        longest_stretch_minutes=60.0,
        break_count=3,
    )

    eval_result = gm.evaluate_day(user.id, dm)
    assert eval_result.deep_work_actual_m == 200.0
    assert eval_result.deep_work_pct == 100.0
    assert eval_result.distraction_actual_m == 20.0
    assert eval_result.distraction_budget_left_m == 25.0
    assert eval_result.goals_met is True
    assert len(eval_result.badges) >= 2


def test_team_analytics(store):
    tm = TeamAnalyticsManager(store)
    bench = tm.get_team_benchmark("Frontend Core")
    assert bench.member_count == 8
    assert bench.avg_focus_score > 70
    assert bench.burnout_risk_score in ("Low", "Moderate", "Elevated")
