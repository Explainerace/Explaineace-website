"""
Tests for focuslens.collector.session – SessionManager lifecycle.
No DB required (store is mocked).
"""

import time
from unittest.mock import MagicMock, call

import pytest

from focuslens.collector.session import SessionManager, SessionState


@pytest.fixture()
def mock_store():
    store = MagicMock()
    store.start_session.return_value = 1
    return store


@pytest.fixture()
def mgr(mock_store):
    return SessionManager(mock_store)


class TestSessionLifecycle:
    def test_initial_state_is_idle(self, mgr):
        assert mgr.state == SessionState.IDLE

    def test_start_creates_session(self, mgr, mock_store):
        session = mgr.start()
        assert session.session_id == 1
        assert mgr.state == SessionState.RUNNING
        mock_store.start_session.assert_called_once()

    def test_stop_calls_store(self, mgr, mock_store):
        mgr.start()
        info = mgr.stop()
        mock_store.stop_session.assert_called_once()
        assert info.state == SessionState.STOPPED
        assert mgr.state == SessionState.IDLE
        assert mgr.current is None

    def test_pause_and_resume(self, mgr):
        mgr.start()
        mgr.pause()
        assert mgr.state == SessionState.PAUSED
        mgr.resume()
        assert mgr.state == SessionState.RUNNING

    def test_elapsed_increases(self, mgr):
        mgr.start()
        t0 = mgr.current.elapsed_seconds()
        time.sleep(0.05)
        t1 = mgr.current.elapsed_seconds()
        assert t1 > t0

    def test_double_start_raises(self, mgr):
        mgr.start()
        with pytest.raises(RuntimeError):
            mgr.start()

    def test_pause_then_stop(self, mgr, mock_store):
        mgr.start()
        mgr.pause()
        info = mgr.stop()
        # stop() should resume first, then stop
        assert info is not None
        mock_store.stop_session.assert_called_once()

    def test_elapsed_display_format(self, mgr):
        mgr.start()
        display = mgr.current.elapsed_display()
        assert len(display) == 8  # HH:MM:SS
        assert display.count(":") == 2
