"""
Tests for focuslens.ai (prompt builder, client, and providers).
"""

from __future__ import annotations

import json
from datetime import date as Date
from unittest.mock import MagicMock, patch

import pytest

from focuslens.ai.client import (
    AIClient,
    AIReportResult,
    ClaudeBackend,
    OfflineMockBackend,
    OllamaBackend,
)
from focuslens.ai.prompt import build_prompt
from focuslens.insights.models import DailyReport, Finding
from focuslens.metrics.models import AppUsage, DayMetrics, DeepWorkBlock, DomainUsage

TODAY = Date(2024, 3, 4)


@pytest.fixture
def sample_metrics_and_report():
    dm = DayMetrics(
        date=TODAY,
        productive_seconds=7200.0,
        neutral_seconds=1800.0,
        distracting_seconds=1800.0,
        idle_seconds=600.0,
        focus_score=78.0,
        deep_work_blocks=[
            DeepWorkBlock(
                start_ts=0,
                end_ts=3600,
                duration_minutes=60,
                primary_app="Code",
            )
        ],
        context_switches=12,
        context_switches_per_hour=4.0,
        longest_stretch_minutes=65.0,
        break_count=2,
        top_apps=[
            AppUsage(name="Code", seconds=7200.0, category="productive"),
            AppUsage(name="Slack", seconds=1800.0, category="neutral"),
        ],
        top_distracting_domains=[
            DomainUsage(domain="reddit.com", seconds=1800.0, category="distracting"),
        ],
    )
    report = DailyReport(
        date=TODAY,
        findings=[
            Finding(
                rule_id="strong_focus",
                severity="positive",
                title="Strong focus session",
                detail="Focus score of 78/100.",
                fix="Keep it up.",
                metric="Focus score",
                value="78 / 100",
            )
        ],
        summary="Strong day with solid deep work blocks.",
        overall_verdict="🌟 Excellent day",
        score=78.0,
        has_enough_data=True,
    )
    return dm, report


# ═══════════════════════════════════════════════════════════════════════
# PROMPT BUILDER TESTS
# ═══════════════════════════════════════════════════════════════════════

class TestPromptBuilder:
    def test_prompt_structure(self, sample_metrics_and_report):
        dm, report = sample_metrics_and_report
        sys_prompt, user_prompt = build_prompt(
            dm, report,
            week_dates=["2024-03-03", "2024-03-04"],
            week_scores=[65.0, 78.0],
        )

        assert "productivity coach" in sys_prompt.lower()
        assert "SESSION OVERVIEW" in user_prompt
        assert "Code" in user_prompt
        assert "reddit.com" in user_prompt
        assert "Strong focus session" in user_prompt
        assert "78" in user_prompt
        assert "2024-03-04" in user_prompt

    def test_privacy_no_window_titles_or_full_urls(self, sample_metrics_and_report):
        dm, report = sample_metrics_and_report
        _, user_prompt = build_prompt(dm, report)

        # Confirm nothing resembling sensitive URLs with query parameters or paths
        assert "https://" not in user_prompt
        assert "http://" not in user_prompt
        assert "file://" not in user_prompt
        assert "?" not in user_prompt  # No query strings

    def test_prompt_handles_empty_findings_and_trends(self):
        dm = DayMetrics(
            date=TODAY,
            productive_seconds=0,
            neutral_seconds=0,
            distracting_seconds=0,
            idle_seconds=0,
            focus_score=0.0,
            deep_work_blocks=[],
            context_switches=0,
            context_switches_per_hour=0.0,
            longest_stretch_minutes=0,
            break_count=0,
        )
        report = DailyReport(date=TODAY, has_enough_data=False)
        sys_prompt, user_prompt = build_prompt(dm, report)

        assert "no app data" in user_prompt
        assert "None recorded" in user_prompt
        assert "no trend data available" in user_prompt


# ═══════════════════════════════════════════════════════════════════════
# BACKEND & CLIENT TESTS
# ═══════════════════════════════════════════════════════════════════════

class TestAIClientAndBackends:
    def test_offline_mock_generation(self, sample_metrics_and_report):
        dm, report = sample_metrics_and_report
        client = AIClient(provider="offline")
        res = client.generate_report(dm, report)

        assert res.success is True
        assert res.provider == "offline_mock"
        assert len(res.content) > 100
        assert "Executive Coaching Analysis" in res.content

    def test_provider_selection_auto_defaults_to_offline_if_no_services(self):
        with patch.object(OllamaBackend, "is_available", return_value=False), \
             patch.object(ClaudeBackend, "is_available", return_value=False):
            client = AIClient(provider="auto")
            backend = client.select_backend()
            assert isinstance(backend, OfflineMockBackend)

    def test_provider_selection_auto_prefers_ollama_if_available(self):
        with patch.object(OllamaBackend, "is_available", return_value=True):
            client = AIClient(provider="auto")
            backend = client.select_backend()
            assert isinstance(backend, OllamaBackend)

    def test_provider_selection_auto_picks_claude_if_key_present(self):
        with patch.object(OllamaBackend, "is_available", return_value=False), \
             patch.object(ClaudeBackend, "is_available", return_value=True):
            client = AIClient(provider="auto")
            backend = client.select_backend()
            assert isinstance(backend, ClaudeBackend)

    def test_claude_backend_missing_key(self):
        backend = ClaudeBackend(api_key="")
        res = backend.generate("sys", "user")
        assert res.success is False
        assert "ANTHROPIC_API_KEY" in res.error

    def test_claude_backend_successful_call(self):
        backend = ClaudeBackend(api_key="sk-ant-testkey123")
        mock_resp_data = {
            "content": [
                {"type": "text", "text": "Here is your Claude productivity analysis."}
            ]
        }
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_resp_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response

        with patch("urllib.request.urlopen", return_value=mock_response):
            res = backend.generate("sys", "user")
            assert res.success is True
            assert res.content == "Here is your Claude productivity analysis."
            assert res.provider == "claude"

    def test_ollama_backend_unreachable(self):
        backend = OllamaBackend(host="http://localhost:99999")
        res = backend.generate("sys", "user")
        assert res.success is False
        assert "Ollama" in res.error

    def test_ollama_backend_successful_call(self):
        backend = OllamaBackend(host="http://localhost:11434", model="llama3:latest")
        mock_resp_data = {
            "message": {
                "role": "assistant",
                "content": "Here is your local Ollama report.",
            }
        }
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_resp_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response

        with patch("urllib.request.urlopen", return_value=mock_response):
            res = backend.generate("sys", "user")
            assert res.success is True
            assert res.content == "Here is your local Ollama report."
            assert res.provider == "ollama"
