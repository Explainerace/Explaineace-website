"""conftest.py – shared pytest fixtures and path setup."""

import sys
from pathlib import Path

# Ensure the focuslens package root is on PYTHONPATH for pytest
sys.path.insert(0, str(Path(__file__).parent.parent))
