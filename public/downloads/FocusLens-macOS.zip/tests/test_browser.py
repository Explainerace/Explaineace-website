"""
Tests for focuslens.collector.browser – domain extraction logic.
All AppleScript calls are mocked; no real browser is required.
"""

from unittest.mock import patch, MagicMock

import pytest

from focuslens.collector.browser import (
    _extract_domain,
    get_active_browser_domain,
)


class TestExtractDomain:
    def test_simple_https(self):
        assert _extract_domain("https://github.com/user/repo") == "github.com"

    def test_strips_www(self):
        assert _extract_domain("https://www.google.com/search?q=test") == "google.com"

    def test_path_and_query_ignored(self):
        assert _extract_domain("https://stackoverflow.com/questions/123/title?tab=votes") == "stackoverflow.com"

    def test_http(self):
        assert _extract_domain("http://example.com/path") == "example.com"

    def test_subdomain_preserved(self):
        assert _extract_domain("https://docs.python.org/3/library/") == "docs.python.org"

    def test_port_stripped(self):
        assert _extract_domain("http://localhost:8501/dashboard") == "localhost"

    def test_empty_string_returns_none(self):
        assert _extract_domain("") is None

    def test_none_returns_none(self):
        assert _extract_domain(None) is None  # type: ignore

    def test_domain_lowercased(self):
        assert _extract_domain("https://GitHub.COM/user") == "github.com"


class TestGetActiveBrowserDomain:
    def test_non_browser_app_returns_none(self):
        result = get_active_browser_domain("Xcode")
        assert result is None

    def test_none_app_returns_none(self):
        result = get_active_browser_domain(None)
        assert result is None

    def test_safari_domain_extracted(self):
        with patch("focuslens.collector.browser._run_applescript") as mock_as:
            mock_as.return_value = "https://github.com/user/focuslens"
            result = get_active_browser_domain("Safari")
        assert result == "github.com"

    def test_chrome_domain_extracted(self):
        with patch("focuslens.collector.browser._run_applescript") as mock_as:
            mock_as.return_value = "https://www.youtube.com/watch?v=abc"
            result = get_active_browser_domain("Google Chrome")
        assert result == "youtube.com"

    def test_arc_domain_extracted(self):
        with patch("focuslens.collector.browser._run_applescript") as mock_as:
            mock_as.return_value = "https://linear.app/team/issues"
            result = get_active_browser_domain("Arc")
        assert result == "linear.app"

    def test_empty_applescript_response_returns_none(self):
        with patch("focuslens.collector.browser._run_applescript") as mock_as:
            mock_as.return_value = ""
            result = get_active_browser_domain("Safari")
        assert result is None

    def test_applescript_failure_returns_none(self):
        with patch("focuslens.collector.browser._run_applescript") as mock_as:
            mock_as.return_value = None
            result = get_active_browser_domain("Safari")
        assert result is None
