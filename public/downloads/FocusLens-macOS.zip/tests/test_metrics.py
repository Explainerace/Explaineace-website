"""
Tests for focuslens.metrics – categorizer, engine, models.

All tests use synthetic in-memory sample data (no DB, no macOS APIs).
"""

from __future__ import annotations

import math
from datetime import date as Date, datetime
from pathlib import Path
from typing import List

import pytest
import yaml

from focuslens.metrics.categorizer import Categorizer
from focuslens.metrics.engine import (
    MetricsEngine,
    _assign_weights,
    _break_pattern,
    _context_switches,
    _deep_work_blocks,
    _focus_score,
    _Sample,
    MAX_GAP_SECONDS,
    SAMPLE_INTERVAL,
)
from focuslens.metrics.models import DayMetrics, DeepWorkBlock

from tests.fixtures.sample_builder import (
    BASE_TS,
    TEST_DATE_STR,
    distracting_block,
    idle_block,
    locked_block,
    make_row,
    productive_block,
)

TODAY = Date(2024, 3, 4)

# ── Minimal categories config ─────────────────────────────────────────────────

_CAT_DATA = {
    "apps": {
        "Code": "productive",
        "Xcode": "productive",
        "Terminal": "productive",
        "Safari": "neutral",       # neutral unless domain overrides
        "YouTube": "distracting",
        "Messages": "neutral",
        "Slack": "neutral",
    },
    "domains": {
        "github.com": "productive",
        "youtube.com": "distracting",
        "twitter.com": "distracting",
        "reddit.com": "distracting",
        "docs.python.org": "productive",
        "google.com": "neutral",
    },
    "default": "neutral",
}


@pytest.fixture()
def cat(tmp_path) -> Categorizer:
    p = tmp_path / "categories.yaml"
    p.write_text(yaml.dump(_CAT_DATA))
    return Categorizer(config_path=p)


@pytest.fixture()
def engine(cat) -> MetricsEngine:
    return MetricsEngine(categorizer=cat)


# ═══════════════════════════════════════════════════════════════════════
# CATEGORIZER TESTS
# ═══════════════════════════════════════════════════════════════════════

class TestCategorizer:
    def test_productive_app(self, cat):
        assert cat.categorise("Code", None) == "productive"

    def test_distracting_app(self, cat):
        assert cat.categorise("YouTube", None) == "distracting"

    def test_neutral_app(self, cat):
        assert cat.categorise("Messages", None) == "neutral"

    def test_default_unknown_app(self, cat):
        assert cat.categorise("GarageBand", None) == "neutral"

    def test_domain_overrides_neutral_browser_app(self, cat):
        # Safari is neutral by app, but github.com is productive → productive wins
        assert cat.categorise("Safari", "github.com") == "productive"

    def test_domain_distracting_overrides_neutral_browser(self, cat):
        assert cat.categorise("Safari", "youtube.com") == "distracting"

    def test_non_browser_app_ignores_domain(self, cat):
        # "Code" is productive; even if domain says distracting, app wins
        assert cat.categorise("Code", "youtube.com") == "productive"

    def test_none_app_falls_back_to_domain(self, cat):
        assert cat.categorise(None, "reddit.com") == "distracting"

    def test_none_app_none_domain_returns_default(self, cat):
        assert cat.categorise(None, None) == "neutral"

    def test_case_insensitive_app(self, cat):
        assert cat.categorise("code", None) == "productive"
        assert cat.categorise("CODE", None) == "productive"

    def test_case_insensitive_domain(self, cat):
        assert cat.categorise("Safari", "GitHub.com") == "productive"

    def test_overrides_take_priority(self, tmp_path):
        p = tmp_path / "categories.yaml"
        p.write_text(yaml.dump(_CAT_DATA))
        overrides = {"apps": {"Slack": "distracting"}}
        c = Categorizer(config_path=p, overrides=overrides)
        assert c.categorise("Slack", None) == "distracting"

    def test_invalid_category_in_config_ignored(self, tmp_path):
        p = tmp_path / "categories.yaml"
        p.write_text(yaml.dump({"apps": {"BadApp": "unknown_cat"}, "default": "neutral"}))
        c = Categorizer(config_path=p)
        # unknown_cat → not stored; falls through to default
        assert c.categorise("BadApp", None) == "neutral"


# ═══════════════════════════════════════════════════════════════════════
# WEIGHT ASSIGNMENT
# ═══════════════════════════════════════════════════════════════════════

class TestWeightAssignment:
    def _make_samples(self, offsets: list[float]) -> list[_Sample]:
        rows = [make_row(o) for o in offsets]
        return _assign_weights(list(map(_Sample, rows)))

    def test_single_sample_gets_default_weight(self):
        samples = self._make_samples([0])
        assert samples[0].weight == SAMPLE_INTERVAL

    def test_regular_interval_weight(self):
        samples = self._make_samples([0, 3, 6, 9])
        assert all(s.weight == 3.0 for s in samples[:3])

    def test_gap_capped_at_max(self):
        # 120s gap → should be capped at MAX_GAP_SECONDS
        samples = self._make_samples([0, 120])
        assert samples[0].weight == MAX_GAP_SECONDS

    def test_last_sample_gets_interval_weight(self):
        samples = self._make_samples([0, 3, 6])
        assert samples[-1].weight == SAMPLE_INTERVAL


# ═══════════════════════════════════════════════════════════════════════
# FOCUS SCORE
# ═══════════════════════════════════════════════════════════════════════

class TestFocusScore:
    def test_all_productive_no_switches(self):
        # 90+ min deep work, no switches → near-max score
        blocks = [DeepWorkBlock(0, 5400, 90, "Code")]
        score = _focus_score(3600, 3600, blocks, 0)
        assert score > 90

    def test_zero_active_time(self):
        assert _focus_score(0, 0, [], 0) == 0.0

    def test_all_distracting(self):
        score = _focus_score(0, 3600, [], 30)
        assert score == 0.0

    def test_half_productive(self):
        score = _focus_score(1800, 3600, [], 5)
        # base = 0.5 → 25 pts, some switch penalty
        assert 20 < score < 60

    def test_high_switches_penalise_score(self):
        # Same productivity, many switches
        score_low_sw = _focus_score(3000, 3600, [], 2)
        score_high_sw = _focus_score(3000, 3600, [], 18)
        assert score_low_sw > score_high_sw

    def test_deep_work_bonus(self):
        blocks = [DeepWorkBlock(0, 5400, 90, "Code")]
        score_with = _focus_score(3000, 3600, blocks, 5)
        score_without = _focus_score(3000, 3600, [], 5)
        assert score_with > score_without

    def test_score_clamped_0_to_100(self):
        score = _focus_score(9999, 10000, [DeepWorkBlock(0, 9000, 150, "Code")], 0)
        assert 0 <= score <= 100


# ═══════════════════════════════════════════════════════════════════════
# DEEP-WORK BLOCKS
# ═══════════════════════════════════════════════════════════════════════

class TestDeepWorkBlocks:
    def _run(self, rows) -> list[DeepWorkBlock]:
        samples = _assign_weights(list(map(_Sample, rows)))
        cats = ["productive"] * len(samples)
        return _deep_work_blocks(samples, cats)

    def test_no_samples_no_blocks(self):
        assert _deep_work_blocks([], []) == []

    def test_short_block_not_counted(self):
        # 20 minutes < 25-min threshold
        rows = productive_block(0, 20 * 60)
        samples = _assign_weights(list(map(_Sample, rows)))
        cats = ["productive"] * len(samples)
        blocks = _deep_work_blocks(samples, cats)
        assert len(blocks) == 0

    def test_25_min_block_counted(self):
        # Exactly 26 min of productive work
        rows = productive_block(0, 26 * 60)
        samples = _assign_weights(list(map(_Sample, rows)))
        cats = ["productive"] * len(samples)
        blocks = _deep_work_blocks(samples, cats)
        assert len(blocks) == 1
        assert blocks[0].duration_minutes >= 25

    def test_two_separate_blocks(self):
        # 30 min productive, 10 min distracting (breaks block), 30 min productive
        rows = (
            productive_block(0, 30 * 60)
            + distracting_block(30 * 60, 10 * 60)
            + productive_block(40 * 60, 30 * 60)
        )
        samples = _assign_weights(list(map(_Sample, rows)))
        # Assign cats based on rows
        cats: list[str] = []
        for s in samples:
            if s.active_app == "Code":
                cats.append("productive")
            else:
                cats.append("distracting")
        blocks = _deep_work_blocks(samples, cats)
        assert len(blocks) == 2

    def test_block_primary_app(self):
        rows = productive_block(0, 30 * 60, app="Xcode")
        samples = _assign_weights(list(map(_Sample, rows)))
        cats = ["productive"] * len(samples)
        blocks = _deep_work_blocks(samples, cats)
        assert len(blocks) == 1
        assert blocks[0].primary_app == "Xcode"

    def test_idle_gap_within_tolerance_does_not_break_block(self):
        # 30 min productive, 30s idle (< 60s tolerance), 10 min productive
        # The whole thing should count as one block
        rows = (
            productive_block(0, 30 * 60)
            + idle_block(30 * 60, 30)  # 30 seconds idle only
            + productive_block(30 * 60 + 30, 10 * 60)
        )
        samples = _assign_weights(list(map(_Sample, rows)))
        cats: list[str] = []
        for s in samples:
            if s.idle_seconds >= 30:
                cats.append("idle")
            elif s.active_app == "Code":
                cats.append("productive")
            else:
                cats.append("neutral")
        blocks = _deep_work_blocks(samples, cats)
        # Should be 1 merged block, not 2 split ones
        assert len(blocks) == 1


# ═══════════════════════════════════════════════════════════════════════
# CONTEXT SWITCHES
# ═══════════════════════════════════════════════════════════════════════

class TestContextSwitches:
    def _run(self, rows, cats) -> tuple[int, float]:
        samples = _assign_weights(list(map(_Sample, rows)))
        return _context_switches(samples, cats)

    def test_no_samples(self):
        count, per_hr = _context_switches([], [])
        assert count == 0
        assert per_hr == 0.0

    def test_same_app_no_switches(self):
        rows = productive_block(0, 60 * 60)  # 1 hour of same app
        samples = _assign_weights(list(map(_Sample, rows)))
        cats = ["productive"] * len(samples)
        count, per_hr = _context_switches(samples, cats)
        assert count == 0

    def test_one_switch(self):
        rows = (
            productive_block(0, 10 * 60, app="Code")
            + productive_block(10 * 60, 10 * 60, app="Xcode")
        )
        samples = _assign_weights(list(map(_Sample, rows)))
        cats = ["productive"] * len(samples)
        count, _ = _context_switches(samples, cats)
        assert count == 1

    def test_idle_gap_not_counted_as_switch(self):
        rows = (
            productive_block(0, 10 * 60, app="Code")
            + idle_block(10 * 60, 5 * 60)
            + productive_block(15 * 60, 10 * 60, app="Code")
        )
        samples = _assign_weights(list(map(_Sample, rows)))
        cats: list[str] = []
        for s in samples:
            cats.append("idle" if s.idle_seconds >= 30 else "productive")
        count, _ = _context_switches(samples, cats)
        # Returning to same app after idle → no switch
        assert count == 0

    def test_many_rapid_switches(self):
        rows = []
        apps = ["Code", "Slack", "Safari", "Terminal", "Slack"]
        for i, app in enumerate(apps):
            rows += productive_block(i * 5 * 60, 5 * 60, app=app)
        samples = _assign_weights(list(map(_Sample, rows)))
        cats = ["productive"] * len(samples)
        count, per_hr = _context_switches(samples, cats)
        assert count == len(apps) - 1


# ═══════════════════════════════════════════════════════════════════════
# BREAK PATTERN
# ═══════════════════════════════════════════════════════════════════════

class TestBreakPattern:
    def test_no_breaks_in_short_session(self):
        rows = productive_block(0, 20 * 60)
        samples = _assign_weights(list(map(_Sample, rows)))
        cats = ["productive"] * len(samples)
        longest, breaks = _break_pattern(samples, cats)
        assert breaks == 0
        assert longest > 0

    def test_one_break(self):
        rows = (
            productive_block(0, 30 * 60)
            + idle_block(30 * 60, 5 * 60)   # 5 min break ≥ BREAK_MIN_SECONDS (2 min)
            + productive_block(35 * 60, 30 * 60)
        )
        samples = _assign_weights(list(map(_Sample, rows)))
        cats: list[str] = []
        for s in samples:
            cats.append("idle" if s.idle_seconds >= 30 else "productive")
        _, breaks = _break_pattern(samples, cats)
        assert breaks == 1

    def test_very_short_idle_not_a_break(self):
        # 30s idle → below BREAK_MIN_SECONDS (120s) → no break
        rows = (
            productive_block(0, 10 * 60)
            + idle_block(10 * 60, 30)
            + productive_block(10 * 60 + 30, 10 * 60)
        )
        samples = _assign_weights(list(map(_Sample, rows)))
        cats: list[str] = []
        for s in samples:
            cats.append("idle" if s.idle_seconds >= 30 else "productive")
        _, breaks = _break_pattern(samples, cats)
        assert breaks == 0

    def test_two_breaks(self):
        rows = (
            productive_block(0, 30 * 60)
            + idle_block(30 * 60, 5 * 60)
            + productive_block(35 * 60, 30 * 60)
            + idle_block(65 * 60, 5 * 60)
            + productive_block(70 * 60, 30 * 60)
        )
        samples = _assign_weights(list(map(_Sample, rows)))
        cats: list[str] = []
        for s in samples:
            cats.append("idle" if s.idle_seconds >= 30 else "productive")
        _, breaks = _break_pattern(samples, cats)
        assert breaks == 2

    def test_longest_stretch_measured(self):
        # 60 min stretch, then a break, then 20 min stretch
        rows = (
            productive_block(0, 60 * 60)
            + idle_block(60 * 60, 5 * 60)
            + productive_block(65 * 60, 20 * 60)
        )
        samples = _assign_weights(list(map(_Sample, rows)))
        cats: list[str] = []
        for s in samples:
            cats.append("idle" if s.idle_seconds >= 30 else "productive")
        longest, _ = _break_pattern(samples, cats)
        assert longest >= 55   # approximately 60 min


# ═══════════════════════════════════════════════════════════════════════
# FULL DAY METRICS (integration)
# ═══════════════════════════════════════════════════════════════════════

class TestDayMetrics:
    def test_empty_session_returns_zeros(self, engine):
        dm = engine.compute_day(TODAY, [])
        assert dm.productive_seconds == 0
        assert dm.focus_score == 0.0

    def test_all_productive_high_score(self, engine):
        # 2 hours of solid coding, no switches
        rows = productive_block(0, 2 * 3600, app="Code")
        dm = engine.compute_day(TODAY, rows)
        assert dm.productive_seconds > 7100
        assert dm.focus_score > 70
        assert dm.context_switches == 0

    def test_all_distracting_low_score(self, engine):
        rows = distracting_block(0, 2 * 3600, app="Safari", domain="youtube.com")
        dm = engine.compute_day(TODAY, rows)
        assert dm.distracting_seconds > 7100
        # Score: base=0 (0 productive), continuity=0, switch_factor=1.0 (0 switches)
        # → 0*50 + 0*30 + 1.0*20 = 20 pts maximum for all-distracting no-switch session
        assert dm.focus_score <= 25
        assert dm.focus_score < dm.active_seconds / dm.active_seconds * 30  # well below 30

    def test_mixed_session_time_buckets(self, engine):
        # 60 min productive, 30 min distracting, 30 min idle
        rows = (
            productive_block(0, 60 * 60)
            + distracting_block(60 * 60, 30 * 60, domain="youtube.com")
            + idle_block(90 * 60, 30 * 60)
        )
        dm = engine.compute_day(TODAY, rows)
        assert dm.productive_seconds > 0
        assert dm.distracting_seconds > 0
        assert dm.idle_seconds > 0
        total = dm.total_tracked_seconds
        assert abs(total - 2 * 3600) < 60  # within 1 minute

    def test_deep_work_block_detected(self, engine):
        # 30 min solid productive → should detect 1 deep work block
        rows = productive_block(0, 30 * 60, app="Code")
        dm = engine.compute_day(TODAY, rows)
        assert len(dm.deep_work_blocks) == 1
        assert dm.deep_work_blocks[0].duration_minutes >= 25

    def test_no_deep_work_for_short_blocks(self, engine):
        # 10 min, 10 min, 10 min separated by distracting → no deep work
        rows = (
            productive_block(0, 10 * 60)
            + distracting_block(10 * 60, 2 * 60, domain="reddit.com")
            + productive_block(12 * 60, 10 * 60)
            + distracting_block(22 * 60, 2 * 60, domain="reddit.com")
            + productive_block(24 * 60, 10 * 60)
        )
        dm = engine.compute_day(TODAY, rows)
        assert len(dm.deep_work_blocks) == 0

    def test_break_detected_in_long_session(self, engine):
        rows = (
            productive_block(0, 90 * 60)
            + idle_block(90 * 60, 10 * 60)
            + productive_block(100 * 60, 60 * 60)
        )
        dm = engine.compute_day(TODAY, rows)
        assert dm.break_count >= 1

    def test_context_switches_counted(self, engine):
        rows = (
            productive_block(0, 10 * 60, app="Code")
            + productive_block(10 * 60, 10 * 60, app="Terminal")
            + productive_block(20 * 60, 10 * 60, app="Slack")
        )
        dm = engine.compute_day(TODAY, rows)
        assert dm.context_switches >= 2

    def test_top_apps_populated(self, engine):
        rows = (
            productive_block(0, 60 * 60, app="Code")
            + distracting_block(60 * 60, 30 * 60, domain="youtube.com")
        )
        dm = engine.compute_day(TODAY, rows)
        app_names = [a.name for a in dm.top_apps]
        assert "Code" in app_names or "Safari" in app_names

    def test_top_distracting_domains(self, engine):
        rows = distracting_block(0, 30 * 60, domain="youtube.com")
        dm = engine.compute_day(TODAY, rows)
        assert len(dm.top_distracting_domains) == 1
        assert dm.top_distracting_domains[0].domain == "youtube.com"

    def test_hourly_breakdown(self, engine):
        # Data starting at 09:00 → should appear in hour 9
        rows = productive_block(0, 30 * 60, app="Code")  # BASE_TS is 09:00
        dm = engine.compute_day(TODAY, rows)
        hours = {h.hour for h in dm.hourly}
        assert 9 in hours

    def test_best_and_worst_hour(self, engine):
        # Hour 9: all productive; Hour 10: all distracting
        rows = (
            productive_block(0, 60 * 60, app="Code")              # 09:00–10:00
            + distracting_block(3600, 60 * 60, domain="youtube.com")  # 10:00–11:00
        )
        dm = engine.compute_day(TODAY, rows)
        assert dm.best_hour is not None
        assert dm.worst_hour is not None
        assert dm.best_hour != dm.worst_hour

    def test_screen_locked_counted_as_idle(self, engine):
        rows = locked_block(0, 30 * 60)  # 30 min locked screen
        dm = engine.compute_day(TODAY, rows)
        assert dm.idle_seconds > 0
        assert dm.productive_seconds == 0

    def test_focus_score_clamped_0_100(self, engine):
        rows = productive_block(0, 3 * 3600, app="Code")
        dm = engine.compute_day(TODAY, rows)
        assert 0 <= dm.focus_score <= 100

    def test_total_tracked_seconds_plausible(self, engine):
        # 1 hour session
        rows = productive_block(0, 3600, app="Code")
        dm = engine.compute_day(TODAY, rows)
        # Should be close to 3600, not wildly off
        assert 3500 < dm.total_tracked_seconds < 3700


# ═══════════════════════════════════════════════════════════════════════
# WEEK TREND
# ═══════════════════════════════════════════════════════════════════════

class TestWeekTrend:
    def test_avg_focus_score(self, engine):
        from datetime import date, timedelta
        dates = [Date(2024, 3, 4) + timedelta(days=i) for i in range(3)]
        rows_by_date = {
            dates[0]: productive_block(0, 3600),
            dates[1]: distracting_block(0, 3600, domain="youtube.com"),
            dates[2]: [],
        }
        trend = engine.compute_week_trend(dates, rows_by_date)
        assert len(trend.days) == 3
        assert 0 <= trend.avg_focus_score <= 100

    def test_empty_week_returns_zero_avg(self, engine):
        from datetime import date, timedelta
        dates = [Date(2024, 3, 4) + timedelta(days=i) for i in range(7)]
        trend = engine.compute_week_trend(dates, {})
        assert trend.avg_focus_score == 0.0
