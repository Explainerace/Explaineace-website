"""
Tests for focuslens.sync (Cloud Sync Client & Server).
"""

from __future__ import annotations

import json
import threading
import time
from datetime import date
from unittest.mock import MagicMock, patch

import pytest

from focuslens.db.store import Store
from focuslens.sync.client import CloudSyncClient
from focuslens.sync.server import SyncRequestHandler, run_sync_server


@pytest.fixture
def store(tmp_path):
    return Store(tmp_path / "test_sync.db")


def test_client_not_configured_when_no_url(store):
    client = CloudSyncClient(store=store, sync_url="")
    assert not client.is_configured
    ok, count = client.sync_once()
    assert not ok
    assert count == 0


def test_client_sync_successful(store):
    # Insert dummy samples
    sid = store.start_session(time.time())
    store.insert_sample(
        session_id=sid,
        ts=time.time(),
        active_app="Code",
        window_title="sampler.py",
        browser_domain="github.com",
        idle_seconds=0.0,
        screen_locked=False,
        kb_events=10,
        mouse_events=5,
    )

    client = CloudSyncClient(store=store, sync_url="http://localhost:8000")
    assert client.is_configured

    mock_resp = MagicMock()
    mock_resp.status = 200
    mock_resp.__enter__.return_value = mock_resp

    with patch("urllib.request.urlopen", return_value=mock_resp):
        ok, count = client.sync_once()
        assert ok is True
        assert count == 1


def test_sync_server_status_and_sync_endpoints(tmp_path):
    server_store = Store(tmp_path / "server.db")

    # Simulate server handler
    handler_cls = type("TestHandler", (SyncRequestHandler,), {
        "store": server_store,
        "api_key": None,
    })

    # Test GET /api/status logic directly
    assert server_store.row_counts()["samples"] == 0
