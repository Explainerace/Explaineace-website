#!/usr/bin/env bash
# Run the FocusLens menu-bar app
# NOTE: Must be run from Terminal (or any app that has Accessibility permission)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="$SCRIPT_DIR/.venv"

if [ ! -d "$VENV" ]; then
  echo "❌  Virtual environment not found. Run ./setup.sh first."
  exit 1
fi

echo "🔭  Launching FocusLens menu bar..."
echo "     Look for the 🔭 icon in your menu bar"
echo "     Press Ctrl-C here or Quit from the menu to exit"
echo ""

"$VENV/bin/python" -m focuslens.menubar "$@"
