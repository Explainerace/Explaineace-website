#!/usr/bin/env bash
# FocusLens macOS Installer
# Builds and installs FocusLens.app into ~/Applications and creates a Desktop shortcut
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="$SCRIPT_DIR/.venv"
USER_APPS="$HOME/Applications"
DESKTOP="$HOME/Desktop"
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"

echo "============================================================"
echo "          🔭 FocusLens macOS Installer                     "
echo "============================================================"
echo ""

# 1. Check Python
PYTHON=""
for candidate in python3 /usr/bin/python3 /usr/local/bin/python3 /opt/homebrew/bin/python3; do
    if command -v "$candidate" >/dev/null 2>&1; then
        PYTHON="$candidate"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo "❌ Error: Python 3 was not found. Please install Python 3."
    exit 1
fi

echo "✔ Using Python: $PYTHON ($("$PYTHON" -V))"

# 2. Virtual Environment Setup
if [ ! -d "$VENV" ]; then
    echo "📦 Bootstrapping virtual environment..."
    "$PYTHON" -m venv "$VENV"
    "$VENV/bin/pip" install --upgrade pip setuptools wheel
fi

echo "📦 Checking and installing dependencies..."
"$VENV/bin/pip" install -q -r "$SCRIPT_DIR/requirements.txt"

# 3. Build FocusLens.app Bundle
echo "🔨 Building FocusLens.app..."
"$SCRIPT_DIR/scripts/build_app.sh"

# 4. Install into ~/Applications
mkdir -p "$USER_APPS"
TARGET_APP="$USER_APPS/FocusLens.app"

echo "📂 Installing to $TARGET_APP..."
rm -rf "$TARGET_APP"
cp -R "$SCRIPT_DIR/dist/FocusLens.app" "$TARGET_APP"

# 5. Create Desktop Shortcut for easy 1-click launching
DESKTOP_SHORTCUT="$DESKTOP/FocusLens.app"
rm -rf "$DESKTOP_SHORTCUT"
ln -s "$TARGET_APP" "$DESKTOP_SHORTCUT"
echo "✔ Created Desktop shortcut at: $DESKTOP_SHORTCUT"

# 6. Register with macOS LaunchServices (Spotlight & Launchpad recognition)
if [ -f "$LSREGISTER" ]; then
    echo "⚡ Registering with macOS LaunchServices..."
    "$LSREGISTER" -f "$TARGET_APP" 2>/dev/null || true
fi

echo ""
echo "============================================================"
echo "          🎉 FocusLens Successfully Installed!             "
echo "============================================================"
echo ""
echo "You can now launch FocusLens in any of these ways:"
echo "  1. 🖥 Double-click 'FocusLens' on your Desktop"
echo "  2. 🔍 Search 'FocusLens' in Spotlight (Cmd + Space)"
echo "  3. 📁 Open ~/Applications/FocusLens.app"
echo ""
echo "When FocusLens starts:"
echo "  • The 🔭 icon will appear in your top Menu Bar."
echo "  • The native Dashboard Window will open displaying your metrics."
echo ""
echo "🔒 Privacy Reminder:"
echo "  Ensure Accessibility is granted in:"
echo "  System Settings → Privacy & Security → Accessibility"
echo "============================================================"

# Offer to launch right now
read -p "Would you like to launch FocusLens now? (y/N) " -n 1 -r || true
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🚀 Launching FocusLens..."
    open "$TARGET_APP"
fi
