#!/usr/bin/env bash
# FocusLens Uninstaller
set -euo pipefail

USER_APPS="$HOME/Applications/FocusLens.app"
DESKTOP="$HOME/Desktop/FocusLens.app"
DATA_DIR="$HOME/Library/Application Support/FocusLens"

echo "🗑 Uninstalling FocusLens..."

if [ -d "$USER_APPS" ] || [ -L "$USER_APPS" ]; then
    rm -rf "$USER_APPS"
    echo "✔ Removed $USER_APPS"
fi

if [ -L "$DESKTOP" ] || [ -d "$DESKTOP" ]; then
    rm -rf "$DESKTOP"
    echo "✔ Removed $DESKTOP"
fi

read -p "Do you also want to delete all stored tracking data in '$DATA_DIR'? (y/N) " -n 1 -r || true
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    rm -rf "$DATA_DIR"
    echo "✔ Deleted $DATA_DIR"
fi

echo "✅ FocusLens has been uninstalled."
