#!/usr/bin/env bash
# FocusLens – one-shot environment bootstrap
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="$PROJECT_DIR/.venv"

echo "==> Creating virtual environment at $VENV"
python3 -m venv "$VENV"

echo "==> Upgrading pip"
"$VENV/bin/pip" install --upgrade pip --quiet

echo "==> Installing dependencies"
"$VENV/bin/pip" install -r "$PROJECT_DIR/requirements.txt"

# Create the application support directory
APP_SUPPORT="$HOME/Library/Application Support/FocusLens"
mkdir -p "$APP_SUPPORT"
echo "==> Data directory: $APP_SUPPORT"

echo ""
echo "✅  Setup complete."
echo ""
echo "To start the collector:"
echo "   source $VENV/bin/activate"
echo "   python -m focuslens.collector"
echo ""
echo "To run tests:"
echo "   $VENV/bin/pytest tests/ -v"
echo ""
echo "Required macOS permissions (grant before first run):"
echo "  • Accessibility:   System Settings → Privacy & Security → Accessibility"
echo "  • Automation:      System Settings → Privacy & Security → Automation"
