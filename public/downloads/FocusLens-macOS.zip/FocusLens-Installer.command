#!/usr/bin/env bash
# FocusLens macOS 1-Click Installer
# Double-click this file in Finder to automatically install FocusLens
cd "$(dirname "$0")"
chmod +x ./install.sh ./scripts/*.sh 2>/dev/null || true
./install.sh
