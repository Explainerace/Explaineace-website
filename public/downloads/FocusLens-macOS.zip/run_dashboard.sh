#!/usr/bin/env bash
# Run the FocusLens Streamlit dashboard
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="$SCRIPT_DIR/.venv"

if [ ! -d "$VENV" ]; then
  echo "❌  Virtual environment not found. Run ./setup.sh first."
  exit 1
fi

echo "🔭  Starting FocusLens Dashboard..."
echo "     Opening http://localhost:8501"
echo "     Press Ctrl-C to stop"
echo ""

"$VENV/bin/python" -m focuslens.dashboard "$@"
