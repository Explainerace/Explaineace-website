"""
focuslens.collector.permissions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Detect required macOS permissions and guide the user to grant them
instead of crashing.

Permissions checked:
  • Accessibility – needed to read active-app name and window titles via
    CGWindowListCopyWindowInfo / AXUIElement APIs.
  • Automation – needed for AppleScript calls to Safari/Chrome.

We never pop a system dialog without the user's consent; we just detect
and print clear instructions.
"""

from __future__ import annotations

import logging
import subprocess
import sys

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Accessibility
# ---------------------------------------------------------------------------


def has_accessibility() -> bool:
    """
    Return True if this process has been granted Accessibility permission.
    Uses AXIsProcessTrustedWithOptions without prompting.
    """
    try:
        from ApplicationServices import AXIsProcessTrustedWithOptions  # type: ignore
        result = AXIsProcessTrustedWithOptions({"AXTrustedCheckOptionPrompt": False})
        return bool(result)
    except ImportError:
        logger.debug("ApplicationServices not available – skipping AX check")
        return True  # assume ok in non-macOS / test environments


def request_accessibility_prompt() -> None:
    """Trigger the macOS system prompt asking the user to grant Accessibility."""
    try:
        from ApplicationServices import AXIsProcessTrustedWithOptions  # type: ignore
        AXIsProcessTrustedWithOptions({"AXTrustedCheckOptionPrompt": True})
    except ImportError:
        pass


# ---------------------------------------------------------------------------
# Automation (AppleScript access to Safari / Chrome)
# ---------------------------------------------------------------------------

_AUTOMATION_TEST_SCRIPT = 'tell application "System Events" to get name of first process'


def has_automation() -> bool:
    """
    Quick smoke-test: run a benign AppleScript against System Events.
    Returns False if the OS blocks the call (error 1743 / -1743).
    """
    try:
        result = subprocess.run(
            ["osascript", "-e", _AUTOMATION_TEST_SCRIPT],
            capture_output=True,
            text=True,
            timeout=3,
        )
        return result.returncode == 0
    except Exception as exc:
        logger.debug("Automation check failed: %s", exc)
        return False


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

ACCESSIBILITY_INSTRUCTIONS = """
╔══════════════════════════════════════════════════════════════════════╗
║              FocusLens needs Accessibility permission               ║
╠══════════════════════════════════════════════════════════════════════╣
║  Without it, FocusLens cannot read the active app or window title.  ║
║                                                                      ║
║  To grant:                                                           ║
║    1. Open System Settings (⌘ Space → "System Settings")            ║
║    2. Go to  Privacy & Security → Accessibility                      ║
║    3. Click the lock  🔒  and authenticate                           ║
║    4. Toggle ON the entry for "Terminal" (or your Python runtime)    ║
║    5. Re-run FocusLens                                               ║
╚══════════════════════════════════════════════════════════════════════╝
"""

AUTOMATION_INSTRUCTIONS = """
╔══════════════════════════════════════════════════════════════════════╗
║              FocusLens needs Automation permission                  ║
╠══════════════════════════════════════════════════════════════════════╣
║  Without it, browser domain extraction via AppleScript is disabled. ║
║  Tracking will continue; browser domains will be recorded as NULL.  ║
║                                                                      ║
║  To grant:                                                           ║
║    1. Open System Settings                                           ║
║    2. Go to  Privacy & Security → Automation                         ║
║    3. Expand "Terminal" (or your Python runtime)                     ║
║    4. Enable  Safari  and  Google Chrome                             ║
╚══════════════════════════════════════════════════════════════════════╝
"""


class PermissionStatus:
    def __init__(self, accessibility: bool, automation: bool) -> None:
        self.accessibility = accessibility
        self.automation = automation

    @property
    def can_track(self) -> bool:
        """Tracking is possible even without Automation (domain will be NULL)."""
        return self.accessibility

    def __repr__(self) -> str:
        return (
            f"PermissionStatus(accessibility={self.accessibility}, "
            f"automation={self.automation})"
        )


def check_all(prompt_accessibility: bool = False) -> PermissionStatus:
    """
    Check all required permissions.

    Args:
        prompt_accessibility: If True, trigger the macOS system dialog
            asking the user to grant Accessibility. Only do this once,
            on first launch.

    Returns:
        PermissionStatus with booleans for each permission.
    """
    ax = has_accessibility()
    auto = has_automation()

    status = PermissionStatus(accessibility=ax, automation=auto)

    if not ax:
        print(ACCESSIBILITY_INSTRUCTIONS, file=sys.stderr)
        if prompt_accessibility:
            request_accessibility_prompt()

    if not auto:
        print(AUTOMATION_INSTRUCTIONS, file=sys.stderr)
        logger.warning("Automation not granted – browser domain will be NULL")

    return status
