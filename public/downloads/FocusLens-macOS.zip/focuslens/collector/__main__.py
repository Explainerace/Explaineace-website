"""Allow `python -m focuslens.collector` to invoke the CLI."""
from focuslens.collector import main

main()
