"""
focuslens.collector.browser
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Extract the domain of the front-most tab in Safari or Chrome via AppleScript.

Rules:
  • Only the domain (e.g. "github.com") is extracted – never the full URL or path.
  • If the browser is not running, or AppleScript is blocked, returns None silently.
  • Calls are wrapped with a short timeout so they cannot stall the sample loop.
"""

from __future__ import annotations

import logging
import re
import subprocess
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# Timeout for each AppleScript call (seconds)
_AS_TIMEOUT = 2.0

# ── AppleScript templates ──────────────────────────────────────────────────

_SAFARI_SCRIPT = """\
tell application "System Events"
    if (name of processes) contains "Safari" then
        tell application "Safari"
            if (count of windows) > 0 then
                set u to URL of current tab of front window
                return u
            end if
        end tell
    end if
end tell
return ""
"""

_CHROME_SCRIPT = """\
tell application "System Events"
    if (name of processes) contains "Google Chrome" then
        tell application "Google Chrome"
            if (count of windows) > 0 then
                set u to URL of active tab of front window
                return u
            end if
        end tell
    end if
end tell
return ""
"""

_CHROME_CANARY_SCRIPT = """\
tell application "System Events"
    if (name of processes) contains "Google Chrome Canary" then
        tell application "Google Chrome Canary"
            if (count of windows) > 0 then
                set u to URL of active tab of front window
                return u
            end if
        end tell
    end if
end tell
return ""
"""

_ARC_SCRIPT = """\
tell application "System Events"
    if (name of processes) contains "Arc" then
        tell application "Arc"
            if (count of windows) > 0 then
                set u to URL of active tab of front window
                return u
            end if
        end tell
    end if
end tell
return ""
"""

_BRAVE_SCRIPT = """\
tell application "System Events"
    if (name of processes) contains "Brave Browser" then
        tell application "Brave Browser"
            if (count of windows) > 0 then
                set u to URL of active tab of front window
                return u
            end if
        end tell
    end if
end tell
return ""
"""

# Map from app display name → script
_BROWSER_SCRIPTS: dict[str, str] = {
    "Safari": _SAFARI_SCRIPT,
    "Google Chrome": _CHROME_SCRIPT,
    "Google Chrome Canary": _CHROME_CANARY_SCRIPT,
    "Arc": _ARC_SCRIPT,
    "Brave Browser": _BRAVE_SCRIPT,
}


def _run_applescript(script: str) -> str | None:
    """Run an AppleScript and return stdout, or None on error."""
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=_AS_TIMEOUT,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except subprocess.TimeoutExpired:
        logger.debug("AppleScript timed out")
    except Exception as exc:
        logger.debug("AppleScript error: %s", exc)
    return None


def _extract_domain(url: str) -> str | None:
    """
    Parse a URL and return just the registrable domain.

    Examples:
        "https://github.com/user/repo" → "github.com"
        "https://www.google.com/search?q=foo" → "google.com"
    """
    if not url or url.strip() == "":
        return None
    try:
        parsed = urlparse(url)
        host = parsed.netloc or parsed.path
        # Strip www. prefix
        host = re.sub(r"^www\.", "", host, flags=re.IGNORECASE)
        # Strip port
        host = host.split(":")[0].strip()
        if host:
            return host.lower()
    except Exception as exc:
        logger.debug("URL parse error: %s", exc)
    return None


def get_active_browser_domain(active_app: str | None) -> str | None:
    """
    Return the domain of the front tab if the active app is a known browser.

    Args:
        active_app: Display name of the currently active application.

    Returns:
        Domain string (e.g. "github.com") or None if not applicable.
    """
    if not active_app:
        return None

    script = _BROWSER_SCRIPTS.get(active_app)
    if script is None:
        return None  # Not a tracked browser

    raw_url = _run_applescript(script)
    if not raw_url:
        return None

    domain = _extract_domain(raw_url)
    logger.debug("Browser domain: %s (app=%s)", domain, active_app)
    return domain
