"""
focuslens.collector
~~~~~~~~~~~~~~~~~~~~
Main CLI entry point for the Phase 1 collector.

Usage:
    python -m focuslens.collector [--debug] [--db PATH] [--interval SECONDS]

Controls (keyboard, while running):
    q / Ctrl-C  →  stop and exit
    p           →  pause / resume
"""

from __future__ import annotations

import argparse
import logging
import signal
import sys
import threading
import time
from pathlib import Path

# ── Logging setup (must happen before any import that logs) ──────────────────

def _setup_logging(debug: bool) -> None:
    level = logging.DEBUG if debug else logging.INFO
    fmt = "%(asctime)s  %(levelname)-8s  %(name)s – %(message)s"
    logging.basicConfig(level=level, format=fmt, datefmt="%H:%M:%S")


# ── Default DB path ──────────────────────────────────────────────────────────

_DEFAULT_DB = (
    Path.home() / "Library" / "Application Support" / "FocusLens" / "focuslens.db"
)


# ── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="FocusLens collector – Phase 1")
    parser.add_argument("--debug", action="store_true", help="Verbose logging")
    parser.add_argument("--db", default=str(_DEFAULT_DB), help="Path to SQLite DB")
    parser.add_argument(
        "--interval",
        type=float,
        default=None,
        help="Override sample interval (seconds, default 3)"
    )
    args = parser.parse_args()

    _setup_logging(args.debug)
    logger = logging.getLogger("focuslens.collector.__main__")

    # ── Imports (after logging is configured) ────────────────────────────────
    from focuslens.collector.permissions import check_all
    from focuslens.collector.sampler import Blocklist, Sampler, SAMPLE_INTERVAL
    from focuslens.collector.system_stats import SystemStatsCollector
    from focuslens.collector.session import SessionManager
    from focuslens.db.store import Store

    # ── Override interval if requested ───────────────────────────────────────
    if args.interval:
        import focuslens.collector.sampler as _sampler_mod
        _sampler_mod.SAMPLE_INTERVAL = args.interval

    # ── Permissions ──────────────────────────────────────────────────────────
    print("FocusLens v0.1 – Collector")
    print("Checking macOS permissions…")
    perm = check_all(prompt_accessibility=True)

    if not perm.can_track:
        print("\n❌  Cannot start: Accessibility permission is required.", file=sys.stderr)
        print("   See instructions above.", file=sys.stderr)
        sys.exit(1)

    if not perm.automation:
        print("⚠️   Automation not granted – browser domains will not be tracked.")
    else:
        print("✅  All permissions OK")

    # ── Database ─────────────────────────────────────────────────────────────
    db_path = Path(args.db)
    logger.info("Using database: %s", db_path)
    store = Store(db_path)

    # ── Session ───────────────────────────────────────────────────────────────
    mgr = SessionManager(store)
    session = mgr.start(note="CLI session")
    session_id = session.session_id

    # ── Blocklist ─────────────────────────────────────────────────────────────
    blocklist = Blocklist()

    # ── Workers ───────────────────────────────────────────────────────────────
    sampler = Sampler(
        store=store,
        session_id=session_id,
        blocklist=blocklist,
        has_automation=perm.automation,
    )
    stats_collector = SystemStatsCollector(store=store, session_id=session_id)

    sampler_thread = threading.Thread(target=sampler.start, name="sampler", daemon=True)
    stats_thread = threading.Thread(target=stats_collector.start, name="stats", daemon=True)

    # ── Shutdown hook ─────────────────────────────────────────────────────────
    _stop_event = threading.Event()

    def _shutdown(signum=None, frame=None) -> None:
        if _stop_event.is_set():
            return
        _stop_event.set()
        print("\n⏹  Stopping…")
        sampler.stop()
        stats_collector.stop()
        mgr.stop()
        counts = store.row_counts()
        print(f"\n📊  Session {session_id} complete")
        print(f"   Samples collected  : {counts['samples']}")
        print(f"   System stats       : {counts['system_stats']}")
        print(f"   Total sessions     : {counts['sessions']}")

        # ── Insight report ────────────────────────────────────────────────────
        print("\n─────────────────────────────────────────")
        try:
            from datetime import date as _Date
            from focuslens.metrics import MetricsEngine
            from focuslens.insights import InsightEngine

            today_str     = _Date.today().strftime("%Y-%m-%d")
            today_samples = store.fetch_samples_for_day(today_str)
            today_stats   = store.fetch_system_stats_for_day(today_str)

            dm     = MetricsEngine().compute_day(_Date.today(), today_samples)
            report = InsightEngine().analyse(dm, sys_stats=today_stats)

            print(f"  {report.overall_verdict}")
            print(f"  {report.summary}")
            if report.has_enough_data and report.findings:
                print("\n  Top findings:")
                for f in report.sorted_findings():
                    print(f"  {f.emoji}  {f.title}")
                    print(f"     ↳ {f.fix.split('.')[0]}.")
        except Exception as _err:
            logger.debug("Could not generate insight report: %s", _err)
        print("─────────────────────────────────────────")
        store.close()
        print("✅  Done — open dashboard for full analysis:")

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    # ── Start threads ─────────────────────────────────────────────────────────
    sampler_thread.start()
    stats_thread.start()
    print(f"\n▶  Tracking started (session {session_id})")
    print(f"   DB: {db_path}")
    print("   Press Ctrl-C to stop\n")

    # ── Status ticker ─────────────────────────────────────────────────────────
    try:
        while not _stop_event.is_set():
            elapsed = session.elapsed_display()
            counts = store.row_counts()
            print(
                f"\r⏱  {elapsed}  |  samples: {counts['samples']}  "
                f"|  stats: {counts['system_stats']}   ",
                end="",
                flush=True,
            )
            time.sleep(3)
    except KeyboardInterrupt:
        _shutdown()


if __name__ == "__main__":
    main()
