"""
focuslens.collector.sampler
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Core 3-second sample loop.

What it collects per sample:
  • timestamp              – unix float
  • active_app             – frontmost app display name (NSWorkspace)
  • window_title           – front window title (CGWindowList); "<blocked>"
                             if the app or title matches the blocklist
  • browser_domain         – domain of the active browser tab (AppleScript)
  • idle_seconds           – seconds since last keyboard/mouse event
  • screen_locked          – bool: screensaver running or display asleep
  • kb_events              – keyboard event count delta since last sample
  • mouse_events           – mouse event count delta since last sample

Privacy guarantees:
  • Keystroke content is NEVER recorded.
  • Window titles that match the blocklist are stored as "<blocked>".
  • Full browser URLs are NEVER stored (domain extracted server-side in browser.py).
"""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path
from typing import Optional

import yaml

logger = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────────────────────

SAMPLE_INTERVAL = 3.0          # seconds between samples
_BLOCKED_PLACEHOLDER = "<blocked>"

# Default blocklist path (resolved relative to project root)
_DEFAULT_BLOCKLIST = Path(__file__).parents[3] / "config" / "blocklist.yaml"


# ── Blocklist ────────────────────────────────────────────────────────────────

class Blocklist:
    """Load and apply the title/app blocklist."""

    def __init__(self, path: Path = _DEFAULT_BLOCKLIST) -> None:
        self._blocked_apps: list[str] = []
        self._blocked_patterns: list[re.Pattern] = []
        self._load(path)

    def _load(self, path: Path) -> None:
        if not path.exists():
            logger.warning("Blocklist not found at %s – using empty blocklist", path)
            return
        try:
            with open(path) as fh:
                data = yaml.safe_load(fh) or {}
            self._blocked_apps = [
                a.lower() for a in (data.get("blocked_apps") or [])
            ]
            for pattern in data.get("blocked_title_patterns") or []:
                try:
                    self._blocked_patterns.append(
                        re.compile(pattern, re.IGNORECASE)
                    )
                except re.error as exc:
                    logger.warning("Bad blocklist pattern %r: %s", pattern, exc)
            logger.info(
                "Blocklist loaded: %d apps, %d title patterns",
                len(self._blocked_apps),
                len(self._blocked_patterns),
            )
        except Exception as exc:
            logger.error("Failed to load blocklist: %s", exc)

    def is_app_blocked(self, app_name: Optional[str]) -> bool:
        if not app_name:
            return False
        return app_name.lower() in self._blocked_apps

    def is_title_blocked(self, title: Optional[str]) -> bool:
        if not title:
            return False
        return any(p.search(title) for p in self._blocked_patterns)

    def filter_title(self, app_name: Optional[str], title: Optional[str]) -> Optional[str]:
        """Return the title, or _BLOCKED_PLACEHOLDER if it should be hidden."""
        if self.is_app_blocked(app_name) or self.is_title_blocked(title):
            return _BLOCKED_PLACEHOLDER
        return title


# ── macOS API helpers ────────────────────────────────────────────────────────

def _get_active_app() -> Optional[str]:
    """Return the display name of the frontmost application."""
    try:
        from AppKit import NSWorkspace  # type: ignore
        ws = NSWorkspace.sharedWorkspace()
        app = ws.frontmostApplication()
        if app:
            return app.localizedName()
    except Exception as exc:
        logger.debug("active_app error: %s", exc)
    return None


def _get_front_window_title() -> Optional[str]:
    """
    Return the title of the front window via CGWindowListCopyWindowInfo.
    This requires Accessibility or Screen Recording permission on macOS 10.15+.
    """
    try:
        import Quartz  # type: ignore
        # kCGWindowListOptionOnScreenOnly = 1, kCGNullWindowID = 0
        window_list = Quartz.CGWindowListCopyWindowInfo(
            Quartz.kCGWindowListOptionOnScreenOnly |
            Quartz.kCGWindowListExcludeDesktopElements,
            Quartz.kCGNullWindowID,
        )
        if not window_list:
            return None
        for win in window_list:
            # Layer 0 = normal window layer
            if win.get("kCGWindowLayer", 999) == 0:
                return win.get("kCGWindowName") or win.get("kCGWindowOwnerName")
    except Exception as exc:
        logger.debug("window_title error: %s", exc)
    return None


def _get_idle_seconds() -> float:
    """Seconds since the last keyboard or mouse event (HID idle time)."""
    try:
        import Quartz  # type: ignore
        # kCGEventSourceStateHIDSystemState = 1
        # kCGAnyInputEventType = UINT32_MAX (4294967295)
        idle = Quartz.CGEventSourceSecondsSinceLastEventType(1, 0xFFFFFFFF)
        return float(idle)
    except Exception as exc:
        logger.debug("idle_seconds error: %s", exc)
    return 0.0


def _get_screen_locked() -> bool:
    """
    Return True if the screen is locked or the screensaver is active.
    Uses CGSessionCopyCurrentDictionary (works without special permissions).
    """
    try:
        import Quartz  # type: ignore
        session = Quartz.CGSessionCopyCurrentDictionary()
        if session is None:
            return False
        # CGSSessionScreenIsLocked is set when screen is locked
        locked = session.get("CGSSessionScreenIsLocked", 0)
        screensaver = session.get("com.apple.screensaver.running", 0)
        return bool(locked or screensaver)
    except Exception as exc:
        logger.debug("screen_locked error: %s", exc)
    return False


def _get_event_counts() -> tuple[int, int]:
    """
    Return (keyboard_count, mouse_count) as cumulative event source counters.
    Callers subtract the previous value to get a per-interval delta.
    """
    try:
        import Quartz  # type: ignore
        src_state = 1  # kCGEventSourceStateHIDSystemState
        # kCGEventKeyDown = 10, kCGEventMouseMoved = 5
        # We use counter for all events from the same source
        kb = Quartz.CGEventSourceCounterForEventType(src_state, 10)   # kCGEventKeyDown
        mouse = Quartz.CGEventSourceCounterForEventType(src_state, 5)  # kCGEventMouseMoved
        return int(kb), int(mouse)
    except Exception as exc:
        logger.debug("event_counts error: %s", exc)
    return 0, 0


# ── Sampler class ────────────────────────────────────────────────────────────

class Sampler:
    """
    Collects one activity sample every SAMPLE_INTERVAL seconds.

    Usage::

        sampler = Sampler(store=store, session_id=sid, blocklist=bl, has_automation=True)
        sampler.start()
        ...
        sampler.stop()
    """

    def __init__(
        self,
        store,               # focuslens.db.store.Store
        session_id: int,
        blocklist: Blocklist,
        has_automation: bool = True,
    ) -> None:
        self._store = store
        self._session_id = session_id
        self._blocklist = blocklist
        self._has_automation = has_automation
        self._running = False

        # Previous event counters to compute deltas
        self._prev_kb, self._prev_mouse = _get_event_counts()

    def start(self) -> None:
        """Start the blocking sample loop (call from a dedicated thread)."""
        self._running = True
        logger.info("Sampler started (interval=%.1fs)", SAMPLE_INTERVAL)
        while self._running:
            loop_start = time.monotonic()
            try:
                self._collect_one()
            except Exception as exc:
                logger.error("Sample collection error: %s", exc, exc_info=True)
            elapsed = time.monotonic() - loop_start
            sleep_for = max(0.0, SAMPLE_INTERVAL - elapsed)
            # Sleep in small chunks so stop() can interrupt quickly
            _interruptible_sleep(sleep_for, check=lambda: not self._running)

    def stop(self) -> None:
        self._running = False
        logger.info("Sampler stopped")

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _collect_one(self) -> None:
        ts = time.time()

        active_app = _get_active_app()
        raw_title = _get_front_window_title()
        window_title = self._blocklist.filter_title(active_app, raw_title)

        # Browser domain (only if automation is available and app is a browser)
        browser_domain: Optional[str] = None
        if self._has_automation:
            from focuslens.collector.browser import get_active_browser_domain
            browser_domain = get_active_browser_domain(active_app)

        idle_seconds = _get_idle_seconds()
        screen_locked = _get_screen_locked()

        cur_kb, cur_mouse = _get_event_counts()
        kb_delta = max(0, cur_kb - self._prev_kb)
        mouse_delta = max(0, cur_mouse - self._prev_mouse)
        self._prev_kb = cur_kb
        self._prev_mouse = cur_mouse

        self._store.insert_sample(
            session_id=self._session_id,
            ts=ts,
            active_app=active_app,
            window_title=window_title,
            browser_domain=browser_domain,
            idle_seconds=idle_seconds,
            screen_locked=screen_locked,
            kb_events=kb_delta,
            mouse_events=mouse_delta,
        )

        logger.debug(
            "sample: app=%r title=%r domain=%r idle=%.1fs locked=%s kb+%d ms+%d",
            active_app, window_title, browser_domain,
            idle_seconds, screen_locked, kb_delta, mouse_delta,
        )


def _interruptible_sleep(duration: float, check, step: float = 0.2) -> None:
    """Sleep for `duration` seconds but wake early if `check()` returns True."""
    end = time.monotonic() + duration
    while time.monotonic() < end:
        if check():
            return
        time.sleep(min(step, end - time.monotonic()))
