"""
focuslens.collector.system_stats
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Collects CPU, RAM, battery, and thermal state every 30 seconds.

Thermal state is read from `pmset -g therm` or IOKit (whichever is
available). Falls back to None gracefully.
"""

from __future__ import annotations

import logging
import re
import subprocess
import time
from typing import Optional

import psutil

logger = logging.getLogger(__name__)

STATS_INTERVAL = 30.0  # seconds


# ── Thermal state ────────────────────────────────────────────────────────────

def _thermal_state_pmset() -> Optional[str]:
    """
    Parse `pmset -g therm` output.

    Returns one of: "nominal", "fair", "serious", "critical", or None.
    """
    try:
        result = subprocess.run(
            ["pmset", "-g", "therm"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        output = result.stdout
        # Look for "CPU_Scheduler_Limit" or "CPU_Speed_Limit" to judge throttle
        # pmset outputs lines like:
        #   CPU_Scheduler_Limit     = 100
        #   CPU_Available_CPUs      = 8
        #   CPU_Speed_Limit         = 100
        scheduler = re.search(r"CPU_Scheduler_Limit\s*=\s*(\d+)", output)
        speed = re.search(r"CPU_Speed_Limit\s*=\s*(\d+)", output)

        s_val = int(scheduler.group(1)) if scheduler else 100
        sp_val = int(speed.group(1)) if speed else 100
        min_val = min(s_val, sp_val)

        if min_val >= 95:
            return "nominal"
        elif min_val >= 70:
            return "fair"
        elif min_val >= 40:
            return "serious"
        else:
            return "critical"
    except Exception as exc:
        logger.debug("pmset thermal error: %s", exc)
    return None


def _thermal_state_iokit() -> Optional[str]:
    """
    Try to read thermalLevel from IOKit (macOS 12+).
    Returns one of: "nominal", "fair", "serious", "critical", or None.
    """
    try:
        import objc  # type: ignore  # noqa: F401
        import Foundation  # type: ignore  # noqa: F401
        # The IOKit thermal notification is complex; skip for now and rely on pmset.
    except ImportError:
        pass
    return None


def get_thermal_state() -> Optional[str]:
    """Return the current thermal state string, or None if unavailable."""
    state = _thermal_state_pmset()
    if state is None:
        state = _thermal_state_iokit()
    return state


# ── Collector ────────────────────────────────────────────────────────────────

class SystemStatsCollector:
    """
    Collects CPU/RAM/battery/thermal every STATS_INTERVAL seconds.

    Usage::

        collector = SystemStatsCollector(store=store, session_id=sid)
        collector.start()   # blocking; call from a dedicated thread
        collector.stop()
    """

    def __init__(self, store, session_id: int) -> None:
        self._store = store
        self._session_id = session_id
        self._running = False

    def start(self) -> None:
        self._running = True
        logger.info("SystemStatsCollector started (interval=%.0fs)", STATS_INTERVAL)
        while self._running:
            loop_start = time.monotonic()
            try:
                self._collect_one()
            except Exception as exc:
                logger.error("system_stats collection error: %s", exc, exc_info=True)
            elapsed = time.monotonic() - loop_start
            sleep_for = max(0.0, STATS_INTERVAL - elapsed)
            _interruptible_sleep(sleep_for, check=lambda: not self._running)

    def stop(self) -> None:
        self._running = False
        logger.info("SystemStatsCollector stopped")

    def _collect_one(self) -> None:
        ts = time.time()

        # CPU – non-blocking (interval=None → instant reading since last call)
        cpu_pct: Optional[float] = None
        try:
            cpu_pct = psutil.cpu_percent(interval=None)
        except Exception as exc:
            logger.debug("cpu_pct error: %s", exc)

        # RAM
        ram_pct: Optional[float] = None
        try:
            ram_pct = psutil.virtual_memory().percent
        except Exception as exc:
            logger.debug("ram_pct error: %s", exc)

        # Battery
        battery_pct: Optional[float] = None
        try:
            batt = psutil.sensors_battery()
            if batt is not None:
                battery_pct = batt.percent
        except Exception as exc:
            logger.debug("battery_pct error: %s", exc)

        # Thermal
        thermal_state = get_thermal_state()

        self._store.insert_system_stat(
            session_id=self._session_id,
            ts=ts,
            cpu_pct=cpu_pct,
            ram_pct=ram_pct,
            battery_pct=battery_pct,
            thermal_state=thermal_state,
        )

        logger.debug(
            "system_stat: cpu=%.1f%% ram=%.1f%% batt=%s thermal=%s",
            cpu_pct or 0,
            ram_pct or 0,
            f"{battery_pct:.0f}%" if battery_pct is not None else "N/A",
            thermal_state or "N/A",
        )


def _interruptible_sleep(duration: float, check, step: float = 0.5) -> None:
    end = time.monotonic() + duration
    while time.monotonic() < end:
        if check():
            return
        time.sleep(min(step, end - time.monotonic()))
