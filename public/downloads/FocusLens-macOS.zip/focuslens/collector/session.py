"""
focuslens.collector.session
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Session lifecycle helpers: create, pause, resume, stop.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

logger = logging.getLogger(__name__)


class SessionState(Enum):
    IDLE = auto()
    RUNNING = auto()
    PAUSED = auto()
    STOPPED = auto()


@dataclass
class SessionInfo:
    session_id: int
    started_at: float
    state: SessionState = SessionState.RUNNING
    paused_at: Optional[float] = None
    total_paused_seconds: float = 0.0

    def elapsed_seconds(self) -> float:
        """Effective tracked time (excluding pauses)."""
        now = time.time()
        if self.state == SessionState.PAUSED:
            pause_so_far = (self.paused_at or now) - (self.paused_at or now)
            return (now - self.started_at) - self.total_paused_seconds - pause_so_far
        return (now - self.started_at) - self.total_paused_seconds

    def elapsed_display(self) -> str:
        """Format elapsed time as HH:MM:SS."""
        secs = int(self.elapsed_seconds())
        h, rem = divmod(secs, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"


class SessionManager:
    """Manages the lifecycle of a FocusLens tracking session."""

    def __init__(self, store) -> None:
        self._store = store
        self._current: Optional[SessionInfo] = None

    @property
    def current(self) -> Optional[SessionInfo]:
        return self._current

    @property
    def state(self) -> SessionState:
        return self._current.state if self._current else SessionState.IDLE

    def start(self, note: str = "") -> SessionInfo:
        if self._current and self._current.state == SessionState.RUNNING:
            raise RuntimeError("Session already running")
        now = time.time()
        session_id = self._store.start_session(now, note=note)
        self._current = SessionInfo(session_id=session_id, started_at=now)
        logger.info("Session %d started", session_id)
        return self._current

    def pause(self) -> None:
        if not self._current or self._current.state != SessionState.RUNNING:
            return
        self._current.state = SessionState.PAUSED
        self._current.paused_at = time.time()
        logger.info("Session %d paused", self._current.session_id)

    def resume(self) -> None:
        if not self._current or self._current.state != SessionState.PAUSED:
            return
        paused_duration = time.time() - (self._current.paused_at or time.time())
        self._current.total_paused_seconds += paused_duration
        self._current.paused_at = None
        self._current.state = SessionState.RUNNING
        logger.info("Session %d resumed (paused %.0fs)", self._current.session_id, paused_duration)

    def stop(self) -> Optional[SessionInfo]:
        if not self._current:
            return None
        if self._current.state == SessionState.PAUSED:
            self.resume()
        now = time.time()
        self._store.stop_session(self._current.session_id, now)
        self._current.state = SessionState.STOPPED
        info = self._current
        self._current = None
        logger.info(
            "Session %d stopped. Tracked %.0fs",
            info.session_id,
            info.elapsed_seconds(),
        )
        return info
