"""
focuslens.insights.engine
~~~~~~~~~~~~~~~~~~~~~~~~~~
Rule-based productivity diagnosis engine.

Usage::

    from focuslens.insights import InsightEngine
    from focuslens.metrics import MetricsEngine

    dm  = MetricsEngine().compute_day(today, raw_samples)
    report = InsightEngine().analyse(dm, sys_stats=sys_stat_rows)
    for finding in report.sorted_findings():
        print(finding.emoji, finding.title, "→", finding.fix)

─────────────────────────────────────────────────────────────────────────────
RULES  (evaluated in priority order)
─────────────────────────────────────────────────────────────────────────────

  NEGATIVE findings  (critical / warning / info)
  ───────────────────────────────────────────────
  1. fragmented_attention   – context switches/hr > threshold
  2. fatigue_risk           – longest stretch without a break > threshold
  3. distracting_time       – distracting % of active time > threshold
  4. no_deep_work           – 0 deep-work blocks in a long enough session
  5. shallow_blocks         – deepest focus block < 40 min
  6. low_productive_time    – productive % of active time < threshold
  7. machine_bottleneck     – thermal "serious" or "critical" during work
  8. high_cpu               – avg CPU > 80 % during active time

  POSITIVE findings  (shown 1-2 at most)
  ───────────────────────────────────────
  9.  strong_focus          – focus_score ≥ 75
  10. deep_work_champion    – deep_work_minutes ≥ 90
  11. great_break_habits    – ≥ 2 breaks AND longest_stretch < 90 min
  12. productive_majority   – productive_pct ≥ 60 %

─────────────────────────────────────────────────────────────────────────────
REPORT ASSEMBLY
─────────────────────────────────────────────────────────────────────────────
The engine fires all rules, collects findings, then:
  • Selects up to MAX_NEGATIVES  (default 4) negative findings by priority.
  • Appends up to MAX_POSITIVES  (default 2) positive findings.
  • Generates a 2-3 sentence plain-English summary.
  • Assigns an overall verdict emoji + label.

Minimum data requirement: at least MIN_TRACKED_MINUTES (30) of active time.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date as Date
from typing import Callable, Optional

from focuslens.dashboard.helpers import fmt_seconds
from focuslens.insights.models import DailyReport, Finding
from focuslens.metrics.models import DayMetrics

logger = logging.getLogger(__name__)

# ── Tuneable constants ────────────────────────────────────────────────────────

MIN_TRACKED_MINUTES = 30       # skip analysis if session is very short
MAX_NEGATIVES = 4              # max negative findings shown
MAX_POSITIVES = 2              # max positive findings shown

# Rule thresholds
SWITCH_CRITICAL  = 30          # context switches / hr
SWITCH_WARNING   = 20
STRETCH_CRITICAL = 180         # minutes without break (3 h)
STRETCH_WARNING  = 90          # minutes without break (1.5 h)
DISTRACT_CRITICAL = 35         # % of active time
DISTRACT_WARNING  = 20
PRODUCTIVE_WARNING = 30        # % of active time (low productive threshold)
NO_DW_THRESHOLD   = 60        # min active minutes before flagging no deep work
SHALLOW_DW_MINUTES = 40       # deep-work block shorter than this → shallow
THERMAL_BAD = frozenset({"serious", "critical"})
CPU_HIGH_PCT = 80.0

# Positive thresholds
SCORE_POSITIVE    = 75.0
DEEP_CHAMPION_MIN = 90         # minutes of deep work
GOOD_BREAK_MIN    = 2          # number of breaks
PRODUCTIVE_POSITIVE = 60       # % productive


# ── Rule descriptor ───────────────────────────────────────────────────────────

@dataclass
class _Rule:
    id:        str
    # Returns "critical"/"warning"/"info"/"positive"/None
    severity_fn: Callable[[DayMetrics, list], Optional[str]]
    title_fn:    Callable[[DayMetrics], str]
    detail_fn:   Callable[[DayMetrics], str]
    fix:         str
    metric:      str
    value_fn:    Callable[[DayMetrics], str]
    is_positive: bool = False


# ── Rule definitions ──────────────────────────────────────────────────────────

def _pct(num: float, denom: float) -> float:
    return num / denom * 100 if denom > 0 else 0.0


def _thermal_worst(sys_stats: list[tuple]) -> Optional[str]:
    """Return the worst thermal state seen in sys_stats rows."""
    order = {"nominal": 0, "fair": 1, "serious": 2, "critical": 3}
    worst = None
    worst_rank = -1
    for row in sys_stats:
        state = row[4] if len(row) > 4 else None
        if state and order.get(state, -1) > worst_rank:
            worst = state
            worst_rank = order[state]
    return worst


def _avg_cpu(sys_stats: list[tuple]) -> float:
    values = [row[1] for row in sys_stats if row[1] is not None]
    return sum(values) / len(values) if values else 0.0


_RULES: list[_Rule] = [

    # ── 1. Fragmented attention ───────────────────────────────────────────────
    _Rule(
        id="fragmented_attention",
        severity_fn=lambda dm, _: (
            "critical" if dm.context_switches_per_hour > SWITCH_CRITICAL else
            "warning"  if dm.context_switches_per_hour > SWITCH_WARNING  else None
        ),
        title_fn=lambda dm: "Fragmented attention",
        detail_fn=lambda dm: (
            f"You switched apps {dm.context_switches_per_hour:.0f} times per active hour "
            f"({dm.context_switches} total). Each switch costs ~23 min of refocus time."
        ),
        fix=(
            "Use a single app per focus block. Batch email/Slack to fixed slots (e.g. 9 am, 1 pm, 5 pm). "
            "Try a site/app blocker like Freedom or Cold Turkey during focus sessions."
        ),
        metric="Switches / hr",
        value_fn=lambda dm: f"{dm.context_switches_per_hour:.1f}",
    ),

    # ── 2. Fatigue risk (no break) ────────────────────────────────────────────
    _Rule(
        id="fatigue_risk",
        severity_fn=lambda dm, _: (
            "critical" if dm.longest_stretch_minutes > STRETCH_CRITICAL else
            "warning"  if dm.longest_stretch_minutes > STRETCH_WARNING  else None
        ),
        title_fn=lambda dm: "Fatigue risk — no break taken",
        detail_fn=lambda dm: (
            f"Your longest uninterrupted stretch was {dm.longest_stretch_minutes:.0f} min "
            f"({dm.break_count} break(s) total). "
            "After 90 min of focused work, cognitive performance drops measurably."
        ),
        fix=(
            "Set a repeating 25-min or 52-min timer. Use the 20-20-20 rule (every 20 min, "
            "look 20 ft away for 20 s). Stand up and walk even for 2 min."
        ),
        metric="Longest stretch",
        value_fn=lambda dm: f"{dm.longest_stretch_minutes:.0f} min",
    ),

    # ── 3. Distracting time ───────────────────────────────────────────────────
    _Rule(
        id="distracting_time",
        severity_fn=lambda dm, _: (
            None if dm.active_seconds < 1800 else
            "critical" if _pct(dm.distracting_seconds, dm.active_seconds) > DISTRACT_CRITICAL else
            "warning"  if _pct(dm.distracting_seconds, dm.active_seconds) > DISTRACT_WARNING  else None
        ),
        title_fn=lambda dm: "High distracting-site usage",
        detail_fn=lambda dm: (
            f"{_pct(dm.distracting_seconds, dm.active_seconds):.0f}% of your active time "
            f"({fmt_seconds(dm.distracting_seconds)}) went to distracting content. "
            + (
                f"Top offenders: {', '.join(d.domain for d in dm.top_distracting_domains[:3])}."
                if dm.top_distracting_domains else ""
            )
        ),
        fix=(
            "Block your top distracting sites during work hours. "
            "Schedule a deliberate 'break window' (e.g. 15 min after lunch) for guilt-free browsing "
            "so you don't resist it all day."
        ),
        metric="Distracting time",
        value_fn=lambda dm: f"{_pct(dm.distracting_seconds, dm.active_seconds):.0f}% of active",
    ),

    # ── 4. No deep work ───────────────────────────────────────────────────────
    _Rule(
        id="no_deep_work",
        severity_fn=lambda dm, _: (
            None if dm.active_seconds < NO_DW_THRESHOLD * 60 else
            "warning" if len(dm.deep_work_blocks) == 0 else None
        ),
        title_fn=lambda dm: "No deep-work blocks",
        detail_fn=lambda dm: (
            f"Despite {fmt_seconds(dm.active_seconds)} of active time, "
            "you had zero uninterrupted 25-min productive blocks. "
            "Without deep work, complex tasks don't get done — only shallow, reactive work does."
        ),
        fix=(
            "Protect a 90-min morning block before email or Slack. "
            "Turn off all notifications, close irrelevant tabs, "
            "and put your phone in another room."
        ),
        metric="Deep-work blocks",
        value_fn=lambda dm: "0 blocks",
    ),

    # ── 5. Shallow work only (blocks exist but are short) ────────────────────
    _Rule(
        id="shallow_blocks",
        severity_fn=lambda dm, _: (
            None if not dm.deep_work_blocks else
            "info" if max(b.duration_minutes for b in dm.deep_work_blocks) < SHALLOW_DW_MINUTES else None
        ),
        title_fn=lambda dm: "Only short focus blocks",
        detail_fn=lambda dm: (
            f"Your longest deep-work block was only "
            f"{max(b.duration_minutes for b in dm.deep_work_blocks):.0f} min. "
            "Meaningful work on hard problems typically requires 60-90 min of sustained focus."
        ),
        fix=(
            "Aim to extend your longest block progressively: add 10 min each day "
            "until you can sustain 90 min. Use a visual timer to build the habit."
        ),
        metric="Longest focus block",
        value_fn=lambda dm: f"{max(b.duration_minutes for b in dm.deep_work_blocks):.0f} min",
    ),

    # ── 6. Low productive time ────────────────────────────────────────────────
    _Rule(
        id="low_productive_time",
        severity_fn=lambda dm, _: (
            None if dm.active_seconds < 3600 else
            "warning" if _pct(dm.productive_seconds, dm.active_seconds) < PRODUCTIVE_WARNING else None
        ),
        title_fn=lambda dm: "Low productive-app usage",
        detail_fn=lambda dm: (
            f"Only {_pct(dm.productive_seconds, dm.active_seconds):.0f}% of your active time "
            f"({fmt_seconds(dm.productive_seconds)}) was in apps categorised as productive. "
            "Check that your work apps are listed in config/categories.yaml."
        ),
        fix=(
            "Review config/categories.yaml and add any missing work apps. "
            "If the categorisation is correct, plan your first hour around deep work tasks "
            "before switching to communication tools."
        ),
        metric="Productive time",
        value_fn=lambda dm: f"{_pct(dm.productive_seconds, dm.active_seconds):.0f}% of active",
    ),

    # ── 7. Machine bottleneck (thermal) ───────────────────────────────────────
    _Rule(
        id="machine_bottleneck",
        severity_fn=lambda dm, sys_stats: (
            "warning" if _thermal_worst(sys_stats) in THERMAL_BAD else None
        ),
        title_fn=lambda dm: "Mac is thermally throttled",
        detail_fn=lambda dm: (
            "Your Mac hit a 'serious' or 'critical' thermal state today, "
            "causing the CPU to slow down. This directly reduces your app's responsiveness "
            "and your own patience."
        ),
        fix=(
            "Close background apps and browser tabs you're not using. "
            "Check Activity Monitor → CPU for runaway processes. "
            "Work on a hard flat surface or use a laptop stand with a fan."
        ),
        metric="Thermal state",
        value_fn=lambda dm: "throttled",
    ),

    # ── 8. High average CPU ───────────────────────────────────────────────────
    _Rule(
        id="high_cpu",
        severity_fn=lambda dm, sys_stats: (
            "info" if dm.active_seconds > 1800 and _avg_cpu(sys_stats) > CPU_HIGH_PCT else None
        ),
        title_fn=lambda dm: "Consistently high CPU usage",
        detail_fn=lambda dm: (
            f"Average CPU usage was above {CPU_HIGH_PCT:.0f}% throughout your session. "
            "This drains battery faster and generates more heat, which can affect focus."
        ),
        fix=(
            "Open Activity Monitor and identify the top CPU consumer. "
            "Common culprits: browser tabs with video, Spotlight indexing, antivirus scans, "
            "or a runaway build process."
        ),
        metric="Avg CPU",
        value_fn=lambda dm: f">{CPU_HIGH_PCT:.0f}%",
    ),

    # ── 9. Strong focus score (positive) ─────────────────────────────────────
    _Rule(
        id="strong_focus",
        is_positive=True,
        severity_fn=lambda dm, _: (
            "positive" if dm.focus_score >= SCORE_POSITIVE and dm.active_seconds >= 1800 else None
        ),
        title_fn=lambda dm: "Strong focus session",
        detail_fn=lambda dm: (
            f"Focus score of {dm.focus_score:.0f}/100 — you spent most of your active time "
            f"productively with minimal fragmentation."
        ),
        fix="Keep it up. Protect this routine tomorrow.",
        metric="Focus score",
        value_fn=lambda dm: f"{dm.focus_score:.0f} / 100",
    ),

    # ── 10. Deep work champion (positive) ────────────────────────────────────
    _Rule(
        id="deep_work_champion",
        is_positive=True,
        severity_fn=lambda dm, _: (
            "positive" if dm.deep_work_minutes >= DEEP_CHAMPION_MIN else None
        ),
        title_fn=lambda dm: "Deep-work champion",
        detail_fn=lambda dm: (
            f"{dm.deep_work_minutes:.0f} min of deep work across "
            f"{len(dm.deep_work_blocks)} block(s). "
            "That's where real, cognitively demanding progress gets made."
        ),
        fix="Note what conditions made this possible — replicate them tomorrow.",
        metric="Deep work",
        value_fn=lambda dm: f"{dm.deep_work_minutes:.0f} min",
    ),

    # ── 11. Good break habits (positive) ─────────────────────────────────────
    _Rule(
        id="great_break_habits",
        is_positive=True,
        severity_fn=lambda dm, _: (
            "positive"
            if dm.break_count >= GOOD_BREAK_MIN and dm.longest_stretch_minutes <= STRETCH_WARNING
            else None
        ),
        title_fn=lambda dm: "Good break rhythm",
        detail_fn=lambda dm: (
            f"{dm.break_count} break(s) taken, longest stretch {dm.longest_stretch_minutes:.0f} min. "
            "Regular breaks improve sustained concentration and reduce errors."
        ),
        fix="Keep scheduling breaks before you feel tired, not after.",
        metric="Breaks",
        value_fn=lambda dm: f"{dm.break_count} breaks",
    ),

    # ── 12. Productive majority (positive) ───────────────────────────────────
    _Rule(
        id="productive_majority",
        is_positive=True,
        severity_fn=lambda dm, _: (
            "positive"
            if (dm.active_seconds > 1800
                and _pct(dm.productive_seconds, dm.active_seconds) >= PRODUCTIVE_POSITIVE)
            else None
        ),
        title_fn=lambda dm: "Predominantly productive",
        detail_fn=lambda dm: (
            f"{_pct(dm.productive_seconds, dm.active_seconds):.0f}% of your active screen time "
            f"({fmt_seconds(dm.productive_seconds)}) was in productive apps."
        ),
        fix="Pair this habit with scheduled deep-work blocks for maximum output.",
        metric="Productive time",
        value_fn=lambda dm: f"{_pct(dm.productive_seconds, dm.active_seconds):.0f}% of active",
    ),
]


# ── Verdict generator ─────────────────────────────────────────────────────────

def _verdict(score: float, n_critical: int, n_warning: int, n_positive: int) -> str:
    if n_critical >= 2:
        return "🔴 Rough day"
    if n_critical == 1:
        return "🟠 Challenging day"
    if n_warning >= 3:
        return "🟡 Below potential"
    if n_warning == 0 and score >= 75:
        return "🌟 Excellent day"
    if score >= 60:
        return "👍 Good day"
    if score >= 40:
        return "😐 Average day"
    return "🟡 Room to improve"


def _summary(dm: DayMetrics, findings: list[Finding]) -> str:
    """Generate a 2-3 sentence plain-English summary."""
    negatives = [f for f in findings if f.severity in ("critical", "warning")]
    positives  = [f for f in findings if f.severity == "positive"]

    pct_prod = _pct(dm.productive_seconds, dm.active_seconds)

    # Opening sentence
    if dm.focus_score >= 75:
        opener = f"Strong day — focus score {dm.focus_score:.0f}/100."
    elif dm.focus_score >= 50:
        opener = f"Decent day with a focus score of {dm.focus_score:.0f}/100."
    elif dm.focus_score > 0:
        opener = f"Tough day — focus score {dm.focus_score:.0f}/100."
    else:
        opener = "Insufficient data for a full assessment."

    # Body (biggest issue)
    body = ""
    if negatives:
        top = negatives[0]
        body = f" Main concern: {top.title.lower()} ({top.value}). {top.fix.split('.')[0]}."
    elif pct_prod >= 60:
        body = (
            f" You spent {pct_prod:.0f}% of your active time productively"
            + (
                f" with {fmt_seconds(dm.deep_work_minutes * 60)} of deep work."
                if dm.deep_work_minutes > 0 else "."
            )
        )

    # Positive tail
    tail = ""
    if positives and negatives:
        tail = f" Bright spot: {positives[0].title.lower()}."

    return opener + body + tail


# ── Engine ────────────────────────────────────────────────────────────────────

class InsightEngine:
    """
    Analyses a DayMetrics + optional system_stats rows and returns a DailyReport.

    Args:
        rules: Override the default rule list (useful for testing).
    """

    def __init__(self, rules: Optional[list[_Rule]] = None) -> None:
        self._rules = rules if rules is not None else _RULES

    def analyse(
        self,
        dm: DayMetrics,
        sys_stats: Optional[list[tuple]] = None,
    ) -> DailyReport:
        """
        Run all rules against DayMetrics and return a DailyReport.

        Args:
            dm:        Pre-computed day metrics.
            sys_stats: Optional system_stats rows for the same day
                       (ts, cpu_pct, ram_pct, battery_pct, thermal_state).
        """
        sys_stats = sys_stats or []

        if dm.active_seconds < MIN_TRACKED_MINUTES * 60:
            return DailyReport(
                date=dm.date,
                summary=f"Only {fmt_seconds(dm.active_seconds)} of data — track for at least "
                        f"{MIN_TRACKED_MINUTES} min to get insights.",
                overall_verdict="💤 Not enough data",
                score=dm.focus_score,
                has_enough_data=False,
            )

        # ── Fire all rules ────────────────────────────────────────────────────
        raw_findings: list[Finding] = []
        for rule in self._rules:
            try:
                sev = rule.severity_fn(dm, sys_stats)
                if sev is None:
                    continue
                raw_findings.append(
                    Finding(
                        rule_id=rule.id,
                        severity=sev,
                        title=rule.title_fn(dm),
                        detail=rule.detail_fn(dm),
                        fix=rule.fix,
                        metric=rule.metric,
                        value=rule.value_fn(dm),
                    )
                )
            except Exception as exc:
                logger.warning("Rule %s raised: %s", rule.id, exc, exc_info=True)

        # ── Assemble findings ─────────────────────────────────────────────────
        negatives = [f for f in raw_findings if not f.severity == "positive"]
        positives  = [f for f in raw_findings if f.severity == "positive"]

        # Sort negatives: critical > warning > info
        negatives.sort(key=lambda f: -{"critical": 3, "warning": 2, "info": 1}.get(f.severity, 0))
        selected = negatives[:MAX_NEGATIVES] + positives[:MAX_POSITIVES]

        report = DailyReport(
            date=dm.date,
            findings=selected,
            summary=_summary(dm, selected),
            overall_verdict=_verdict(
                dm.focus_score,
                sum(1 for f in selected if f.severity == "critical"),
                sum(1 for f in selected if f.severity == "warning"),
                sum(1 for f in selected if f.severity == "positive"),
            ),
            score=dm.focus_score,
            has_enough_data=True,
        )
        logger.info(
            "Insight report: %s | %d findings (%d crit, %d warn, %d pos)",
            report.overall_verdict,
            len(selected),
            len(report.critical),
            len(report.warnings),
            len(report.positives),
        )
        return report
