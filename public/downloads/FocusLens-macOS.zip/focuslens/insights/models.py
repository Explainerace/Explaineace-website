"""
focuslens.insights.models
~~~~~~~~~~~~~~~~~~~~~~~~~~
Data classes for the insight / diagnosis engine output.

Finding:     one specific issue or praise, with severity, detail, and a fix.
DailyReport: the full diagnosis for one day.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date as Date
from typing import Optional


# ── Severity ordering (lowest → highest) ─────────────────────────────────────

SEVERITY_ORDER = {"positive": 0, "info": 1, "warning": 2, "critical": 3}

SEVERITY_EMOJI = {
    "positive": "✅",
    "info":     "ℹ️",
    "warning":  "⚠️",
    "critical": "🚨",
}

SEVERITY_COLOR = {
    "positive": "#dcfce7",   # green-100
    "info":     "#e0f2fe",   # sky-100
    "warning":  "#fef9c3",   # yellow-100
    "critical": "#fee2e2",   # red-100
}

SEVERITY_BORDER = {
    "positive": "#22c55e",
    "info":     "#0ea5e9",
    "warning":  "#f59e0b",
    "critical": "#ef4444",
}


@dataclass
class Finding:
    """A single diagnosed issue or praise."""
    rule_id:  str           # machine-readable identifier
    severity: str           # "critical" | "warning" | "info" | "positive"
    title:    str           # short headline, e.g. "Fragmented attention"
    detail:   str           # why it was flagged, includes measured values
    fix:      str           # actionable next step
    metric:   str           # metric label shown in the card
    value:    str           # formatted measured value

    @property
    def emoji(self) -> str:
        return SEVERITY_EMOJI.get(self.severity, "•")

    @property
    def bg_color(self) -> str:
        return SEVERITY_COLOR.get(self.severity, "#f8fafc")

    @property
    def border_color(self) -> str:
        return SEVERITY_BORDER.get(self.severity, "#94a3b8")


@dataclass
class DailyReport:
    """Complete productivity diagnosis for one calendar day."""
    date:            Date
    findings:        list[Finding] = field(default_factory=list)
    summary:         str = ""           # 2-3 sentence plain-English summary
    overall_verdict: str = ""           # e.g. "🌟 Excellent day"
    score:           float = 0.0        # focus score (0-100)
    has_enough_data: bool = False       # False when session < MIN_TRACKED

    @property
    def critical(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == "critical"]

    @property
    def warnings(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == "warning"]

    @property
    def positives(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == "positive"]

    @property
    def negatives(self) -> list[Finding]:
        return [f for f in self.findings if f.severity in ("critical", "warning")]

    def sorted_findings(self) -> list[Finding]:
        """Return findings sorted: critical first, then warning, info, positive."""
        return sorted(
            self.findings,
            key=lambda f: -SEVERITY_ORDER.get(f.severity, 0),
        )
