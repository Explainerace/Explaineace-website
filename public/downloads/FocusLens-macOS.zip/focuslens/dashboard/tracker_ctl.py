"""
focuslens.dashboard.tracker_ctl
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Background collector process controller for the Streamlit dashboard.
Allows users to Start, Stop, and check Tracker status directly via UI buttons.
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import psutil

_APP_SUPPORT = Path.home() / "Library" / "Application Support" / "FocusLens"
_PID_FILE = _APP_SUPPORT / "collector.pid"
_PROJECT_ROOT = Path(__file__).parents[2]


def get_collector_pid() -> Optional[int]:
    """Return the running collector PID if active, else None."""
    if not _PID_FILE.exists():
        # Check by process cmdline fallback
        for proc in psutil.process_iter(["pid", "cmdline"]):
            try:
                cmd = proc.info.get("cmdline") or []
                if any("focuslens.collector" in arg for arg in cmd):
                    return proc.info["pid"]
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return None

    try:
        pid = int(_PID_FILE.read_text().strip())
        if psutil.pid_exists(pid):
            proc = psutil.Process(pid)
            cmd = proc.cmdline()
            if any("focuslens.collector" in arg for arg in cmd):
                return pid
    except Exception:
        pass

    _PID_FILE.unlink(missing_ok=True)
    return None


def is_tracker_running() -> bool:
    """Return True if background collector process is active."""
    return get_collector_pid() is not None


def start_tracker() -> tuple[bool, str]:
    """Start the background collector process."""
    if is_tracker_running():
        return True, "Tracker is already running."

    _APP_SUPPORT.mkdir(parents=True, exist_ok=True)

    cmd = [sys.executable, "-m", "focuslens.collector"]
    try:
        proc = subprocess.Popen(
            cmd,
            cwd=str(_PROJECT_ROOT),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        _PID_FILE.write_text(str(proc.pid))
        time.sleep(1.0)
        return True, f"Tracker started (PID: {proc.pid})."
    except Exception as exc:
        return False, f"Failed to start tracker: {exc}"


def stop_tracker() -> tuple[bool, str]:
    """Stop the background collector process cleanly."""
    pid = get_collector_pid()
    if not pid:
        _PID_FILE.unlink(missing_ok=True)
        return True, "Tracker was not running."

    try:
        os.kill(pid, signal.SIGINT)  # Trigger clean shutdown hook
        # Wait up to 3s for termination
        for _ in range(15):
            if not psutil.pid_exists(pid):
                break
            time.sleep(0.2)
        if psutil.pid_exists(pid):
            os.kill(pid, signal.SIGTERM)
        _PID_FILE.unlink(missing_ok=True)
        return True, "Tracker stopped successfully."
    except ProcessLookupError:
        _PID_FILE.unlink(missing_ok=True)
        return True, "Tracker stopped."
    except Exception as exc:
        return False, f"Failed to stop tracker: {exc}"
