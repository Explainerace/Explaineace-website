"""Allow `python -m focuslens.dashboard` invocation."""
from focuslens.dashboard import main
main()
