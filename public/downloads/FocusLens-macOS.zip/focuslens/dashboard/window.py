"""
focuslens.dashboard.window
~~~~~~~~~~~~~~~~~~~~~~~~~~
Native macOS desktop application window for FocusLens Dashboard.
Uses Cocoa (AppKit) and WebKit (WKWebView) to display the Streamlit
analytics dashboard in a standalone, dedicated Mac window.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).parents[2]
_DASHBOARD_APP = Path(__file__).parent / "app.py"


def _ensure_streamlit_running(port: int = 8501) -> subprocess.Popen:
    """Ensure Streamlit daemon is running on the specified port."""
    import urllib.request

    url = f"http://localhost:{port}/_stcore/health"
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=1.0) as resp:
            if resp.status == 200:
                logger.info("Streamlit server already running on port %d", port)
                return None  # Already running
    except Exception:
        pass

    # Launch Streamlit in headless background mode
    logger.info("Starting background Streamlit server on port %d...", port)
    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(_DASHBOARD_APP),
        "--server.headless",
        "true",
        "--browser.gatherUsageStats",
        "false",
        "--server.port",
        str(port),
    ]
    proc = subprocess.Popen(
        cmd,
        cwd=str(_PROJECT_ROOT),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    # Wait up to 8s for it to become ready
    start_time = time.time()
    while time.time() - start_time < 8.0:
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                if resp.status == 200:
                    logger.info("Streamlit server is ready")
                    break
        except Exception:
            time.sleep(0.4)

    return proc


def open_native_dashboard(port: int = 8501) -> None:
    """
    Open the dashboard in a dedicated native macOS Cocoa/WebKit window.
    """
    import AppKit
    import Foundation
    import WebKit

    _ensure_streamlit_running(port=port)

    # Ensure Cocoa application instance exists
    app = AppKit.NSApplication.sharedApplication()
    app.setActivationPolicy_(AppKit.NSApplicationActivationPolicyRegular)

    # Window geometry
    rect = Foundation.NSMakeRect(100, 100, 1200, 820)
    style_mask = (
        AppKit.NSWindowStyleMaskTitled
        | AppKit.NSWindowStyleMaskClosable
        | AppKit.NSWindowStyleMaskMiniaturizable
        | AppKit.NSWindowStyleMaskResizable
    )

    window = AppKit.NSWindow.alloc().initWithContentRect_styleMask_backing_defer_(
        rect, style_mask, AppKit.NSBackingStoreBuffered, False
    )
    window.setTitle_("FocusLens Dashboard")
    window.center()
    window.setMinSize_(Foundation.NSMakeSize(800, 600))

    # Create WebKit configuration
    config = WebKit.WKWebViewConfiguration.alloc().init()

    # Create WKWebView
    web_view = WebKit.WKWebView.alloc().initWithFrame_configuration_(
        window.contentView().bounds(), config
    )
    web_view.setAutoresizingMask_(
        AppKit.NSViewWidthSizable | AppKit.NSViewHeightSizable
    )
    window.contentView().addSubview_(web_view)

    # Load URL
    url = Foundation.NSURL.URLWithString_(f"http://localhost:{port}")
    request = Foundation.NSURLRequest.requestWithURL_(url)
    web_view.loadRequest_(request)

    # Bring window to front
    window.makeKeyAndOrderFront_(None)
    app.activateIgnoringOtherApps_(True)

    logger.info("Native dashboard window displayed")
    app.run()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    open_native_dashboard()
