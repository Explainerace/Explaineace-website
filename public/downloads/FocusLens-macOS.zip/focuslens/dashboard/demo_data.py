"""
focuslens.dashboard.demo_data
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Generates realistic sample telemetry for demonstrating the dashboard
without having to wait hours to collect live data.
"""

from __future__ import annotations

from datetime import date as Date, datetime, timedelta
import random
from focuslens.db.store import Store


def inject_demo_day(store: Store, target_date: Date) -> int:
    """
    Inject a realistic 8-hour workday of telemetry for the given date.
    Returns the total number of samples inserted.
    """
    base_dt = datetime(target_date.year, target_date.month, target_date.day, 9, 0, 0)
    session_id = store.start_session(base_dt.timestamp(), note="Demo Workday Session")

    # Schedule schedule segments: (duration_min, app, title, domain, idle_sec, locked)
    schedule = [
        # 09:00 - 10:15: Deep Work (Coding)
        (75, "Code", "focuslens/collector/sampler.py", "github.com", 0.0, 0),
        # 10:15 - 10:25: Morning Break
        (10, None, None, None, 180.0, 0),
        # 10:25 - 11:45: Deep Work (Xcode & Terminal)
        (45, "Xcode", "FocusLens.xcodeproj", None, 0.0, 0),
        (35, "Terminal", "zsh - cargo test", None, 0.0, 0),
        # 11:45 - 12:15: Team Communication (Neutral)
        (30, "Slack", "#engineering", None, 2.0, 0),
        # 12:15 - 13:00: Lunch (Idle / Screen Locked)
        (45, None, None, None, 300.0, 1),
        # 13:00 - 14:15: Deep Work (Python Architecture)
        (75, "Code", "focuslens/metrics/engine.py", "docs.python.org", 0.0, 0),
        # 14:15 - 14:45: Distraction Spurt (Reddit & YouTube)
        (15, "Google Chrome", "AskReddit: Top engineering practices", "reddit.com", 0.0, 0),
        (15, "Google Chrome", "YouTube: Lo-Fi Coding Music", "youtube.com", 0.0, 0),
        # 14:45 - 15:00: Stretch Break
        (15, None, None, None, 150.0, 0),
        # 15:00 - 16:30: Afternoon Deep Work (Testing & PR)
        (60, "Code", "tests/test_metrics.py", "github.com", 0.0, 0),
        (30, "Terminal", "pytest tests/ -v", None, 0.0, 0),
        # 16:30 - 17:00: Wrap Up
        (30, "Slack", "#general", None, 5.0, 0),
    ]

    total_samples = 0
    curr_dt = base_dt

    for duration_min, app, title, domain, idle_sec, locked in schedule:
        num_samples = int(duration_min * 60 / 3)  # 3-second sample interval
        for _ in range(num_samples):
            # Add micro-variation to idle and events
            kb = random.randint(5, 45) if idle_sec < 30 and not locked else 0
            mouse = random.randint(2, 20) if idle_sec < 30 and not locked else 0
            actual_idle = idle_sec if locked or idle_sec >= 30 else random.uniform(0.1, 4.0)

            store.insert_sample(
                session_id=session_id,
                ts=curr_dt.timestamp(),
                active_app=app,
                window_title=title,
                browser_domain=domain,
                idle_seconds=actual_idle,
                screen_locked=bool(locked),
                kb_events=kb,
                mouse_events=mouse,
            )
            total_samples += 1

            # System stat every 10 samples (30s)
            if total_samples % 10 == 0:
                store.insert_system_stat(
                    session_id=session_id,
                    ts=curr_dt.timestamp(),
                    cpu_pct=random.uniform(12.0, 48.0) if app else random.uniform(2.0, 8.0),
                    ram_pct=random.uniform(55.0, 68.0),
                    battery_pct=max(20.0, 95.0 - (total_samples / 50.0)),
                    thermal_state="nominal",
                )

            curr_dt += timedelta(seconds=3)

    store.stop_session(session_id, curr_dt.timestamp())
    return total_samples
