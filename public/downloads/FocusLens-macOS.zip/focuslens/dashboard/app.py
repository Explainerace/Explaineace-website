"""
focuslens.dashboard.app
~~~~~~~~~~~~~~~~~~~~~~~~
Modern macOS-style productivity & performance dashboard for FocusLens.
"""

from __future__ import annotations

import sys
import time
from datetime import date as Date, datetime, timedelta
from pathlib import Path

# ── Ensure project root is on path ───────────────────────────────────────────
_PROJECT_ROOT = Path(__file__).parents[2]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

import streamlit as st

from focuslens.db.store import Store
from focuslens.metrics import Categorizer, MetricsEngine
from focuslens.metrics.engine import _Sample, _assign_weights, IDLE_THRESHOLD
from focuslens.dashboard.helpers import (
    CATEGORY_COLORS,
    CATEGORY_LABELS,
    fmt_seconds,
    focus_score_color,
    focus_score_label,
    merge_to_segments,
)
from focuslens.dashboard.charts import (
    hourly_chart,
    system_stats_chart,
    timeline_chart,
    top_apps_chart,
    top_domains_chart,
    week_trend_chart,
)
from focuslens.dashboard.tracker_ctl import (
    is_tracker_running,
    start_tracker,
    stop_tracker,
    get_collector_pid,
)
from focuslens.dashboard.demo_data import inject_demo_day
from focuslens.saas.auth import AuthManager
from focuslens.saas.goals import GoalManager
from focuslens.saas.teams import TeamAnalyticsManager

# ── Paths ─────────────────────────────────────────────────────────────────────

_APP_SUPPORT = Path.home() / "Library" / "Application Support" / "FocusLens"
_DB_PATH = _APP_SUPPORT / "focuslens.db"

# ── Page config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="FocusLens",
    page_icon="🔭",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── Custom CSS for macOS App Styling ──────────────────────────────────────────

st.markdown("""
<style>
  /* Hide default Streamlit clutter */
  #MainMenu { visibility: hidden; }
  header { visibility: hidden; height: 0 !important; }
  footer { visibility: hidden; height: 0 !important; }
  div[data-testid="stDecoration"] { display: none !important; }
  div[data-testid="stStatusWidget"] { visibility: hidden; }
  
  /* Container layout & native typography */
  div.block-container {
    padding-top: 1.5rem !important;
    padding-bottom: 2.5rem !important;
    max-width: 1440px !important;
  }
  
  body, .stApp {
    font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", -apple-system, "Segoe UI", Roboto, sans-serif;
    color: #0f172a;
    background: #f8fafc;
  }
  
  /* Top App Bar */
  .app-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 20px;
    background: #ffffff;
    border-radius: 16px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03), 0 4px 6px -2px rgba(0,0,0,0.02);
    margin-bottom: 20px;
  }
  .app-title {
    font-size: 1.45rem;
    font-weight: 800;
    letter-spacing: -0.025em;
    color: #0f172a;
    display: flex;
    align-items: center;
    gap: 10px;
  }
  
  /* Status Pill */
  .status-pill-running {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 5px 14px;
    border-radius: 9999px;
    background: #ecfdf5;
    color: #065f46;
    font-size: 0.82rem;
    font-weight: 600;
    border: 1px solid #a7f3d0;
    box-shadow: 0 1px 2px rgba(0,0,0,0.02);
  }
  .status-pill-idle {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 5px 14px;
    border-radius: 9999px;
    background: #f1f5f9;
    color: #475569;
    font-size: 0.82rem;
    font-weight: 600;
    border: 1px solid #cbd5e1;
  }
  .status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
  }
  .dot-green { background-color: #10b981; box-shadow: 0 0 8px #10b981; }
  .dot-gray { background-color: #94a3b8; }

  /* ==========================================================================
     PREMIUM BUTTON SYSTEM (macOS & Linear Design)
     ========================================================================== */
  
  /* Base button styling */
  div.stButton > button {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 8px !important;
    height: 40px !important;
    min-height: 40px !important;
    padding: 0 18px !important;
    border-radius: 10px !important;
    font-size: 0.86rem !important;
    font-weight: 600 !important;
    letter-spacing: -0.01em !important;
    cursor: pointer !important;
    white-space: nowrap !important;
    outline: none !important;
    -webkit-font-smoothing: antialiased !important;
    transition: all 0.16s cubic-bezier(0.16, 1, 0.3, 1) !important;
  }
  div.stButton > button:focus,
  div.stButton > button:focus-visible {
    outline: none !important;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.25) !important;
  }
  
  /* Ensure text inside button inherits white/dark correctly without Streamlit interference */
  div.stButton > button p,
  div.stButton > button span,
  div.stButton > button div {
    color: inherit !important;
    font-family: inherit !important;
    font-size: inherit !important;
    font-weight: inherit !important;
    letter-spacing: inherit !important;
    line-height: 1 !important;
    margin: 0 !important;
    padding: 0 !important;
  }

  /* Primary Button (Linear / Apple gradient) */
  div.stButton > button[kind="primary"],
  div.stButton > button[data-testid="baseButton-primary"] {
    background: linear-gradient(180deg, #2563eb 0%, #1d4ed8 100%) !important;
    color: #ffffff !important;
    border: 1px solid #1e40af !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.06), inset 0 1px 0 rgba(255, 255, 255, 0.25), 0 2px 4px rgba(37, 99, 235, 0.2) !important;
    text-shadow: 0 1px 1px rgba(0, 0, 0, 0.15) !important;
  }
  div.stButton > button[kind="primary"]:hover,
  div.stButton > button[data-testid="baseButton-primary"]:hover {
    background: linear-gradient(180deg, #3b82f6 0%, #2563eb 100%) !important;
    border-color: #1d4ed8 !important;
    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.3) !important;
    transform: translateY(-1.5px) !important;
    color: #ffffff !important;
  }
  div.stButton > button[kind="primary"]:active,
  div.stButton > button[data-testid="baseButton-primary"]:active {
    background: linear-gradient(180deg, #1d4ed8 0%, #1e40af 100%) !important;
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.25) !important;
    transform: translateY(0.5px) !important;
  }

  /* Secondary Button (Sleek Apple frosted glass / white card) */
  div.stButton > button[kind="secondary"],
  div.stButton > button[data-testid="baseButton-secondary"],
  div.stButton > button:not([kind="primary"]):not([data-testid="baseButton-primary"]) {
    background: #ffffff !important;
    color: #1e293b !important;
    border: 1px solid #cbd5e1 !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04) !important;
  }
  div.stButton > button[kind="secondary"]:hover,
  div.stButton > button[data-testid="baseButton-secondary"]:hover,
  div.stButton > button:not([kind="primary"]):not([data-testid="baseButton-primary"]):hover {
    background: #f8fafc !important;
    color: #0f172a !important;
    border-color: #94a3b8 !important;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.06) !important;
    transform: translateY(-1px) !important;
  }
  div.stButton > button[kind="secondary"]:active,
  div.stButton > button[data-testid="baseButton-secondary"]:active,
  div.stButton > button:not([kind="primary"]):not([data-testid="baseButton-primary"]):active {
    background: #f1f5f9 !important;
    transform: translateY(0.5px) !important;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.05) !important;
  }

  /* Date inputs match button height & style */
  div[data-baseweb="input"] {
    border-radius: 10px !important;
    height: 40px !important;
    min-height: 40px !important;
    border: 1px solid #cbd5e1 !important;
    background: #ffffff !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03) !important;
  }
  div[data-baseweb="input"]:focus-within {
    border-color: #2563eb !important;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15) !important;
  }
  div[data-baseweb="input"] input {
    font-size: 0.85rem !important;
    font-weight: 500 !important;
    color: #0f172a !important;
  }

  /* Sleek macOS Segmented Tabs */
  div[data-baseweb="tab-list"] {
    background: #f1f5f9 !important;
    border-radius: 12px !important;
    padding: 5px !important;
    gap: 4px !important;
    border: 1px solid #e2e8f0 !important;
    box-shadow: inset 0 1px 2px rgba(0,0,0,0.03) !important;
  }
  div[data-baseweb="tab-list"] button[data-baseweb="tab"] {
    border-radius: 8px !important;
    padding: 8px 18px !important;
    font-size: 0.86rem !important;
    font-weight: 600 !important;
    color: #64748b !important;
    background: transparent !important;
    border: none !important;
    transition: all 0.15s ease !important;
  }
  div[data-baseweb="tab-list"] button[data-baseweb="tab"]:hover {
    color: #1e293b !important;
    background: rgba(255, 255, 255, 0.5) !important;
  }
  div[data-baseweb="tab-list"] button[data-baseweb="tab"][aria-selected="true"] {
    background: #ffffff !important;
    color: #0f172a !important;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04) !important;
  }
  div[data-baseweb="tab-highlight"] {
    display: none !important;
  }

  /* Hero Metric Card */
  .score-card {
    background: #ffffff;
    border-radius: 18px;
    padding: 24px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 2px 8px rgba(0,0,0,0.03), 0 1px 2px rgba(0,0,0,0.02);
    text-align: center;
    transition: box-shadow 0.2s ease;
  }
  .score-card:hover {
    box-shadow: 0 6px 16px rgba(0,0,0,0.05);
  }
  .score-number {
    font-size: 4rem;
    font-weight: 900;
    letter-spacing: -0.05em;
    line-height: 1;
    margin: 8px 0;
  }
  .score-badge {
    display: inline-block;
    padding: 5px 14px;
    border-radius: 9999px;
    font-size: 0.88rem;
    font-weight: 700;
    margin-top: 4px;
  }

  /* Metric mini tiles */
  .mini-tile {
    background: #ffffff;
    border-radius: 16px;
    padding: 18px 20px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    height: 100%;
    transition: transform 0.15s ease, box-shadow 0.15s ease;
  }
  .mini-tile:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
  }
  .mini-tile-title {
    font-size: 0.78rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #64748b;
  }
  .mini-tile-value {
    font-size: 1.65rem;
    font-weight: 800;
    color: #0f172a;
    letter-spacing: -0.02em;
    margin-top: 6px;
  }
  .mini-tile-desc {
    font-size: 0.78rem;
    color: #94a3b8;
    margin-top: 4px;
  }

  /* Category Progress Bar */
  .cat-bar-container {
    background: #f1f5f9;
    border-radius: 9999px;
    overflow: hidden;
    display: flex;
    height: 14px;
    width: 100%;
    margin: 16px 0 10px;
    box-shadow: inset 0 1px 2px rgba(0,0,0,0.05);
  }
  .cat-bar-seg { height: 100%; transition: width 0.3s ease; }

  /* Diagnostic Card */
  .finding-card {
    border-radius: 14px;
    padding: 18px;
    margin-bottom: 14px;
    border-left: 4px solid;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
  }

  /* Section Title */
  .section-heading {
    font-size: 1.15rem;
    font-weight: 700;
    color: #0f172a;
    letter-spacing: -0.015em;
    margin: 18px 0 12px;
    display: flex;
    align-items: center;
    gap: 8px;
  }
</style>
""", unsafe_allow_html=True)


# ── Cached DB & Engine ────────────────────────────────────────────────────────

@st.cache_resource
def _get_store() -> Store:
    _APP_SUPPORT.mkdir(parents=True, exist_ok=True)
    return Store(_DB_PATH)


@st.cache_resource
def _get_engine() -> MetricsEngine:
    return MetricsEngine()


def _load_samples(date_str: str) -> list[tuple]:
    return _get_store().fetch_samples_for_day(date_str)


def _load_system_stats(date_str: str) -> list[tuple]:
    return _get_store().fetch_system_stats_for_day(date_str)


# ── Main App ──────────────────────────────────────────────────────────────────

def main() -> None:
    store = _get_store()
    engine = _get_engine()

    # Tracker Process Status
    running = is_tracker_running()
    pid = get_collector_pid()

    # ── Top Control & Header Bar ──────────────────────────────────────────────
    c_brand, c_actions = st.columns([4.2, 5.8])

    with c_brand:
        status_html = (
            f'<span class="status-pill-running"><span class="status-dot dot-green"></span> Tracking Live (PID {pid})</span>'
            if running
            else '<span class="status-pill-idle"><span class="status-dot dot-gray"></span> Tracker Stopped</span>'
        )
        st.markdown(
            f'<div style="display:flex;align-items:center;gap:12px;height:40px;">'
            f'<div class="app-title" style="margin:0;">🔭 FocusLens</div>'
            f'{status_html}'
            f'</div>',
            unsafe_allow_html=True,
        )

    with c_actions:
        c_act1, c_act2, c_act3 = st.columns([2.2, 2.2, 1.4])
        with c_act1:
            if not running:
                if st.button("▶ Start Tracking", type="primary", use_container_width=True):
                    ok, msg = start_tracker()
                    if ok:
                        st.success(msg)
                        time.sleep(0.4)
                        st.rerun()
                    else:
                        st.error(msg)
            else:
                if st.button("⏹ Stop Tracking", type="secondary", use_container_width=True):
                    ok, msg = stop_tracker()
                    if ok:
                        st.info(msg)
                        time.sleep(0.4)
                        st.rerun()
                    else:
                        st.error(msg)

        with c_act2:
            if st.button("🎲 Load Demo Day", help="Insert a realistic 8-hour workday to preview all charts and reports", use_container_width=True):
                today = Date.today()
                count = inject_demo_day(store, today)
                st.success(f"Loaded {count} demo telemetry samples!")
                time.sleep(0.5)
                st.rerun()

        with c_act3:
            if st.button("🔄 Refresh", use_container_width=True):
                st.rerun()

    # ── Date Navigation Toolbar ───────────────────────────────────────────────
    st.markdown("<div style='height:2px'></div>", unsafe_allow_html=True)
    today = Date.today()
    c_date_lbl, c_date, c_quick_today, c_quick_yest, _ = st.columns([1.5, 2.3, 1.2, 1.2, 3.8])

    with c_date_lbl:
        st.markdown(
            '<div style="display:flex;align-items:center;height:40px;font-size:0.82rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.04em;">'
            '📅 Select Date</div>',
            unsafe_allow_html=True,
        )

    with c_date:
        selected_date = st.date_input(
            "Select Date",
            value=today,
            min_value=today - timedelta(days=365),
            max_value=today,
            label_visibility="collapsed",
        )
    date_str = selected_date.strftime("%Y-%m-%d")

    with c_quick_today:
        if st.button("Today", use_container_width=True):
            selected_date = today
            date_str = today.strftime("%Y-%m-%d")
            st.rerun()

    with c_quick_yest:
        if st.button("Yesterday", use_container_width=True):
            selected_date = today - timedelta(days=1)
            date_str = selected_date.strftime("%Y-%m-%d")
            st.rerun()

    # ── Load Data & Check Empty State ─────────────────────────────────────────
    raw_samples = _load_samples(date_str)
    sys_stats = _load_system_stats(date_str)

    if not raw_samples:
        _render_empty_state(selected_date, running)
        _render_danger_zone(store)
        return

    # ── Compute Metrics & Insights ─────────────────────────────────────────────
    dm = engine.compute_day(selected_date, raw_samples)
    from focuslens.insights import InsightEngine
    report = InsightEngine().analyse(dm, sys_stats=sys_stats)

    # ── SaaS Auth & Goals ──────────────────────────────────────────────────────
    auth_mgr = AuthManager(store)
    current_user = auth_mgr.get_or_create_default_user()
    goal_mgr = GoalManager(store)
    goal_eval = goal_mgr.evaluate_day(current_user.id, dm)
    team_mgr = TeamAnalyticsManager(store)

    # ── SaaS Account & Goals Ribbon ───────────────────────────────────────────
    g1, g2, g3 = st.columns([2.5, 3.5, 4])
    with g1:
        st.markdown(
            f'<div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:12px;padding:12px 16px;box-shadow:0 1px 3px rgba(0,0,0,0.03);">'
            f'<div style="font-size:0.75rem;font-weight:600;color:#64748b;text-transform:uppercase;">Account Workspace</div>'
            f'<div style="font-weight:700;font-size:0.95rem;color:#0f172a;">{current_user.email} '
            f'<span style="background:#dbeafe;color:#1e40af;font-size:0.75rem;padding:2px 8px;border-radius:10px;font-weight:600;margin-left:4px;">✨ {current_user.plan_tier.upper()}</span></div>'
            f'</div>',
            unsafe_allow_html=True,
        )
    with g2:
        dw_hrs = goal_eval.deep_work_actual_m / 60.0
        target_hrs = goal_eval.deep_work_target_m / 60.0
        st.markdown(
            f'<div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:12px;padding:12px 16px;box-shadow:0 1px 3px rgba(0,0,0,0.03);">'
            f'<div style="display:flex;justify-content:space-between;font-size:0.75rem;font-weight:600;color:#64748b;text-transform:uppercase;">'
            f'<span>🎯 Deep Work Target</span> <span>{dw_hrs:.1f}h / {target_hrs:.1f}h ({goal_eval.deep_work_pct:.0f}%)</span>'
            f'</div>'
            f'<div style="background:#f1f5f9;height:8px;border-radius:4px;overflow:hidden;margin-top:8px;">'
            f'<div style="background:#22c55e;height:100%;width:{goal_eval.deep_work_pct}%;"></div>'
            f'</div>'
            f'</div>',
            unsafe_allow_html=True,
        )
    with g3:
        badges_html = " ".join([
            f'<span style="background:#fef3c7;color:#92400e;border:1px solid #fde68a;font-size:0.75rem;padding:2px 8px;border-radius:10px;font-weight:600;margin-right:4px;">{b}</span>'
            for b in goal_eval.badges
        ]) or '<span style="font-size:0.8rem;color:#94a3b8;">Keep tracking to earn daily badges</span>'
        st.markdown(
            f'<div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:12px;padding:12px 16px;box-shadow:0 1px 3px rgba(0,0,0,0.03);">'
            f'<div style="font-size:0.75rem;font-weight:600;color:#64748b;text-transform:uppercase;">Daily Achievements</div>'
            f'<div style="margin-top:4px;">{badges_html}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)

    # 7-day trend
    week_dates = [(selected_date - timedelta(days=i)) for i in range(6, -1, -1)]
    week_date_strs = [d.strftime("%Y-%m-%d") for d in week_dates]
    week_scores = []
    for d in week_dates:
        ds = d.strftime("%Y-%m-%d")
        rows = _load_samples(ds)
        if rows:
            wdm = engine.compute_day(d, rows)
            week_scores.append(wdm.focus_score)
        else:
            week_scores.append(0.0)

    # ── Hero Metrics Row ───────────────────────────────────────────────────────
    score_col, m1, m2, m3, m4 = st.columns([2.5, 2, 2, 2, 2])

    with score_col:
        s_color = focus_score_color(dm.focus_score)
        s_lbl = focus_score_label(dm.focus_score)
        st.markdown(
            f'<div class="score-card">'
            f'<div style="font-size:0.85rem;font-weight:600;color:#64748b;text-transform:uppercase;">Daily Focus Score</div>'
            f'<div class="score-number" style="color:{s_color};">{dm.focus_score:.0f}</div>'
            f'<div class="score-badge" style="background:{s_color}22;color:{s_color};">{s_lbl}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    with m1:
        st.markdown(
            f'<div class="mini-tile">'
            f'<div class="mini-tile-title">⏱ Screen Time</div>'
            f'<div class="mini-tile-value">{fmt_seconds(dm.total_tracked_seconds)}</div>'
            f'<div class="mini-tile-desc">Active: {fmt_seconds(dm.active_seconds)}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    with m2:
        st.markdown(
            f'<div class="mini-tile">'
            f'<div class="mini-tile-title">🧠 Deep Work</div>'
            f'<div class="mini-tile-value">{fmt_seconds(dm.deep_work_minutes * 60)}</div>'
            f'<div class="mini-tile-desc">{len(dm.deep_work_blocks)} block(s) ≥ 25 min</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    with m3:
        st.markdown(
            f'<div class="mini-tile">'
            f'<div class="mini-tile-title">🔀 Context Switches</div>'
            f'<div class="mini-tile-value">{dm.context_switches_per_hour:.1f} <span style="font-size:0.9rem;font-weight:400">/hr</span></div>'
            f'<div class="mini-tile-desc">{dm.context_switches} total switches</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    with m4:
        st.markdown(
            f'<div class="mini-tile">'
            f'<div class="mini-tile-title">☕ Rest Rhythm</div>'
            f'<div class="mini-tile-value">{dm.break_count} <span style="font-size:0.9rem;font-weight:400">breaks</span></div>'
            f'<div class="mini-tile-desc">Max stretch: {fmt_seconds(dm.longest_stretch_minutes * 60)}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    # ── Category Distribution Pill Bar ─────────────────────────────────────────
    total = dm.total_tracked_seconds or 1
    p_pct = dm.productive_seconds / total * 100
    n_pct = dm.neutral_seconds / total * 100
    d_pct = dm.distracting_seconds / total * 100
    i_pct = dm.idle_seconds / total * 100

    st.markdown(
        f'<div class="cat-bar-container">'
        f'<div class="cat-bar-seg" style="width:{p_pct}%;background:{CATEGORY_COLORS["productive"]}" title="Productive: {p_pct:.0f}%"></div>'
        f'<div class="cat-bar-seg" style="width:{n_pct}%;background:{CATEGORY_COLORS["neutral"]}" title="Neutral: {n_pct:.0f}%"></div>'
        f'<div class="cat-bar-seg" style="width:{d_pct}%;background:{CATEGORY_COLORS["distracting"]}" title="Distracting: {d_pct:.0f}%"></div>'
        f'<div class="cat-bar-seg" style="width:{i_pct}%;background:{CATEGORY_COLORS["idle"]}" title="Idle: {i_pct:.0f}%"></div>'
        f'</div>',
        unsafe_allow_html=True,
    )

    leg1, leg2, leg3, leg4 = st.columns(4)
    with leg1:
        st.markdown(f'<span style="color:{CATEGORY_COLORS["productive"]}">●</span> <b>Productive</b>: {p_pct:.0f}% ({fmt_seconds(dm.productive_seconds)})', unsafe_allow_html=True)
    with leg2:
        st.markdown(f'<span style="color:{CATEGORY_COLORS["neutral"]}">●</span> <b>Neutral</b>: {n_pct:.0f}% ({fmt_seconds(dm.neutral_seconds)})', unsafe_allow_html=True)
    with leg3:
        st.markdown(f'<span style="color:{CATEGORY_COLORS["distracting"]}">●</span> <b>Distracting</b>: {d_pct:.0f}% ({fmt_seconds(dm.distracting_seconds)})', unsafe_allow_html=True)
    with leg4:
        st.markdown(f'<span style="color:{CATEGORY_COLORS["idle"]}">●</span> <b>Idle/Locked</b>: {i_pct:.0f}% ({fmt_seconds(dm.idle_seconds)})', unsafe_allow_html=True)

    st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)

    # ── Modern Tabs ───────────────────────────────────────────────────────────
    (
        tab_overview,
        tab_apps,
        tab_insights,
        tab_ai,
        tab_teams,
        tab_cloud,
        tab_trends,
    ) = st.tabs([
        "📊 Activity & Timeline",
        "📱 Apps & Distractions",
        "🧪 Diagnostic Findings",
        "🤖 AI Productivity Coach",
        "👥 Team Benchmarks",
        "☁️ Cloud Sync & Devices",
        "📈 7-Day Trend & System",
    ])

    # ── TAB 1: OVERVIEW & TIMELINE ────────────────────────────────────────────
    with tab_overview:
        st.markdown('<div class="section-heading">📅 24-Hour Day Timeline</div>', unsafe_allow_html=True)
        samples_obj = _assign_weights(list(map(_Sample, raw_samples)))
        cats = [
            "idle" if (s.screen_locked or s.idle_seconds >= IDLE_THRESHOLD)
            else engine._cat.categorise(s.active_app, s.browser_domain)
            for s in samples_obj
        ]
        segments = merge_to_segments(raw_samples, cats)
        st.plotly_chart(
            timeline_chart(segments, date_str),
            use_container_width=True,
            config={"displayModeBar": False},
        )

        h_col, dw_col = st.columns([2, 1])
        with h_col:
            st.markdown('<div class="section-heading">🕐 Hourly Focus Quality</div>', unsafe_allow_html=True)
            if dm.best_hour is not None:
                st.caption(f"Peak Performance: **{dm.best_hour:02d}:00** · Most Fragmented: **{dm.worst_hour:02d}:00**")
            st.plotly_chart(
                hourly_chart(dm.hourly),
                use_container_width=True,
                config={"displayModeBar": False},
            )

        with dw_col:
            st.markdown('<div class="section-heading">🧠 Deep Work Blocks</div>', unsafe_allow_html=True)
            if dm.deep_work_blocks:
                for blk in dm.deep_work_blocks:
                    start_s = datetime.fromtimestamp(blk.start_ts).strftime("%H:%M")
                    end_s = datetime.fromtimestamp(blk.end_ts).strftime("%H:%M")
                    st.markdown(
                        f'<div style="background:#f0fdf4;border-left:4px solid #22c55e;'
                        f'padding:10px 14px;border-radius:0 10px 10px 0;margin-bottom:8px">'
                        f'<b>{start_s} – {end_s}</b> <span style="color:#16a34a;font-weight:600">({blk.duration_minutes:.0f}m)</span><br>'
                        f'<span style="font-size:0.85rem;color:#475569">{blk.primary_app}</span>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )
            else:
                st.info("No deep work blocks recorded today.\nAim for at least 25 min uninterrupted focus in a productive tool.")

    # ── TAB 2: APPS & WEBSITES ────────────────────────────────────────────────
    with tab_apps:
        app_col, dom_col = st.columns(2)
        with app_col:
            st.markdown('<div class="section-heading">📱 Top Applications</div>', unsafe_allow_html=True)
            if dm.top_apps:
                st.plotly_chart(
                    top_apps_chart(dm.top_apps, n=10),
                    use_container_width=True,
                    config={"displayModeBar": False},
                )
            else:
                st.info("No app data recorded.")

        with dom_col:
            st.markdown('<div class="section-heading">🚫 Top Distracting Websites</div>', unsafe_allow_html=True)
            if dm.top_distracting_domains:
                st.plotly_chart(
                    top_domains_chart(dm.top_distracting_domains, n=8),
                    use_container_width=True,
                    config={"displayModeBar": False},
                )
            else:
                st.success("✅ Zero distracting sites visited today! Excellent discipline.")

    # ── TAB 3: DIAGNOSTIC FINDINGS ────────────────────────────────────────────
    with tab_insights:
        _render_insights_tab(report)

    # ── TAB 4: AI COACH ───────────────────────────────────────────────────────
    with tab_ai:
        _render_ai_tab(dm, report, week_date_strs, week_scores, date_str)

    # ── TAB 5: TEAM BENCHMARKS ───────────────────────────────────────────────
    with tab_teams:
        _render_teams_tab(team_mgr)

    # ── TAB 6: CLOUD SYNC & DEVICES ──────────────────────────────────────────
    with tab_cloud:
        _render_cloud_sync_tab(current_user)

    # ── TAB 7: TRENDS & SYSTEM STATS ──────────────────────────────────────────
    with tab_trends:
        st.markdown('<div class="section-heading">📈 7-Day Focus Score Trend</div>', unsafe_allow_html=True)
        st.plotly_chart(
            week_trend_chart(week_date_strs, week_scores),
            use_container_width=True,
            config={"displayModeBar": False},
        )

        if sys_stats:
            st.markdown('<div class="section-heading">💻 Machine Telemetry (CPU & RAM)</div>', unsafe_allow_html=True)
            st.plotly_chart(
                system_stats_chart(sys_stats),
                use_container_width=True,
                config={"displayModeBar": False},
            )
            # Thermals
            states = [r[4] for r in sys_stats if r[4]]
            if states:
                dominant = max(set(states), key=states.count)
                st.caption(f"Dominant Thermal State: **{dominant}**")

    # ── Danger Zone ───────────────────────────────────────────────────────────
    _render_danger_zone(store)


# ── Render Helpers ────────────────────────────────────────────────────────────

def _render_empty_state(selected_date: Date, running: bool) -> None:
    """Render a modern welcome empty state with action buttons."""
    st.markdown(
        f'<div style="text-align:center;padding:50px 20px;background:#ffffff;border-radius:18px;border:1px solid #e2e8f0;margin-top:20px;">'
        f'<div style="font-size:3rem;margin-bottom:10px;">🔭</div>'
        f'<h2 style="font-weight:700;color:#0f172a;margin-bottom:6px;">No Telemetry for {selected_date.strftime("%B %d, %Y")}</h2>'
        f'<p style="color:#64748b;max-width:500px;margin:0 auto 24px;line-height:1.5;">'
        f'FocusLens records your active applications, deep work blocks, and focus interruptions locally with zero cloud exposure.'
        f'</p>'
        f'</div>',
        unsafe_allow_html=True,
    )

    c_pad1, c_btn1, c_btn2, c_pad2 = st.columns([1.5, 2.2, 2.2, 1.5])
    with c_btn1:
        if not running:
            if st.button("▶ Start Tracking Now", type="primary", use_container_width=True, key="empty_start"):
                ok, msg = start_tracker()
                if ok:
                    st.success(msg)
                    time.sleep(0.4)
                    st.rerun()
        else:
            st.info("🟢 Collector is actively running!")

    with c_btn2:
        if st.button("✨ Load 8-Hour Demo Day", type="secondary", use_container_width=True, key="empty_demo"):
            store = _get_store()
            count = inject_demo_day(store, selected_date)
            st.success(f"Generated {count} realistic telemetry samples!")
            time.sleep(0.5)
            st.rerun()


def _render_insights_tab(report) -> None:
    """Render styled diagnostic cards."""
    from focuslens.insights.models import SEVERITY_COLOR, SEVERITY_BORDER

    st.markdown(
        f'<div style="display:flex;align-items:center;justify-content:space-between;background:#ffffff;padding:18px;border-radius:14px;border:1px solid #e2e8f0;margin-bottom:20px;">'
        f'<div>'
        f'<div style="font-size:1.4rem;font-weight:800;color:#0f172a;">{report.overall_verdict}</div>'
        f'<div style="color:#475569;margin-top:4px;font-size:0.95rem;">{report.summary}</div>'
        f'</div>'
        f'</div>',
        unsafe_allow_html=True,
    )

    if not report.has_enough_data:
        st.info("Track for at least 30 minutes to unlock comprehensive automated diagnostics.")
        return

    findings = report.sorted_findings()
    if not findings:
        st.success("✅ No productivity bottlenecks detected today!")
        return

    cols = st.columns(2)
    for i, f in enumerate(findings):
        with cols[i % 2]:
            bg = SEVERITY_COLOR.get(f.severity, "#f8fafc")
            border = SEVERITY_BORDER.get(f.severity, "#94a3b8")
            st.markdown(
                f'<div class="finding-card" style="background:{bg};border-color:{border};">'
                f'<div style="font-weight:700;font-size:1rem;color:#0f172a;">{f.emoji} {f.title}</div>'
                f'<div style="font-size:0.85rem;color:#334155;margin:8px 0;line-height:1.4;">{f.detail}</div>'
                f'<div style="font-size:0.82rem;font-weight:600;color:#4f46e5;background:#ffffffcc;padding:8px 10px;border-radius:6px;border:1px solid #e0e7ff;">'
                f'💡 Action: {f.fix}'
                f'</div>'
                f'<div style="font-size:0.75rem;color:#64748b;margin-top:6px;">Metric: <b>{f.value}</b> ({f.metric})</div>'
                f'</div>',
                unsafe_allow_html=True,
            )


def _render_ai_tab(dm, report, week_dates, week_scores, date_str) -> None:
    """Render AI coach tab with interactive execution."""
    from focuslens.ai import AIClient

    st.markdown('<div class="section-heading">🤖 AI Productivity Coach</div>', unsafe_allow_html=True)
    st.markdown(
        "Generate an executive coaching brief synthesizing your telemetry into specific strategic recommendations. "
        "Aggregated metrics are processed locally: **no window titles, keystrokes, or URLs** are ever transmitted."
    )

    c_opt, c_run = st.columns([3, 1.5])
    with c_opt:
        provider_opt = st.selectbox(
            "Select AI Provider",
            options=["auto", "ollama", "claude", "offline"],
            format_func=lambda x: {
                "auto": "⚡ Auto-Detect (Ollama Local → Claude API → Offline)",
                "ollama": "🦙 Ollama (100% Local LLM)",
                "claude": "🧠 Claude (Anthropic API Key)",
                "offline": "📦 Built-in Offline Synthesizer",
            }.get(x, x),
            key=f"ai_prov_{date_str}",
        )
    with c_run:
        st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
        generate_btn = st.button("✨ Generate Coaching Brief", type="primary", use_container_width=True, key=f"ai_gen_{date_str}")

    cache_key = f"cached_ai_report_{date_str}"
    if generate_btn:
        with st.spinner("Analyzing telemetry with AI coach..."):
            client = AIClient(provider=provider_opt)
            res = client.generate_report(dm, report, week_dates, week_scores)
            st.session_state[cache_key] = res

    cached = st.session_state.get(cache_key)
    if cached:
        if cached.success:
            st.markdown(
                f'<div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:14px;padding:22px;margin-top:14px;box-shadow:0 2px 8px rgba(0,0,0,0.02);">'
                f'<div style="font-size:0.8rem;color:#64748b;margin-bottom:12px;">Generated via <b>{cached.provider}</b> ({cached.model})</div>'
                f'{cached.content}'
                f'</div>',
                unsafe_allow_html=True,
            )
        else:
            st.error(f"AI Generation Failed: {cached.error}")

def _render_teams_tab(team_mgr) -> None:
    """Render the B2B team productivity benchmarks tab."""
    bench = team_mgr.get_team_benchmark("Engineering & Product")

    st.markdown('<div class="section-heading">👥 Workplace & Team Analytics</div>', unsafe_allow_html=True)
    st.markdown(
        "Aggregated, privacy-first benchmarks across your organization. "
        "**Privacy Guarantee**: Personal window titles and browsing history are strictly hidden; only team-wide aggregate focus scores and deep work hours are compiled."
    )

    t1, t2, t3, t4 = st.columns(4)
    with t1:
        st.markdown(
            f'<div class="mini-tile">'
            f'<div class="mini-tile-title">🏢 Workspace</div>'
            f'<div class="mini-tile-value" style="font-size:1.2rem;">{bench.team_name}</div>'
            f'<div class="mini-tile-desc">{bench.member_count} connected engineers</div>'
            f'</div>',
            unsafe_allow_html=True,
        )
    with t2:
        st.markdown(
            f'<div class="mini-tile">'
            f'<div class="mini-tile-title">🎯 Team Avg Score</div>'
            f'<div class="mini-tile-value" style="color:#16a34a;">{bench.avg_focus_score:.1f} <span style="font-size:0.9rem;font-weight:400">/100</span></div>'
            f'<div class="mini-tile-desc">Top 15% industry benchmark</div>'
            f'</div>',
            unsafe_allow_html=True,
        )
    with t3:
        st.markdown(
            f'<div class="mini-tile">'
            f'<div class="mini-tile-title">🧠 Team Deep Work</div>'
            f'<div class="mini-tile-value">{bench.total_deep_work_hours:.1f} <span style="font-size:0.9rem;font-weight:400">hrs</span></div>'
            f'<div class="mini-tile-desc">This week total</div>'
            f'</div>',
            unsafe_allow_html=True,
        )
    with t4:
        risk_color = "#16a34a" if bench.burnout_risk_score == "Low" else "#f59e0b"
        st.markdown(
            f'<div class="mini-tile">'
            f'<div class="mini-tile-title">🛡 Burnout Risk Index</div>'
            f'<div class="mini-tile-value" style="color:{risk_color};">{bench.burnout_risk_score}</div>'
            f'<div class="mini-tile-desc">Healthy break intervals</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)
    st.markdown("<b>Primary Core Tools Across Team:</b>", unsafe_allow_html=True)
    pills = " ".join([
        f'<span style="background:#e0f2fe;color:#0369a1;padding:4px 12px;border-radius:12px;font-size:0.85rem;font-weight:600;margin-right:6px;">{tool}</span>'
        for tool in bench.top_productive_tools
    ])
    st.markdown(f'<div style="margin-top:6px;">{pills}</div>', unsafe_allow_html=True)


def _render_cloud_sync_tab(user) -> None:
    """Render cloud sync configuration and device pairing keys."""
    st.markdown('<div class="section-heading">☁️ Cloud Sync & Device Pairing</div>', unsafe_allow_html=True)
    st.markdown(
        "Connect multiple MacBooks to your FocusLens cloud account. "
        "Telemetry streams securely over HTTPS and updates this dashboard in real-time."
    )

    c_box1, c_box2 = st.columns(2)
    with c_box1:
        st.markdown(
            f'<div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:14px;padding:20px;box-shadow:0 2px 6px rgba(0,0,0,0.02);">'
            f'<div style="font-size:0.85rem;font-weight:700;color:#64748b;text-transform:uppercase;">Your Device Pairing Key</div>'
            f'<div style="font-family:monospace;font-size:1.1rem;background:#f8fafc;border:1px dashed #cbd5e1;padding:10px;border-radius:8px;margin:10px 0;word-break:break-all;color:#0f172a;">'
            f'{user.api_key}</div>'
            f'<div style="font-size:0.8rem;color:#64748b;">Use this key to authenticate your MacBook with your cloud dashboard.</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    with c_box2:
        st.markdown(
            f'<div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:14px;padding:20px;box-shadow:0 2px 6px rgba(0,0,0,0.02);">'
            f'<div style="font-size:0.85rem;font-weight:700;color:#64748b;text-transform:uppercase;">Railway Cloud Endpoint</div>'
            f'<div style="font-family:monospace;font-size:1rem;background:#f8fafc;border:1px solid #e2e8f0;padding:10px;border-radius:8px;margin:10px 0;color:#2563eb;">'
            f'https://your-app.up.railway.app</div>'
            f'<div style="font-size:0.8rem;color:#64748b;">To pair a Mac, run: <code>export FOCUSLENS_SYNC_URL=https://...</code></div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)
    with st.expander("📖 Step-by-Step Multi-Device Pairing Guide"):
        st.markdown("""
        1. **On your other MacBook**, install FocusLens using `./install.sh`.
        2. Set your environment variables in `~/.zshrc`:
           ```bash
           export FOCUSLENS_SYNC_URL="https://your-app.up.railway.app"
           export FOCUSLENS_API_KEY="{api_key}"
           ```
        3. Launch FocusLens: telemetry from both laptops will now unify under this single dashboard.
        """.format(api_key=user.api_key))


def _render_danger_zone(store: Store) -> None:
    """Render data management options."""
    st.markdown("<div style='height:30px'></div>", unsafe_allow_html=True)
    with st.expander("⚙️ Data Management & Privacy"):
        st.markdown("All FocusLens tracking data resides exclusively on your local Mac disk in `~/Library/Application Support/FocusLens/focuslens.db`.")
        if st.button("🗑 Delete All Stored Telemetry", type="secondary"):
            st.session_state["confirm_purge"] = True

        if st.session_state.get("confirm_purge"):
            st.warning("⚠️ Are you sure you want to permanently erase all sessions, samples, and stats?")
            c_yes, c_no = st.columns([1, 4])
            with c_yes:
                if st.button("Yes, Erase Everything", type="primary"):
                    store.delete_all_data()
                    st.session_state.pop("confirm_purge", None)
                    st.success("All data successfully erased.")
                    time.sleep(0.5)
                    st.rerun()
            with c_no:
                if st.button("Cancel"):
                    st.session_state.pop("confirm_purge", None)
                    st.rerun()


if __name__ == "__main__":
    main()
