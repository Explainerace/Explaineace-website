"""Allow `python -m focuslens.dashboard` to launch the Streamlit app."""
import subprocess
import sys
from pathlib import Path

_APP_FILE = Path(__file__).parent / "app.py"


def main() -> None:
    cmd = [
        sys.executable, "-m", "streamlit", "run",
        str(_APP_FILE),
        "--server.headless", "false",
        "--browser.gatherUsageStats", "false",
    ]
    # Forward any extra CLI arguments (e.g. --server.port 8502)
    cmd.extend(sys.argv[1:])
    subprocess.run(cmd)


if __name__ == "__main__":
    main()
