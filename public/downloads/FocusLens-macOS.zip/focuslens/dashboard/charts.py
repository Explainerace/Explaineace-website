"""
focuslens.dashboard.charts
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Plotly chart builders for the FocusLens dashboard.

Each function takes domain objects (from metrics.models or helpers)
and returns a plotly Figure ready for st.plotly_chart().
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

import plotly.graph_objects as go

from focuslens.dashboard.helpers import (
    CATEGORY_COLORS,
    CATEGORY_LABELS,
    TimelineSegment,
    focus_score_color,
    fmt_hhmm,
    fmt_seconds,
)
from focuslens.metrics.models import AppUsage, DomainUsage, HourMetrics

# ── Shared layout defaults ────────────────────────────────────────────────────

_FONT = dict(family="system-ui, -apple-system, sans-serif", size=13)
_PAPER_BG = "white"
_PLOT_BG = "#fafafa"
_GRID_COLOR = "#f1f5f9"
_MARGIN = dict(l=8, r=8, t=8, b=8)


# ─────────────────────────────────────────────────────────────────────────────
# 1.  DAY TIMELINE
# ─────────────────────────────────────────────────────────────────────────────

def timeline_chart(
    segments: list[TimelineSegment],
    day_date_str: str,
) -> go.Figure:
    """
    Horizontal coloured timeline bar for one day.

    X-axis = hours 0-24.
    Each segment is rendered as a filled rectangle.
    An invisible scatter trace provides hover tooltips.
    """
    from datetime import datetime
    midnight_ts = datetime.strptime(day_date_str, "%Y-%m-%d").timestamp()

    fig = go.Figure()

    # ── Draw coloured rectangles ──────────────────────────────────────────────
    for seg in segments:
        x0 = (seg.start_ts - midnight_ts) / 3600
        x1 = (seg.end_ts - midnight_ts) / 3600
        x0 = max(0.0, min(x0, 24.0))
        x1 = max(0.0, min(x1, 24.0))
        if x1 <= x0:
            continue

        label = CATEGORY_LABELS.get(seg.category, seg.category)
        dur = fmt_seconds(seg.duration_seconds)
        hover = (
            f"<b>{label}</b><br>"
            f"{fmt_hhmm(seg.start_ts)} – {fmt_hhmm(seg.end_ts)}<br>"
            f"Duration: {dur}"
            + (f"<br>App: {seg.app}" if seg.app else "")
        )

        fig.add_shape(
            type="rect",
            x0=x0, x1=x1,
            y0=0, y1=1,
            fillcolor=CATEGORY_COLORS.get(seg.category, "#94a3b8"),
            line_width=0,
            opacity=0.88,
        )
        # Invisible scatter point for tooltip
        fig.add_trace(
            go.Scatter(
                x=[(x0 + x1) / 2],
                y=[0.5],
                mode="markers",
                marker=dict(size=1, opacity=0),
                hovertemplate=hover + "<extra></extra>",
                showlegend=False,
            )
        )

    # ── Legend traces (one per category, invisible) ───────────────────────────
    seen: set[str] = set()
    for seg in segments:
        if seg.category not in seen:
            seen.add(seg.category)
            fig.add_trace(
                go.Scatter(
                    x=[None], y=[None],
                    mode="markers",
                    marker=dict(size=12, color=CATEGORY_COLORS.get(seg.category, "#94a3b8"), symbol="square"),
                    name=CATEGORY_LABELS.get(seg.category, seg.category),
                    showlegend=True,
                )
            )

    tick_vals = list(range(0, 25, 2))
    tick_text = [f"{h:02d}:00" for h in tick_vals]

    fig.update_layout(
        height=90,
        margin=dict(l=0, r=0, t=0, b=28),
        xaxis=dict(
            range=[0, 24],
            tickmode="array",
            tickvals=tick_vals,
            ticktext=tick_text,
            showgrid=True,
            gridcolor=_GRID_COLOR,
            zeroline=False,
        ),
        yaxis=dict(visible=False, range=[0, 1]),
        plot_bgcolor=_PLOT_BG,
        paper_bgcolor=_PAPER_BG,
        font=_FONT,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
            font=dict(size=11),
        ),
        hovermode="closest",
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# 2.  HOURLY FOCUS SCORE
# ─────────────────────────────────────────────────────────────────────────────

def hourly_chart(hourly: list[HourMetrics]) -> go.Figure:
    """Bar chart: focus score by hour, colour-coded by score level."""
    if not hourly:
        return _empty_fig("No hourly data")

    active = [h for h in hourly if h.total_seconds >= 30]
    if not active:
        return _empty_fig("No active hours")

    x = [f"{h.hour:02d}:00" for h in active]
    y = [h.focus_score for h in active]
    colors = [focus_score_color(s) for s in y]
    hover = [
        (
            f"<b>{h.hour:02d}:00 – {h.hour+1:02d}:00</b><br>"
            f"Focus score: <b>{h.focus_score:.0f}</b><br>"
            f"Productive: {fmt_seconds(h.productive_seconds)}<br>"
            f"Distracting: {fmt_seconds(h.distracting_seconds)}<br>"
            f"Idle: {fmt_seconds(h.idle_seconds)}<br>"
            f"Switches: {h.context_switches}"
        )
        for h in active
    ]

    fig = go.Figure(
        go.Bar(
            x=x,
            y=y,
            marker_color=colors,
            customdata=hover,
            hovertemplate="%{customdata}<extra></extra>",
            text=[f"{s:.0f}" for s in y],
            textposition="outside",
            textfont=dict(size=11),
        )
    )
    fig.update_layout(
        height=280,
        margin=dict(l=0, r=0, t=24, b=0),
        xaxis=dict(title="Hour", showgrid=False),
        yaxis=dict(title="Focus Score", range=[0, 115], showgrid=True, gridcolor=_GRID_COLOR),
        plot_bgcolor=_PLOT_BG,
        paper_bgcolor=_PAPER_BG,
        font=_FONT,
        showlegend=False,
    )
    # Reference lines
    for level, color in [(70, "#22c55e"), (40, "#f59e0b")]:
        fig.add_hline(
            y=level, line_dash="dot", line_color=color,
            opacity=0.5, line_width=1,
        )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# 3.  TOP APPS
# ─────────────────────────────────────────────────────────────────────────────

def top_apps_chart(top_apps: list[AppUsage], n: int = 10) -> go.Figure:
    """Horizontal bar chart of top apps by time spent, coloured by category."""
    if not top_apps:
        return _empty_fig("No app data")

    apps = top_apps[:n]
    names = [a.name for a in apps]
    durations = [a.seconds / 60 for a in apps]   # convert to minutes
    colors = [CATEGORY_COLORS.get(a.category, "#94a3b8") for a in apps]
    hover = [
        f"<b>{a.name}</b><br>{fmt_seconds(a.seconds)}<br>Category: {a.category}"
        for a in apps
    ]

    fig = go.Figure(
        go.Bar(
            x=durations[::-1],
            y=names[::-1],
            orientation="h",
            marker_color=colors[::-1],
            customdata=hover[::-1],
            hovertemplate="%{customdata}<extra></extra>",
            text=[fmt_seconds(a.seconds) for a in apps[::-1]],
            textposition="outside",
            textfont=dict(size=11),
        )
    )
    fig.update_layout(
        height=max(180, 30 * len(apps) + 40),
        margin=dict(l=0, r=60, t=8, b=0),
        xaxis=dict(title="Minutes", showgrid=True, gridcolor=_GRID_COLOR),
        yaxis=dict(showgrid=False),
        plot_bgcolor=_PLOT_BG,
        paper_bgcolor=_PAPER_BG,
        font=_FONT,
        showlegend=False,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# 4.  TOP DISTRACTING DOMAINS
# ─────────────────────────────────────────────────────────────────────────────

def top_domains_chart(domains: list[DomainUsage], n: int = 8) -> go.Figure:
    """Horizontal bar chart of top distracting domains."""
    if not domains:
        return _empty_fig("No distracting domains 🎉")

    d = domains[:n]
    names = [x.domain for x in d]
    durations = [x.seconds / 60 for x in d]
    hover = [
        f"<b>{x.domain}</b><br>{fmt_seconds(x.seconds)}"
        for x in d
    ]

    fig = go.Figure(
        go.Bar(
            x=durations[::-1],
            y=names[::-1],
            orientation="h",
            marker_color=CATEGORY_COLORS["distracting"],
            customdata=hover[::-1],
            hovertemplate="%{customdata}<extra></extra>",
            text=[fmt_seconds(x.seconds) for x in d[::-1]],
            textposition="outside",
            textfont=dict(size=11),
        )
    )
    fig.update_layout(
        height=max(150, 28 * len(d) + 40),
        margin=dict(l=0, r=60, t=8, b=0),
        xaxis=dict(title="Minutes", showgrid=True, gridcolor=_GRID_COLOR),
        yaxis=dict(showgrid=False),
        plot_bgcolor=_PLOT_BG,
        paper_bgcolor=_PAPER_BG,
        font=_FONT,
        showlegend=False,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# 5.  7-DAY TREND
# ─────────────────────────────────────────────────────────────────────────────

def week_trend_chart(dates: list[str], scores: list[float]) -> go.Figure:
    """Line chart of daily focus scores over 7 days."""
    if not dates:
        return _empty_fig("No trend data")

    # Format dates as weekday labels (Mon, Tue…)
    labels = []
    for d in dates:
        try:
            labels.append(datetime.strptime(d, "%Y-%m-%d").strftime("%a %-d"))
        except Exception:
            labels.append(d)

    point_colors = [focus_score_color(s) for s in scores]

    fig = go.Figure()

    # Shaded reference zones
    for low, high, color in [(0, 40, "#fee2e2"), (40, 70, "#fef9c3"), (70, 100, "#dcfce7")]:
        fig.add_hrect(y0=low, y1=high, fillcolor=color, opacity=0.25, line_width=0)

    fig.add_trace(
        go.Scatter(
            x=labels,
            y=scores,
            mode="lines+markers+text",
            line=dict(color="#6366f1", width=2.5),
            marker=dict(size=10, color=point_colors, line=dict(color="white", width=2)),
            text=[f"{s:.0f}" if s > 0 else "" for s in scores],
            textposition="top center",
            textfont=dict(size=11),
            hovertemplate="<b>%{x}</b><br>Focus Score: <b>%{y:.0f}</b><extra></extra>",
        )
    )

    fig.update_layout(
        height=260,
        margin=dict(l=0, r=0, t=16, b=0),
        xaxis=dict(showgrid=False),
        yaxis=dict(
            title="Focus Score",
            range=[0, 105],
            showgrid=True,
            gridcolor=_GRID_COLOR,
        ),
        plot_bgcolor=_PAPER_BG,
        paper_bgcolor=_PAPER_BG,
        font=_FONT,
        showlegend=False,
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# 6.  SYSTEM STATS MINI CHART
# ─────────────────────────────────────────────────────────────────────────────

def system_stats_chart(rows: list[tuple]) -> go.Figure:
    """
    Line chart of CPU% and RAM% over the day.
    rows: (ts, cpu_pct, ram_pct, battery_pct, thermal_state)
    """
    if not rows:
        return _empty_fig("No system data")

    times = [datetime.fromtimestamp(r[0]).strftime("%H:%M") for r in rows]
    cpu = [r[1] or 0 for r in rows]
    ram = [r[2] or 0 for r in rows]

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=times, y=cpu, name="CPU %",
        line=dict(color="#6366f1", width=1.5),
        hovertemplate="CPU: <b>%{y:.1f}%</b><extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=times, y=ram, name="RAM %",
        line=dict(color="#f59e0b", width=1.5),
        hovertemplate="RAM: <b>%{y:.1f}%</b><extra></extra>",
    ))
    fig.update_layout(
        height=200,
        margin=dict(l=0, r=0, t=8, b=0),
        xaxis=dict(showgrid=False, nticks=8),
        yaxis=dict(range=[0, 105], title="%", showgrid=True, gridcolor=_GRID_COLOR),
        plot_bgcolor=_PLOT_BG,
        paper_bgcolor=_PAPER_BG,
        font=_FONT,
        legend=dict(orientation="h", y=1.02, x=0),
    )
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# Utility
# ─────────────────────────────────────────────────────────────────────────────

def _empty_fig(message: str) -> go.Figure:
    """Return a blank figure with a centred message."""
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper", yref="paper",
        x=0.5, y=0.5,
        showarrow=False,
        font=dict(size=14, color="#94a3b8"),
    )
    fig.update_layout(
        height=120,
        margin=_MARGIN,
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
        plot_bgcolor=_PAPER_BG,
        paper_bgcolor=_PAPER_BG,
    )
    return fig
