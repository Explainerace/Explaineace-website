"""
focuslens.dashboard.helpers
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Pure-Python utilities shared by the dashboard that are testable
without importing Streamlit or Plotly.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime
from typing import Optional


# ── Category colours (CSS hex) ────────────────────────────────────────────────

CATEGORY_COLORS: dict[str, str] = {
    "productive":  "#22c55e",   # green-500
    "neutral":     "#94a3b8",   # slate-400
    "distracting": "#ef4444",   # red-500
    "idle":        "#e2e8f0",   # slate-200
}

CATEGORY_LABELS = {
    "productive":  "Productive",
    "neutral":     "Neutral",
    "distracting": "Distracting",
    "idle":        "Idle / Locked",
}


def focus_score_color(score: float) -> str:
    """Return a CSS hex color for a focus score value."""
    if score >= 70:
        return "#22c55e"   # green
    elif score >= 40:
        return "#f59e0b"   # amber
    else:
        return "#ef4444"   # red


def focus_score_label(score: float) -> str:
    if score >= 70:
        return "🟢 High"
    elif score >= 40:
        return "🟡 Medium"
    else:
        return "🔴 Low"


# ── Timeline segments ─────────────────────────────────────────────────────────

@dataclass
class TimelineSegment:
    """A merged run of consecutive samples with the same category."""
    start_ts: float
    end_ts: float
    category: str
    app: Optional[str] = None       # dominant app in this span

    @property
    def duration_seconds(self) -> float:
        return self.end_ts - self.start_ts

    @property
    def start_dt(self) -> datetime:
        return datetime.fromtimestamp(self.start_ts)

    @property
    def end_dt(self) -> datetime:
        return datetime.fromtimestamp(self.end_ts)


def merge_to_segments(
    samples: list[tuple],
    cats: list[str],
    gap_cap: float = 30.0,
) -> list[TimelineSegment]:
    """
    Merge consecutive same-category samples into TimelineSegments.

    Args:
        samples: List of raw DB tuples (ts, active_app, ...).
        cats:    Category string for each sample.
        gap_cap: Maximum gap (s) before starting a new segment.

    Returns:
        Sorted list of TimelineSegment objects.
    """
    if not samples:
        return []

    segments: list[TimelineSegment] = []
    seg_start_ts = samples[0][0]
    seg_cat = cats[0]
    seg_app = samples[0][1]       # active_app
    seg_end_ts = samples[0][0]

    for i in range(1, len(samples)):
        ts = samples[i][0]
        cat = cats[i]
        app = samples[i][1]
        gap = ts - samples[i - 1][0]

        if cat == seg_cat and gap <= gap_cap:
            seg_end_ts = ts
            # Keep dominant app (first non-None)
            if seg_app is None and app:
                seg_app = app
        else:
            segments.append(
                TimelineSegment(
                    start_ts=seg_start_ts,
                    end_ts=seg_end_ts + 3.0,   # add one sample width
                    category=seg_cat,
                    app=seg_app,
                )
            )
            seg_start_ts = ts
            seg_cat = cat
            seg_app = app
            seg_end_ts = ts

    segments.append(
        TimelineSegment(
            start_ts=seg_start_ts,
            end_ts=seg_end_ts + 3.0,
            category=seg_cat,
            app=seg_app,
        )
    )
    return segments


# ── Duration formatting ───────────────────────────────────────────────────────

def fmt_seconds(seconds: float) -> str:
    """Format a duration in seconds as 'Xh Ym' or 'Ym Zs'."""
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    h, rem = divmod(seconds, 3600)
    m = rem // 60
    if h > 0:
        return f"{h}h {m:02d}m"
    return f"{m}m"


def fmt_hhmm(ts: float) -> str:
    """Format a unix timestamp as HH:MM."""
    return datetime.fromtimestamp(ts).strftime("%H:%M")


# ── Live tracking detection ───────────────────────────────────────────────────

STATUS_FILE_MAX_AGE = 15.0   # seconds – status file stale after this


def is_tracking_active(store) -> bool:
    """
    Return True if a tracking session is currently running.
    Checks the DB for any session with stopped_at IS NULL.
    """
    try:
        with store._lock:
            cur = store._conn.execute(
                "SELECT COUNT(*) FROM sessions WHERE stopped_at IS NULL"
            )
            return cur.fetchone()[0] > 0
    except Exception:
        return False


def read_status_file(path) -> Optional[dict]:
    """Read the JSON status file written by the menu bar app."""
    import json
    try:
        data = json.loads(path.read_text())
        age = time.time() - data.get("last_updated", 0)
        if age < STATUS_FILE_MAX_AGE:
            return data
    except Exception:
        pass
    return None
