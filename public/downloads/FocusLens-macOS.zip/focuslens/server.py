"""
focuslens.server
~~~~~~~~~~~~~~~~
Unified Cloud Gateway for Railway / Cloud Deployment.

Binds to $PORT (assigned by Railway) and routes:
  • /api/sync   -> Built-in Sync API (receives telemetry from MacBook app)
  • /api/status -> Health & status check
  • /           -> FocusLens Streamlit Dashboard
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from focuslens.db.store import Store
from focuslens.sync.server import SyncRequestHandler
from focuslens.dashboard.demo_data import inject_demo_day
from datetime import date

logger = logging.getLogger("focuslens.server")

_APP_SUPPORT = Path.home() / "Library" / "Application Support" / "FocusLens"
_DB_PATH = _APP_SUPPORT / "focuslens.db"
_PROJECT_ROOT = Path(__file__).parents[1]
_STREAMLIT_PORT = 8501


class UnifiedGatewayHandler(SyncRequestHandler):
    """Handles /api/sync and proxies everything else to the Streamlit backend."""

    def do_GET(self) -> None:
        if self.path in ("/api/status", "/api/health", "/health"):
            super().do_GET()
            return
        self._proxy_to_streamlit("GET")

    def do_POST(self) -> None:
        if self.path == "/api/sync":
            super().do_POST()
            return
        self._proxy_to_streamlit("POST")

    def _proxy_to_streamlit(self, method: str) -> None:
        target_url = f"http://127.0.0.1:{_STREAMLIT_PORT}{self.path}"
        headers = {k: v for k, v in self.headers.items() if k.lower() not in ("host", "content-length")}
        data = None
        if method == "POST":
            length = int(self.headers.get("Content-Length", 0))
            if length > 0:
                data = self.rfile.read(length)

        req = urllib.request.Request(target_url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30.0) as resp:
                content = resp.read()
                self.send_response(resp.status)
                for k, v in resp.headers.items():
                    if k.lower() not in ("transfer-encoding", "content-length"):
                        self.send_header(k, v)
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
        except urllib.error.HTTPError as err:
            body = err.read()
            self.send_response(err.code)
            self.end_headers()
            self.wfile.write(body)
        except Exception as err:
            self.send_response(502)
            self.end_headers()
            self.wfile.write(f"Gateway proxy error: {err}".encode("utf-8"))


def start_streamlit_backend() -> None:
    dash_app = _PROJECT_ROOT / "focuslens" / "dashboard" / "app.py"
    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(dash_app),
        "--server.headless",
        "true",
        "--server.port",
        str(_STREAMLIT_PORT),
        "--server.address",
        "127.0.0.1",
        "--browser.gatherUsageStats",
        "false",
    ]
    subprocess.Popen(cmd, cwd=str(_PROJECT_ROOT))
    time.sleep(2.0)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    port = int(os.environ.get("PORT", 8080))

    _APP_SUPPORT.mkdir(parents=True, exist_ok=True)
    store = Store(_DB_PATH)

    # Pre-populate demo day if empty so web visitors see a full dashboard immediately
    today = date.today()
    if not store.fetch_samples_for_day(today.strftime("%Y-%m-%d")):
        logger.info("Initializing cloud database with sample workday...")
        inject_demo_day(store, today)

    logger.info("Starting Streamlit backend on port %d...", _STREAMLIT_PORT)
    start_streamlit_backend()

    handler_cls = type("CloudGatewayHandler", (UnifiedGatewayHandler,), {
        "store": store,
        "api_key": os.environ.get("FOCUSLENS_API_KEY"),
    })

    server = HTTPServer(("0.0.0.0", port), handler_cls)
    logger.info("🚀 FocusLens Cloud Gateway running on http://0.0.0.0:%d", port)
    server.serve_forever()


if __name__ == "__main__":
    main()
