"""FocusLens – local macOS productivity tracker."""

__version__ = "0.1.0"
