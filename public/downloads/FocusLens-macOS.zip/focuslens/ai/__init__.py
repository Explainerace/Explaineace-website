"""
focuslens.ai
~~~~~~~~~~~~
AI productivity report generation module.
"""

from focuslens.ai.client import AIClient, AIReportResult, OllamaBackend, ClaudeBackend, OfflineMockBackend
from focuslens.ai.prompt import build_prompt

__all__ = [
    "AIClient",
    "AIReportResult",
    "OllamaBackend",
    "ClaudeBackend",
    "OfflineMockBackend",
    "build_prompt",
]
