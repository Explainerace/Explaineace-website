"""
focuslens.ai.prompt
~~~~~~~~~~~~~~~~~~~~
Builds a privacy-safe LLM prompt from DayMetrics + DailyReport.

What is INCLUDED in the prompt:
  • Focus score, time breakdown (percentages and durations)
  • Deep-work block count and total duration (no titles)
  • Context-switch rate, break pattern
  • App names (after blocklist) and time spent
  • Browser domain names and time spent
  • Rule-based findings (title + fix)
  • Last-7-day focus score trend

What is NEVER sent:
  • Window titles
  • Full URLs or query strings
  • Keystroke content
  • Any blocked / sensitive app names
"""

from __future__ import annotations

from datetime import date as Date
from typing import Optional

from focuslens.dashboard.helpers import fmt_seconds
from focuslens.insights.models import DailyReport
from focuslens.metrics.models import DayMetrics


# ── Prompt template ───────────────────────────────────────────────────────────

_SYSTEM_PROMPT = """\
You are a concise, honest productivity coach. You receive aggregated computer \
usage data for one day — no keystroke content, no browsing history, no window \
titles. Your job is to give a clear-eyed analysis of the session and concrete \
advice for tomorrow. Speak in second person ("you"), be specific about the \
numbers, and keep the tone direct but supportive.\
"""

_TEMPLATE = """\
Analyze this productivity data for {date}.

────────────────────────────────────────────
SESSION OVERVIEW
────────────────────────────────────────────
Date         : {date}
Tracked time : {tracked}
Focus score  : {score:.0f} / 100  ({verdict})

TIME BREAKDOWN
────────────────────────────────────────────
Productive   : {p_pct:.0f}%  ({p_time})
Neutral      : {n_pct:.0f}%  ({n_time})
Distracting  : {d_pct:.0f}%  ({d_time})
Idle / locked: {i_pct:.0f}%  ({i_time})

FOCUS QUALITY
────────────────────────────────────────────
Deep-work blocks   : {n_dw} block(s)  ·  {dw_min:.0f} min total
Longest block      : {longest_dw:.0f} min
App switches / hr  : {sw_hr:.1f}
Breaks taken       : {breaks}
Longest stretch    : {stretch:.0f} min without a break

TOP APPS  (by time spent, productive first)
────────────────────────────────────────────
{app_list}

TOP DISTRACTING SITES
────────────────────────────────────────────
{domain_list}

AUTOMATED FINDINGS
────────────────────────────────────────────
{findings_list}

7-DAY FOCUS SCORE TREND  (oldest → today)
────────────────────────────────────────────
{trend_list}

────────────────────────────────────────────

Please write:
1. A 2–3 paragraph narrative — what stands out in this data, what it \
suggests about work habits, and what the person was likely experiencing.
2. Three specific, actionable recommendations for tomorrow (concrete actions, \
not generic advice — reference the actual numbers).
3. One honest closing sentence: encouraging if the day was good, direct if it \
wasn't.

Total response: ~300–400 words.\
"""


# ── Public helper ─────────────────────────────────────────────────────────────

def build_prompt(
    dm: DayMetrics,
    report: DailyReport,
    week_dates: Optional[list[str]] = None,
    week_scores: Optional[list[float]] = None,
) -> tuple[str, str]:
    """
    Build (system_prompt, user_prompt) from the given metrics + report.

    Args:
        dm:          Pre-computed DayMetrics for the day.
        report:      Rule-based DailyReport for the same day.
        week_dates:  ISO date strings for the last 7 days (oldest first).
        week_scores: Corresponding focus scores.

    Returns:
        Tuple of (system_prompt, user_prompt).
    """
    total = dm.total_tracked_seconds or 1  # avoid division by zero

    def _pct(sec: float) -> float:
        return sec / total * 100

    # ── App list ──────────────────────────────────────────────────────────────
    if dm.top_apps:
        app_lines = "\n".join(
            f"  • {a.name:25s} {fmt_seconds(a.seconds):>10s}  [{a.category}]"
            for a in dm.top_apps[:8]
        )
    else:
        app_lines = "  (no app data)"

    # ── Domain list ───────────────────────────────────────────────────────────
    if dm.top_distracting_domains:
        dom_lines = "\n".join(
            f"  • {d.domain:30s} {fmt_seconds(d.seconds):>10s}"
            for d in dm.top_distracting_domains[:6]
        )
    else:
        dom_lines = "  ✅ None recorded"

    # ── Findings list ─────────────────────────────────────────────────────────
    if report.has_enough_data and report.findings:
        finding_lines = "\n".join(
            f"  {f.emoji} [{f.severity.upper()}] {f.title}\n"
            f"     Detail: {f.detail}\n"
            f"     Fix   : {f.fix}"
            for f in report.sorted_findings()
        )
    else:
        finding_lines = "  (no findings — session too short or no issues found)"

    # ── Trend list ────────────────────────────────────────────────────────────
    if week_dates and week_scores:
        trend_lines = "\n".join(
            f"  {d}  →  {s:.0f}" if s > 0 else f"  {d}  →  (no data)"
            for d, s in zip(week_dates, week_scores)
        )
    else:
        trend_lines = "  (no trend data available)"

    # ── Longest deep-work block ───────────────────────────────────────────────
    longest_dw = (
        max(b.duration_minutes for b in dm.deep_work_blocks)
        if dm.deep_work_blocks else 0
    )

    user_prompt = _TEMPLATE.format(
        date=dm.date.strftime("%A, %d %B %Y"),
        tracked=fmt_seconds(dm.total_tracked_seconds),
        score=dm.focus_score,
        verdict=report.overall_verdict if report.has_enough_data else "insufficient data",
        p_pct=_pct(dm.productive_seconds),
        p_time=fmt_seconds(dm.productive_seconds),
        n_pct=_pct(dm.neutral_seconds),
        n_time=fmt_seconds(dm.neutral_seconds),
        d_pct=_pct(dm.distracting_seconds),
        d_time=fmt_seconds(dm.distracting_seconds),
        i_pct=_pct(dm.idle_seconds),
        i_time=fmt_seconds(dm.idle_seconds),
        n_dw=len(dm.deep_work_blocks),
        dw_min=dm.deep_work_minutes,
        longest_dw=longest_dw,
        sw_hr=dm.context_switches_per_hour,
        breaks=dm.break_count,
        stretch=dm.longest_stretch_minutes,
        app_list=app_lines,
        domain_list=dom_lines,
        findings_list=finding_lines,
        trend_list=trend_lines,
    )

    return _SYSTEM_PROMPT, user_prompt
