"""
focuslens.ai CLI
~~~~~~~~~~~~~~~~
Generate and print an AI coaching report from the terminal.

Usage:
    python -m focuslens.ai [--date YYYY-MM-DD] [--provider auto|ollama|claude|offline]
"""

from __future__ import annotations

import argparse
import sys
from datetime import date as Date, datetime, timedelta
from pathlib import Path

from focuslens.ai.client import AIClient
from focuslens.db.store import Store
from focuslens.insights.engine import InsightEngine
from focuslens.metrics.engine import MetricsEngine


def main() -> None:
    parser = argparse.ArgumentParser(description="FocusLens AI Report Generator")
    parser.add_argument("--date", help="Date in YYYY-MM-DD format (default: today)")
    parser.add_argument(
        "--provider",
        choices=["auto", "ollama", "claude", "offline"],
        default="auto",
        help="AI provider to use (default: auto)",
    )
    parser.add_argument(
        "--model",
        help="Model name (e.g. llama3, mistral, claude-3-5-sonnet-20241022)",
    )
    args = parser.parse_args()

    db_path = Path.home() / "Library" / "Application Support" / "FocusLens" / "focuslens.db"
    if not db_path.exists():
        print(f"❌ Database not found at {db_path}. Run the collector first.")
        sys.exit(1)

    store = Store(db_path)
    if args.date:
        try:
            target_date = datetime.strptime(args.date, "%Y-%m-%d").date()
        except ValueError:
            print("❌ Invalid date format. Use YYYY-MM-DD.")
            sys.exit(1)
    else:
        target_date = Date.today()

    date_str = target_date.strftime("%Y-%m-%d")
    samples = store.fetch_samples_for_day(date_str)
    stats = store.fetch_system_stats_for_day(date_str)

    if not samples:
        print(f"⚠️ No telemetry samples found for {date_str}.")
        sys.exit(0)

    print(f"🔭 Analyzing {date_str} ({len(samples)} samples)...")
    m_engine = MetricsEngine()
    dm = m_engine.compute_day(target_date, samples)

    i_engine = InsightEngine()
    report = i_engine.analyse(dm, sys_stats=stats)

    # 7-day trend
    week_dates = [(target_date - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(6, -1, -1)]
    week_scores = []
    for d in week_dates:
        rows = store.fetch_samples_for_day(d)
        if rows:
            wdm = m_engine.compute_day(datetime.strptime(d, "%Y-%m-%d").date(), rows)
            week_scores.append(wdm.focus_score)
        else:
            week_scores.append(0.0)

    client_kwargs = {"provider": args.provider}
    if args.model:
        if args.provider == "ollama":
            client_kwargs["ollama_model"] = args.model
        elif args.provider == "claude":
            client_kwargs["claude_model"] = args.model

    client = AIClient(**client_kwargs)
    backend = client.select_backend()
    print(f"🤖 Dispatching to AI provider: {backend.name} ({getattr(backend, 'model', 'default')})...\n")

    result = client.generate_report(dm, report, week_dates, week_scores)
    if not result.success:
        print(f"❌ Error generating report: {result.error}")
        sys.exit(1)

    print("════════════════════════════════════════════════════════════════════")
    print(result.content)
    print("════════════════════════════════════════════════════════════════════")


if __name__ == "__main__":
    main()
