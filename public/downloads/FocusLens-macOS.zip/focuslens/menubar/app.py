"""
focuslens.menubar.app
~~~~~~~~~~~~~~~~~~~~~~
rumps-based macOS menu-bar app for FocusLens.

Menu bar title:
  🔭        – idle
  🟢 00:00  – tracking
  ⏸ 00:00  – paused

Menu items:
  ▶  Start Tracking     (enabled when idle/paused)
  ⏸  Pause              (enabled when running)
  ⏹  Stop               (enabled when running/paused)
  ─────────────────────
  📊  Open Dashboard
  ─────────────────────
  🗑  Delete All Data
  ─────────────────────
  Quit FocusLens

The collector (sampler + system-stats) runs in background daemon threads.
A 1-second rumps timer updates the title and writes a status JSON file so
the dashboard can show the live indicator.
"""

from __future__ import annotations

import json
import logging
import subprocess
import sys
import threading
import time
from pathlib import Path

import rumps

logger = logging.getLogger(__name__)

# ── Paths ─────────────────────────────────────────────────────────────────────

_APP_SUPPORT = Path.home() / "Library" / "Application Support" / "FocusLens"
_DB_PATH = _APP_SUPPORT / "focuslens.db"
_STATUS_PATH = _APP_SUPPORT / "status.json"
_PROJECT_ROOT = Path(__file__).parents[2]
_DASHBOARD_APP = _PROJECT_ROOT / "focuslens" / "dashboard" / "app.py"


def start_streamlit_daemon(port: int = 8501) -> None:
    """Ensure Streamlit daemon is running."""
    import urllib.request

    url = f"http://localhost:{port}/_stcore/health"
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=1.0) as resp:
            if resp.status == 200:
                return
    except Exception:
        pass

    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(_DASHBOARD_APP),
        "--server.headless",
        "true",
        "--browser.gatherUsageStats",
        "false",
        "--server.port",
        str(port),
    ]
    subprocess.Popen(
        cmd,
        cwd=str(_PROJECT_ROOT),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    # Wait briefly for startup
    start_t = time.time()
    while time.time() - start_t < 6.0:
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                if resp.status == 200:
                    break
        except Exception:
            time.sleep(0.3)


def launch_dashboard(port: int = 8501) -> None:
    """Open the dashboard in standalone desktop app mode if available, or default browser."""
    start_streamlit_daemon(port=port)
    url = f"http://localhost:{port}"

    # Try standalone app window mode with Chrome / Brave / Edge
    for browser in ("Google Chrome", "Brave Browser", "Microsoft Edge"):
        res = subprocess.run(
            ["osascript", "-e", f'id of app "{browser}"'],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if res.returncode == 0:
            subprocess.Popen(["open", "-na", browser, "--args", f"--app={url}"])
            return

    # Fallback to default browser
    subprocess.Popen(["open", url])


# ── States ────────────────────────────────────────────────────────────────────

class _State:
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"


# ── App ───────────────────────────────────────────────────────────────────────

class FocusLensApp(rumps.App):
    """FocusLens menu-bar application."""

    def __init__(self) -> None:
        super().__init__(name="FocusLens", title="🔭", quit_button=None)

        # ── Menu structure ────────────────────────────────────────────────────
        self._item_start = rumps.MenuItem("▶  Start Tracking", callback=self._on_start)
        self._item_pause = rumps.MenuItem("⏸  Pause")
        self._item_stop  = rumps.MenuItem("⏹  Stop")
        self._item_dash  = rumps.MenuItem("📊  Open Dashboard", callback=self._on_open_dashboard)
        self._item_del   = rumps.MenuItem("🗑  Delete All Data", callback=self._on_delete_data)
        self._item_quit  = rumps.MenuItem("Quit FocusLens", callback=self._on_quit)

        self.menu = [
            self._item_start,
            self._item_pause,
            self._item_stop,
            None,
            self._item_dash,
            None,
            self._item_del,
            None,
            self._item_quit,
        ]
        self._set_state(_State.IDLE)

        # ── Backend objects (created lazily on start) ─────────────────────────
        self._store = None
        self._session_mgr = None
        self._sampler = None
        self._stats_collector = None
        self._sampler_thread: threading.Thread | None = None
        self._stats_thread: threading.Thread | None = None
        self._dashboard_proc: subprocess.Popen | None = None

    # ------------------------------------------------------------------
    # State management
    # ------------------------------------------------------------------

    def _set_state(self, state: str) -> None:
        self._state = state

        # Enable / disable items
        can_start  = state in (_State.IDLE, _State.PAUSED)
        can_pause  = state == _State.RUNNING
        can_stop   = state in (_State.RUNNING, _State.PAUSED)

        self._item_start.set_callback(self._on_start if can_start else None)
        self._item_pause.set_callback(self._on_pause if can_pause else None)
        self._item_stop.set_callback(self._on_stop if can_stop else None)

        # Dim label of disabled items
        self._item_start.title = "▶  Start Tracking" + ("" if can_start else " ·")
        self._item_pause.title = "⏸  Pause"          + ("" if can_pause else " ·")
        self._item_stop.title  = "⏹  Stop"           + ("" if can_stop  else " ·")

    # ------------------------------------------------------------------
    # Timer tick (every 1 s)
    # ------------------------------------------------------------------

    @rumps.timer(1)
    def _tick(self, _) -> None:
        if self._state == _State.RUNNING and self._session_mgr:
            info = self._session_mgr.current
            if info:
                elapsed = info.elapsed_display()
                self.title = f"🟢 {elapsed}"
                self._write_status(info)
        elif self._state == _State.PAUSED and self._session_mgr:
            info = self._session_mgr.current
            if info:
                elapsed = info.elapsed_display()
                self.title = f"⏸ {elapsed}"
        else:
            self.title = "🔭"

    def _write_status(self, info) -> None:
        try:
            _STATUS_PATH.write_text(json.dumps({
                "state":   self._state,
                "session_id": info.session_id,
                "started_at": info.started_at,
                "elapsed_seconds": info.elapsed_seconds(),
                "last_updated": time.time(),
            }))
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def _on_start(self, _) -> None:
        if self._state == _State.PAUSED and self._session_mgr:
            # Resume existing session
            self._session_mgr.resume()
            self._restart_sampler()
            self._set_state(_State.RUNNING)
            return

        # Fresh start
        try:
            self._boot_backend()
        except Exception as exc:
            rumps.alert("FocusLens Error", f"Could not start tracking:\n{exc}")
            logger.exception("start error")
            return

        self._set_state(_State.RUNNING)
        rumps.notification(
            "FocusLens",
            "Tracking started",
            "Recording your activity. Press Stop when done.",
            sound=False,
        )

    def _on_pause(self, _) -> None:
        if self._session_mgr:
            self._session_mgr.pause()
        if self._sampler:
            self._sampler.stop()
        self._set_state(_State.PAUSED)

    def _on_stop(self, _) -> None:
        self._shutdown_workers()
        if self._session_mgr:
            info = self._session_mgr.stop()
            if info:
                elapsed = info.elapsed_display()
                rumps.notification(
                    "FocusLens",
                    f"Session stopped ({elapsed})",
                    "Open the dashboard to see your stats.",
                    sound=False,
                )
        self._set_state(_State.IDLE)
        self.title = "🔭"
        _STATUS_PATH.unlink(missing_ok=True)

    def _on_open_dashboard(self, _) -> None:
        """Open the FocusLens dashboard in standalone app window or default browser."""
        launch_dashboard(port=8501)

    def _on_delete_data(self, _) -> None:
        response = rumps.alert(
            title="Delete All FocusLens Data",
            message=(
                "This will permanently delete ALL your tracking data "
                "(samples, sessions, system stats).\n\nThis cannot be undone."
            ),
            ok="Delete Everything",
            cancel="Cancel",
        )
        if response.clicked == 1:   # "Delete Everything"
            if self._store:
                self._store.delete_all_data()
            rumps.notification(
                "FocusLens", "Data Deleted",
                "All tracking data has been permanently deleted.",
                sound=False,
            )

    def _on_quit(self, _) -> None:
        if self._state in (_State.RUNNING, _State.PAUSED):
            self._on_stop(None)
        if self._dashboard_proc and self._dashboard_proc.poll() is None:
            self._dashboard_proc.terminate()
        rumps.quit_application()

    # ------------------------------------------------------------------
    # Backend management
    # ------------------------------------------------------------------

    def _boot_backend(self) -> None:
        """Initialise the DB, session, sampler, and stats-collector."""
        from focuslens.collector.permissions import check_all
        from focuslens.collector.sampler import Blocklist, Sampler
        from focuslens.collector.session import SessionManager
        from focuslens.collector.system_stats import SystemStatsCollector
        from focuslens.db.store import Store

        _APP_SUPPORT.mkdir(parents=True, exist_ok=True)

        perm = check_all(prompt_accessibility=True)
        if not perm.can_track:
            raise RuntimeError(
                "Accessibility permission not granted.\n"
                "System Settings → Privacy & Security → Accessibility"
            )

        if self._store is None:
            self._store = Store(_DB_PATH)

        self._session_mgr = SessionManager(self._store)
        session = self._session_mgr.start(note="Menu bar session")

        blocklist = Blocklist()
        self._sampler = Sampler(
            store=self._store,
            session_id=session.session_id,
            blocklist=blocklist,
            has_automation=perm.automation,
        )
        self._stats_collector = SystemStatsCollector(
            store=self._store,
            session_id=session.session_id,
        )
        self._start_threads()

    def _start_threads(self) -> None:
        self._sampler_thread = threading.Thread(
            target=self._sampler.start, name="fl-sampler", daemon=True
        )
        self._stats_thread = threading.Thread(
            target=self._stats_collector.start, name="fl-stats", daemon=True
        )
        self._sampler_thread.start()
        self._stats_thread.start()

    def _restart_sampler(self) -> None:
        """Restart the sampler thread after a resume."""
        if self._sampler:
            self._sampler._running = False   # ensure old thread exits
        if self._sampler_thread and self._sampler_thread.is_alive():
            self._sampler_thread.join(timeout=2)
        if self._sampler:
            self._sampler._running = True
            self._sampler_thread = threading.Thread(
                target=self._sampler.start, name="fl-sampler", daemon=True
            )
            self._sampler_thread.start()

    def _shutdown_workers(self) -> None:
        if self._sampler:
            self._sampler.stop()
        if self._stats_collector:
            self._stats_collector.stop()
        if self._sampler_thread and self._sampler_thread.is_alive():
            self._sampler_thread.join(timeout=4)
        if self._stats_thread and self._stats_thread.is_alive():
            self._stats_thread.join(timeout=4)


def run() -> None:
    """Entry point for the menu-bar app."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(name)s – %(message)s",
    )
    app = FocusLensApp()
    app.run()
