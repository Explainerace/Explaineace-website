"""Allow `python -m focuslens.menubar` to launch the menu-bar app."""
from focuslens.menubar import run
run()
