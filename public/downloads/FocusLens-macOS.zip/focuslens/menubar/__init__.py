"""focuslens.menubar – public API."""
from focuslens.menubar.app import run

__all__ = ["run"]
