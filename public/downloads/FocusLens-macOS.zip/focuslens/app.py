"""
focuslens.app
~~~~~~~~~~~~~
Unified macOS Application Entry Point for FocusLens.app.

Starts:
1. Streamlit analytics engine daemon (on localhost:8501).
2. Standalone Dashboard application window (Chrome/Brave/Edge app-mode or default browser).
3. Native Menu-Bar app (🔭 in macOS status bar on the main event thread).
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

from focuslens.menubar.app import FocusLensApp, launch_dashboard, start_streamlit_daemon

logger = logging.getLogger("focuslens.app")


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    logger.info("Initializing FocusLens native application...")

    # 1. Start the Streamlit daemon in background
    start_streamlit_daemon(port=8501)

    # 2. Launch the desktop dashboard window
    logger.info("Opening dashboard window...")
    launch_dashboard(port=8501)

    # 3. Run the menu bar app on the main thread (required by macOS Cocoa event loop)
    logger.info("Running menu bar status item on main thread...")
    app = FocusLensApp()
    app.run()


if __name__ == "__main__":
    main()
