"""
focuslens.metrics.models
~~~~~~~~~~~~~~~~~~~~~~~~~
Pure data classes for all metric outputs.  No computation here –
just typed containers that the engine returns and the dashboard consumes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date as Date
from typing import Optional


@dataclass
class DeepWorkBlock:
    """A contiguous span of ≥25 min in productive apps with < 60 s idle."""
    start_ts: float           # unix timestamp
    end_ts: float             # unix timestamp
    duration_minutes: float
    primary_app: str          # most-frequent app during this block


@dataclass
class HourMetrics:
    """Metrics for a single clock-hour (0-23) within a day."""
    hour: int                      # 0–23
    productive_seconds: float = 0
    neutral_seconds: float = 0
    distracting_seconds: float = 0
    idle_seconds: float = 0
    focus_score: float = 0         # 0–100, computed from this hour only
    context_switches: int = 0

    @property
    def active_seconds(self) -> float:
        return self.productive_seconds + self.neutral_seconds + self.distracting_seconds

    @property
    def total_seconds(self) -> float:
        return self.active_seconds + self.idle_seconds


@dataclass
class AppUsage:
    name: str
    seconds: float
    category: str


@dataclass
class DomainUsage:
    domain: str
    seconds: float
    category: str


@dataclass
class DayMetrics:
    """Complete productivity metrics for one calendar day."""
    date: Date

    # ── Time buckets ──────────────────────────────────────────────────
    productive_seconds: float = 0
    neutral_seconds: float = 0
    distracting_seconds: float = 0
    idle_seconds: float = 0        # idle + screen-locked time

    # ── Focus score ───────────────────────────────────────────────────
    focus_score: float = 0         # 0–100

    # ── Deep work ─────────────────────────────────────────────────────
    deep_work_blocks: list[DeepWorkBlock] = field(default_factory=list)

    @property
    def deep_work_minutes(self) -> float:
        return sum(b.duration_minutes for b in self.deep_work_blocks)

    # ── Context switches ──────────────────────────────────────────────
    context_switches: int = 0
    context_switches_per_hour: float = 0

    # ── Break pattern ─────────────────────────────────────────────────
    longest_stretch_minutes: float = 0   # longest run without a break
    break_count: int = 0

    # ── Hour breakdown ────────────────────────────────────────────────
    hourly: list[HourMetrics] = field(default_factory=list)

    @property
    def best_hour(self) -> Optional[int]:
        active = [h for h in self.hourly if h.active_seconds >= 60]
        return max(active, key=lambda h: h.focus_score).hour if active else None

    @property
    def worst_hour(self) -> Optional[int]:
        active = [h for h in self.hourly if h.active_seconds >= 60]
        return min(active, key=lambda h: h.focus_score).hour if active else None

    # ── Top apps / domains ────────────────────────────────────────────
    top_apps: list[AppUsage] = field(default_factory=list)
    top_distracting_domains: list[DomainUsage] = field(default_factory=list)

    # ── Convenience properties ────────────────────────────────────────
    @property
    def active_seconds(self) -> float:
        return self.productive_seconds + self.neutral_seconds + self.distracting_seconds

    @property
    def total_tracked_seconds(self) -> float:
        return self.active_seconds + self.idle_seconds


@dataclass
class WeekTrend:
    """Focus score and totals for each day in a rolling 7-day window."""
    days: list[DayMetrics] = field(default_factory=list)

    @property
    def avg_focus_score(self) -> float:
        scored = [d for d in self.days if d.total_tracked_seconds >= 60]
        if not scored:
            return 0.0
        return sum(d.focus_score for d in scored) / len(scored)

    @property
    def avg_productive_minutes(self) -> float:
        if not self.days:
            return 0.0
        return sum(d.productive_seconds / 60 for d in self.days) / len(self.days)
