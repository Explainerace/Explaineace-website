"""
focuslens.metrics.categorizer
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Map a (active_app, browser_domain) pair to one of four categories:
  "productive" | "neutral" | "distracting" | "idle"

"idle" is never stored in categories.yaml; it is inferred by the engine
from the sample's idle_seconds / screen_locked fields.

Loading priority (first match wins):
  1. Per-project overrides (optional, passed at runtime)
  2. Global categories.yaml
  3. Default value from categories.yaml ("default:" key)
  4. Hardcoded fallback → "neutral"

Browser domain beats app name when both are present and the app is a
known browser, because the domain is more informative than "Chrome".
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import yaml

logger = logging.getLogger(__name__)

_DEFAULT_CONFIG = Path(__file__).parents[3] / "config" / "categories.yaml"

# Known browser app names; when active_app is one of these we prefer
# the domain lookup over the app-name lookup.
_BROWSER_APPS = frozenset(
    {
        "safari",
        "google chrome",
        "google chrome canary",
        "arc",
        "brave browser",
        "firefox",
        "opera",
        "microsoft edge",
    }
)

VALID_CATEGORIES = frozenset({"productive", "neutral", "distracting", "idle"})


class Categorizer:
    """
    Categorise activity samples using categories.yaml.

    Args:
        config_path: Path to categories.yaml.
        overrides: Optional dict with same structure as categories.yaml;
                   entries here take precedence (for per-project use).
    """

    def __init__(
        self,
        config_path: Path = _DEFAULT_CONFIG,
        overrides: Optional[dict] = None,
    ) -> None:
        self._apps: dict[str, str] = {}          # lower-case app name → category
        self._domains: dict[str, str] = {}       # lower-case domain → category
        self._default: str = "neutral"
        self._load(config_path)
        if overrides:
            self._apply(overrides)

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def _load(self, path: Path) -> None:
        if not path.exists():
            logger.warning("categories.yaml not found at %s – using neutral default", path)
            return
        try:
            with open(path) as fh:
                data = yaml.safe_load(fh) or {}
            self._apply(data)
            logger.info("Categories loaded from %s", path)
        except Exception as exc:
            logger.error("Failed to load categories.yaml: %s", exc)

    def _apply(self, data: dict) -> None:
        """Merge a category dict (apps / domains / default) into the tables."""
        for app, cat in (data.get("apps") or {}).items():
            cat = _normalise(cat)
            if cat:
                self._apps[app.lower()] = cat

        for domain, cat in (data.get("domains") or {}).items():
            cat = _normalise(cat)
            if cat:
                self._domains[domain.lower()] = cat

        default_raw = data.get("default")
        if default_raw:
            default_norm = _normalise(default_raw)
            if default_norm:
                self._default = default_norm

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def categorise(
        self,
        active_app: Optional[str],
        browser_domain: Optional[str],
    ) -> str:
        """
        Return "productive", "neutral", or "distracting".
        ("idle" is determined by the engine, not the categorizer.)

        Domain lookup takes priority for browser apps.
        """
        # 1. Domain lookup (only when app is a browser)
        if browser_domain and active_app:
            if active_app.lower() in _BROWSER_APPS:
                domain_cat = self._domains.get(browser_domain.lower())
                if domain_cat:
                    return domain_cat

        # 2. App name lookup
        if active_app:
            app_cat = self._apps.get(active_app.lower())
            if app_cat:
                return app_cat

        # 3. Domain lookup even for non-browser apps (fallback)
        if browser_domain:
            domain_cat = self._domains.get(browser_domain.lower())
            if domain_cat:
                return domain_cat

        return self._default

    def all_apps(self) -> dict[str, str]:
        """Return a copy of the app→category mapping."""
        return dict(self._apps)

    def all_domains(self) -> dict[str, str]:
        """Return a copy of the domain→category mapping."""
        return dict(self._domains)


def _normalise(value: str) -> Optional[str]:
    """Lower-case and validate a category string."""
    v = value.strip().lower()
    if v in VALID_CATEGORIES:
        return v
    logger.warning("Unknown category %r – ignoring", value)
    return None
