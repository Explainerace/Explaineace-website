"""
focuslens.metrics.engine
~~~~~~~~~~~~~~~~~~~~~~~~~
Core metric computation engine.

All inputs are raw sample rows from the DB.  No pandas — pure stdlib.

─────────────────────────────────────────────────────────────────────────────
TIME ACCOUNTING
─────────────────────────────────────────────────────────────────────────────
Each sample represents the activity at that moment.  We assign it a weight
equal to the gap to the next sample (capped at MAX_GAP_SECONDS to avoid
inflating totals if the collector was paused).

A sample is classified as "idle" when:
  • screen_locked == 1, OR
  • idle_seconds >= IDLE_THRESHOLD (user hasn't typed/clicked for ≥ 30 s)

Otherwise its category comes from the Categorizer.

─────────────────────────────────────────────────────────────────────────────
FOCUS SCORE  (0 – 100)
─────────────────────────────────────────────────────────────────────────────

  base          = productive_seconds / active_seconds          (0–1)
  continuity    = min(1, deep_work_minutes / 90)               (0–1, cap 90 min)
  switch_factor = max(0, 1 - context_switches_per_hour / 20)   (0–1, 0 at 20+ sw/h)

  focus_score   = (base * 50) + (continuity * 30) + (switch_factor * 20)

Rationale: productive time is the biggest lever (50 pts), uninterrupted
focus blocks are the quality signal (30 pts), and low fragmentation adds
the remainder (20 pts).

─────────────────────────────────────────────────────────────────────────────
DEEP-WORK BLOCKS
─────────────────────────────────────────────────────────────────────────────
A contiguous run of samples that are ALL:
  • category == "productive"
  • idle_seconds < DEEP_WORK_MAX_IDLE  (60 s – short distraction gap tolerated)
  • screen_locked == 0

The run must span ≥ DEEP_WORK_MIN_MINUTES (25 min) total weighted time.

─────────────────────────────────────────────────────────────────────────────
CONTEXT SWITCHES
─────────────────────────────────────────────────────────────────────────────
Count transitions where active_app changes to a *different* non-None app.
Transitions from/to idle (idle_seconds ≥ IDLE_THRESHOLD) are excluded –
returning from a break is not a context switch.

─────────────────────────────────────────────────────────────────────────────
BREAK PATTERN
─────────────────────────────────────────────────────────────────────────────
A "break" begins when a sample is idle AND the previous sample was active.
A break ends when the next active sample appears.  A run of active samples
constitutes a "stretch".  The longest stretch (in minutes) and total break
count are reported.
"""

from __future__ import annotations

import collections
import logging
from collections import defaultdict
from datetime import date as Date, datetime, timezone
from typing import Iterator, Optional, Sequence

from focuslens.metrics.categorizer import Categorizer
from focuslens.metrics.models import (
    AppUsage,
    DayMetrics,
    DeepWorkBlock,
    DomainUsage,
    HourMetrics,
    WeekTrend,
)

logger = logging.getLogger(__name__)

# ── Tuneable constants ────────────────────────────────────────────────────────

SAMPLE_INTERVAL = 3.0            # expected seconds between samples
MAX_GAP_SECONDS = 30.0           # cap weight if collector was paused
IDLE_THRESHOLD = 30.0            # idle_seconds ≥ this → classify as idle
DEEP_WORK_MIN_MINUTES = 25.0     # minimum block length to count as deep work
DEEP_WORK_MAX_IDLE = 60.0        # tolerate up to 60 s idle inside a deep block
BREAK_MIN_SECONDS = 120.0        # idle span ≥ this counts as a real break
TOP_N = 10                       # how many apps / domains in top lists


# ── Raw sample namedtuple ────────────────────────────────────────────────────

class _Sample:
    """Lightweight wrapper around a DB row."""

    __slots__ = (
        "ts", "active_app", "window_title", "browser_domain",
        "idle_seconds", "screen_locked", "kb_events", "mouse_events",
        "weight",
    )

    def __init__(self, row: tuple) -> None:
        (
            self.ts,
            self.active_app,
            self.window_title,
            self.browser_domain,
            self.idle_seconds,
            self.screen_locked,
            self.kb_events,
            self.mouse_events,
        ) = row
        self.idle_seconds = self.idle_seconds or 0.0
        self.screen_locked = bool(self.screen_locked)
        self.kb_events = self.kb_events or 0
        self.mouse_events = self.mouse_events or 0
        self.weight: float = SAMPLE_INTERVAL  # set by engine after lookahead


# ── Engine ────────────────────────────────────────────────────────────────────

class MetricsEngine:
    """
    Compute productivity metrics from raw DB rows.

    Args:
        categorizer: Categorizer instance (uses default config if None).
        db_store: Optional Store instance for convenience queries.
                  If None, you must pass raw rows to compute_from_rows().
    """

    def __init__(
        self,
        categorizer: Optional[Categorizer] = None,
        db_store=None,
    ) -> None:
        self._cat = categorizer or Categorizer()
        self._store = db_store

    # ------------------------------------------------------------------
    # Public entry points
    # ------------------------------------------------------------------

    def compute_day(self, target_date: Date, rows: Sequence[tuple]) -> DayMetrics:
        """
        Compute full DayMetrics from raw DB rows for one calendar day.

        Args:
            target_date: The date being analysed.
            rows: Sequence of tuples from the samples table, ordered by ts ASC.
                  Each tuple: (ts, active_app, window_title, browser_domain,
                               idle_seconds, screen_locked, kb_events, mouse_events)
        """
        samples = _assign_weights(list(map(_Sample, rows)))
        return self._build_day_metrics(target_date, samples)

    def compute_week_trend(
        self, dates: Sequence[Date], rows_by_date: dict[Date, Sequence[tuple]]
    ) -> WeekTrend:
        """Compute a WeekTrend for multiple days."""
        days = [
            self.compute_day(d, rows_by_date.get(d, []))
            for d in dates
        ]
        return WeekTrend(days=days)

    # ------------------------------------------------------------------
    # Core computation
    # ------------------------------------------------------------------

    def _build_day_metrics(self, date: Date, samples: list[_Sample]) -> DayMetrics:
        if not samples:
            return DayMetrics(date=date)

        # ── Per-sample categorisation ─────────────────────────────────
        cats: list[str] = []
        for s in samples:
            if s.screen_locked or s.idle_seconds >= IDLE_THRESHOLD:
                cats.append("idle")
            else:
                cats.append(self._cat.categorise(s.active_app, s.browser_domain))

        # ── Time buckets ──────────────────────────────────────────────
        time_by_cat: dict[str, float] = defaultdict(float)
        for s, cat in zip(samples, cats):
            time_by_cat[cat] += s.weight

        productive_s = time_by_cat["productive"]
        neutral_s = time_by_cat["neutral"]
        distracting_s = time_by_cat["distracting"]
        idle_s = time_by_cat["idle"]
        active_s = productive_s + neutral_s + distracting_s

        # ── Context switches ──────────────────────────────────────────
        switches, switches_per_hour = _context_switches(samples, cats)

        # ── Deep-work blocks ──────────────────────────────────────────
        deep_blocks = _deep_work_blocks(samples, cats)

        # ── Break pattern ─────────────────────────────────────────────
        longest_stretch, break_count = _break_pattern(samples, cats)

        # ── Focus score ───────────────────────────────────────────────
        focus = _focus_score(productive_s, active_s, deep_blocks, switches_per_hour)

        # ── Hourly breakdown ──────────────────────────────────────────
        hourly = _hourly_metrics(samples, cats, self._cat)

        # ── Top apps / domains ────────────────────────────────────────
        top_apps = _top_apps(samples, cats, self._cat)
        top_domains = _top_distracting_domains(samples, cats)

        return DayMetrics(
            date=date,
            productive_seconds=productive_s,
            neutral_seconds=neutral_s,
            distracting_seconds=distracting_s,
            idle_seconds=idle_s,
            focus_score=focus,
            deep_work_blocks=deep_blocks,
            context_switches=switches,
            context_switches_per_hour=switches_per_hour,
            longest_stretch_minutes=longest_stretch,
            break_count=break_count,
            hourly=hourly,
            top_apps=top_apps,
            top_distracting_domains=top_domains,
        )


# ── Helper functions ──────────────────────────────────────────────────────────

def _assign_weights(samples: list[_Sample]) -> list[_Sample]:
    """
    Set each sample's weight = gap to next sample, capped at MAX_GAP_SECONDS.
    The last sample gets SAMPLE_INTERVAL as its weight.
    """
    for i, s in enumerate(samples):
        if i + 1 < len(samples):
            gap = samples[i + 1].ts - s.ts
            s.weight = min(gap, MAX_GAP_SECONDS)
        else:
            s.weight = SAMPLE_INTERVAL
    return samples


def _focus_score(
    productive_s: float,
    active_s: float,
    deep_blocks: list[DeepWorkBlock],
    switches_per_hour: float,
) -> float:
    """
    Compute focus score 0–100.

    Score = (base * 50) + (continuity * 30) + (switch_factor * 20)

      base          = productive / active              (0–1)
      continuity    = min(1, deep_work_minutes / 90)  (caps at 90 min)
      switch_factor = max(0, 1 - sw_per_hour / 20)    (0 at 20+ switches/hr)
    """
    if active_s < 60:
        return 0.0

    base = productive_s / active_s                              # 0–1
    deep_min = sum(b.duration_minutes for b in deep_blocks)
    continuity = min(1.0, deep_min / 90.0)                     # 0–1
    switch_factor = max(0.0, 1.0 - switches_per_hour / 20.0)   # 0–1

    score = base * 50.0 + continuity * 30.0 + switch_factor * 20.0
    return round(min(100.0, max(0.0, score)), 1)


def _context_switches(
    samples: list[_Sample], cats: list[str]
) -> tuple[int, float]:
    """
    Count app-level context switches and return (count, switches_per_active_hour).

    A switch is a transition from app A → app B where:
      • both A and B are not None
      • A != B
      • the current sample is NOT idle
      • the previous non-idle sample was also not idle
    """
    switches = 0
    active_seconds = 0.0
    prev_app: Optional[str] = None

    for s, cat in zip(samples, cats):
        if cat == "idle":
            continue
        active_seconds += s.weight
        cur_app = s.active_app
        if cur_app and prev_app and cur_app != prev_app:
            switches += 1
        if cur_app:
            prev_app = cur_app

    active_hours = active_seconds / 3600.0
    per_hour = switches / active_hours if active_hours >= 0.1 else 0.0
    return switches, round(per_hour, 2)


def _deep_work_blocks(
    samples: list[_Sample], cats: list[str]
) -> list[DeepWorkBlock]:
    """
    Find all contiguous productive runs of ≥ DEEP_WORK_MIN_MINUTES.
    Short idle gaps (< DEEP_WORK_MAX_IDLE) inside a productive run
    do NOT break the block.
    """
    blocks: list[DeepWorkBlock] = []
    in_block = False
    block_start_ts = 0.0
    block_duration = 0.0
    app_counts: dict[str, float] = defaultdict(float)

    def _close_block(end_ts: float) -> None:
        nonlocal in_block, block_duration, app_counts
        if block_duration >= DEEP_WORK_MIN_MINUTES * 60:
            primary = max(app_counts, key=app_counts.get)  # type: ignore
            blocks.append(
                DeepWorkBlock(
                    start_ts=block_start_ts,
                    end_ts=end_ts,
                    duration_minutes=round(block_duration / 60, 1),
                    primary_app=primary,
                )
            )
        in_block = False
        block_duration = 0.0
        app_counts = defaultdict(float)

    for s, cat in zip(samples, cats):
        if cat == "productive" and not s.screen_locked:
            if not in_block:
                in_block = True
                block_start_ts = s.ts
                block_duration = 0.0
                app_counts = defaultdict(float)
            block_duration += s.weight
            if s.active_app:
                app_counts[s.active_app] += s.weight

        elif cat == "idle" and in_block and s.idle_seconds < DEEP_WORK_MAX_IDLE:
            # Tolerate short idle gaps inside a block
            block_duration += s.weight

        else:
            if in_block:
                _close_block(s.ts)

    # Close any open block at end of data
    if in_block and samples:
        _close_block(samples[-1].ts + samples[-1].weight)

    return blocks


def _break_pattern(
    samples: list[_Sample], cats: list[str]
) -> tuple[float, int]:
    """
    Return (longest_stretch_minutes, break_count).

    A "stretch" is a run of active (non-idle) samples.
    A "break" is a contiguous run of idle samples whose total weighted
    time ≥ BREAK_MIN_SECONDS.
    """
    longest_stretch = 0.0
    break_count = 0
    current_stretch = 0.0
    current_idle_run = 0.0
    was_active_before = False

    for s, cat in zip(samples, cats):
        if cat != "idle":
            if current_idle_run >= BREAK_MIN_SECONDS and was_active_before:
                break_count += 1
                longest_stretch = max(longest_stretch, current_stretch)
                current_stretch = 0.0
            current_idle_run = 0.0
            was_active_before = True
            current_stretch += s.weight
        else:
            current_idle_run += s.weight

    # Final active stretch
    if was_active_before:
        longest_stretch = max(longest_stretch, current_stretch)

    return round(longest_stretch / 60, 1), break_count


def _hourly_metrics(
    samples: list[_Sample],
    cats: list[str],
    categorizer: Categorizer,
) -> list[HourMetrics]:
    """Build per-hour HourMetrics list (only hours with data)."""
    hours: dict[int, HourMetrics] = {}
    prev_app_by_hour: dict[int, Optional[str]] = defaultdict(lambda: None)

    for s, cat in zip(samples, cats):
        dt = datetime.fromtimestamp(s.ts)
        h = dt.hour
        if h not in hours:
            hours[h] = HourMetrics(hour=h)
        hm = hours[h]

        if cat == "productive":
            hm.productive_seconds += s.weight
        elif cat == "neutral":
            hm.neutral_seconds += s.weight
        elif cat == "distracting":
            hm.distracting_seconds += s.weight
        else:
            hm.idle_seconds += s.weight

        # Context switches per hour
        if cat != "idle" and s.active_app:
            prev = prev_app_by_hour[h]
            if prev and prev != s.active_app:
                hm.context_switches += 1
            prev_app_by_hour[h] = s.active_app

    # Compute hourly focus scores
    for hm in hours.values():
        active_s = hm.active_seconds
        if active_s >= 60:
            base = hm.productive_seconds / active_s
            sw_factor = max(0.0, 1.0 - hm.context_switches / 10.0)
            hm.focus_score = round(min(100.0, base * 70.0 + sw_factor * 30.0), 1)

    return sorted(hours.values(), key=lambda hm: hm.hour)


def _top_apps(
    samples: list[_Sample],
    cats: list[str],
    categorizer: Categorizer,
) -> list[AppUsage]:
    """Top apps by time spent, all categories."""
    time_map: dict[str, float] = defaultdict(float)
    for s, cat in zip(samples, cats):
        if cat != "idle" and s.active_app:
            time_map[s.active_app] += s.weight

    results = []
    for app, secs in sorted(time_map.items(), key=lambda x: -x[1])[:TOP_N]:
        cat = categorizer.categorise(app, None)
        results.append(AppUsage(name=app, seconds=round(secs, 1), category=cat))
    return results


def _top_distracting_domains(
    samples: list[_Sample],
    cats: list[str],
) -> list[DomainUsage]:
    """Top distracting browser domains by time spent."""
    time_map: dict[str, float] = defaultdict(float)
    for s, cat in zip(samples, cats):
        if cat == "distracting" and s.browser_domain:
            time_map[s.browser_domain] += s.weight

    results = []
    for domain, secs in sorted(time_map.items(), key=lambda x: -x[1])[:TOP_N]:
        results.append(
            DomainUsage(domain=domain, seconds=round(secs, 1), category="distracting")
        )
    return results
