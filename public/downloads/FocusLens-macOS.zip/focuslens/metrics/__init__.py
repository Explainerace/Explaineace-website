"""focuslens.metrics – public API."""

from focuslens.metrics.categorizer import Categorizer
from focuslens.metrics.engine import MetricsEngine
from focuslens.metrics.models import (
    AppUsage,
    DayMetrics,
    DeepWorkBlock,
    DomainUsage,
    HourMetrics,
    WeekTrend,
)

__all__ = [
    "Categorizer",
    "MetricsEngine",
    "AppUsage",
    "DayMetrics",
    "DeepWorkBlock",
    "DomainUsage",
    "HourMetrics",
    "WeekTrend",
]
