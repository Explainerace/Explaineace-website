"""
focuslens.saas.goals
~~~~~~~~~~~~~~~~~~~~
Productivity goals, streak tracking, and gamification badges for FocusLens SaaS.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date as Date
from typing import List, Optional

from focuslens.db.store import Store
from focuslens.metrics.models import DayMetrics


@dataclass
class ProductivityGoals:
    target_deep_work_m: int = 240    # 4 hours
    max_distraction_m: int = 60      # 1 hour
    target_focus_score: int = 75     # 75/100
    streak_days: int = 3             # current streak in days


@dataclass
class GoalEvaluation:
    deep_work_actual_m: float
    deep_work_target_m: int
    deep_work_pct: float
    distraction_actual_m: float
    distraction_budget_m: int
    distraction_budget_left_m: float
    focus_score_actual: float
    focus_score_target: int
    goals_met: bool
    streak_days: int
    badges: list[str] = field(default_factory=list)


class GoalManager:
    """Manages user goals, evaluates daily progress, and calculates streaks."""

    def __init__(self, store: Store) -> None:
        self.store = store

    def get_goals(self, user_id: int) -> ProductivityGoals:
        with self.store._lock:
            cur = self.store._conn.cursor()
            cur.execute(
                "SELECT target_deep_work_m, max_distraction_m, target_focus_score, streak_days FROM saas_goals WHERE user_id = ?",
                (user_id,),
            )
            row = cur.fetchone()
            if row:
                return ProductivityGoals(
                    target_deep_work_m=row[0],
                    max_distraction_m=row[1],
                    target_focus_score=row[2],
                    streak_days=row[3],
                )
        return ProductivityGoals()

    def update_goals(
        self,
        user_id: int,
        deep_work_m: int,
        max_distract_m: int,
        target_score: int,
    ) -> None:
        with self.store._lock:
            cur = self.store._conn.cursor()
            cur.execute(
                """
                UPDATE saas_goals
                SET target_deep_work_m = ?, max_distraction_m = ?, target_focus_score = ?
                WHERE user_id = ?
                """,
                (deep_work_m, max_distract_m, target_score, user_id),
            )
            self.store._conn.commit()

    def evaluate_day(self, user_id: int, dm: DayMetrics) -> GoalEvaluation:
        goals = self.get_goals(user_id)

        dw_actual = dm.deep_work_minutes
        dw_pct = min(100.0, (dw_actual / goals.target_deep_work_m * 100)) if goals.target_deep_work_m > 0 else 100.0

        distract_actual = dm.distracting_seconds / 60.0
        budget_left = max(0.0, goals.max_distraction_m - distract_actual)

        score_met = dm.focus_score >= goals.target_focus_score
        dw_met = dw_actual >= (goals.target_deep_work_m * 0.75)  # 75%+ achieved
        distract_met = distract_actual <= goals.max_distraction_m

        all_met = score_met and dw_met and distract_met

        badges = []
        if dw_actual >= goals.target_deep_work_m:
            badges.append("🏆 Deep Work Champion")
        if distract_actual <= 30.0 and dm.total_tracked_seconds > 7200:
            badges.append("🛡 Distraction Fortress")
        if dm.focus_score >= 80:
            badges.append("⚡ Laser Focus")
        if dm.break_count >= 3:
            badges.append("🧘 Balanced Pacing")
        if goals.streak_days >= 3:
            badges.append(f"🔥 {goals.streak_days}-Day Streak")

        return GoalEvaluation(
            deep_work_actual_m=dw_actual,
            deep_work_target_m=goals.target_deep_work_m,
            deep_work_pct=dw_pct,
            distraction_actual_m=distract_actual,
            distraction_budget_m=goals.max_distraction_m,
            distraction_budget_left_m=budget_left,
            focus_score_actual=dm.focus_score,
            focus_score_target=goals.target_focus_score,
            goals_met=all_met,
            streak_days=goals.streak_days,
            badges=badges,
        )
