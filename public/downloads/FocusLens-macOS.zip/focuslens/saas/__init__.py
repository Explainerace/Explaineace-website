"""
focuslens.saas
~~~~~~~~~~~~~~
FocusLens Cloud & SaaS core modules:
- Auth: Multi-tenant accounts, password hashing, and API pairing keys
- Goals: Daily deep-work targets, distraction budgets, streaks, and gamification
- Teams: Workplace & team aggregate analytics
"""

from focuslens.saas.auth import AuthManager, SaaSUser
from focuslens.saas.goals import GoalManager, ProductivityGoals, GoalEvaluation
from focuslens.saas.teams import TeamAnalyticsManager, TeamBenchmark

__all__ = [
    "AuthManager",
    "SaaSUser",
    "GoalManager",
    "ProductivityGoals",
    "GoalEvaluation",
    "TeamAnalyticsManager",
    "TeamBenchmark",
]
