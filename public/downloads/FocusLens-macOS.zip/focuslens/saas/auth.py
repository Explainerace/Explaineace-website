"""
focuslens.saas.auth
~~~~~~~~~~~~~~~~~~~
Multi-tenant authentication and API key management for FocusLens SaaS.
Supports password hashing (PBKDF2-SHA256), device pairing tokens, and plan tiers.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import time
from dataclasses import dataclass
from typing import Optional

from focuslens.db.store import Store


@dataclass
class SaaSUser:
    id: int
    email: str
    api_key: str
    plan_tier: str  # "free" | "pro" | "team"
    created_at: float

    @property
    def is_pro_or_higher(self) -> bool:
        return self.plan_tier in ("pro", "team")


class AuthManager:
    """Manages multi-tenant accounts, passwords, and pairing API keys."""

    def __init__(self, store: Store) -> None:
        self.store = store
        self._ensure_saas_tables()

    def _ensure_saas_tables(self) -> None:
        with self.store._lock:
            cur = self.store._conn.cursor()
            cur.execute("""
            CREATE TABLE IF NOT EXISTS saas_users (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                email         TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                salt          TEXT NOT NULL,
                api_key       TEXT UNIQUE NOT NULL,
                plan_tier     TEXT DEFAULT 'pro',
                created_at    REAL NOT NULL
            );
            """)
            cur.execute("""
            CREATE TABLE IF NOT EXISTS saas_devices (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER NOT NULL REFERENCES saas_users(id),
                device_name   TEXT NOT NULL,
                os_version    TEXT,
                last_seen_at  REAL NOT NULL
            );
            """)
            cur.execute("""
            CREATE TABLE IF NOT EXISTS saas_goals (
                user_id             INTEGER PRIMARY KEY REFERENCES saas_users(id),
                target_deep_work_m  INTEGER DEFAULT 240,
                max_distraction_m   INTEGER DEFAULT 60,
                target_focus_score  INTEGER DEFAULT 75,
                streak_days         INTEGER DEFAULT 1
            );
            """)
            self.store._conn.commit()

    @staticmethod
    def _hash_password(password: str, salt: bytes) -> str:
        return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100_000).hex()

    def register(
        self,
        email: str,
        password: str,
        plan_tier: str = "pro",
    ) -> SaaSUser:
        """Register a new user account."""
        email_clean = email.strip().lower()
        salt = secrets.token_bytes(16)
        pwd_hash = self._hash_password(password, salt)
        api_key = f"fl_{secrets.token_hex(16)}"
        now = time.time()

        with self.store._lock:
            cur = self.store._conn.cursor()
            cur.execute(
                """
                INSERT INTO saas_users (email, password_hash, salt, api_key, plan_tier, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (email_clean, pwd_hash, salt.hex(), api_key, plan_tier, now),
            )
            user_id = cur.lastrowid
            # Initialize default goals
            cur.execute(
                """
                INSERT OR IGNORE INTO saas_goals (user_id, target_deep_work_m, max_distraction_m, target_focus_score, streak_days)
                VALUES (?, 240, 60, 75, 1)
                """,
                (user_id,),
            )
            self.store._conn.commit()

        return SaaSUser(
            id=user_id,
            email=email_clean,
            api_key=api_key,
            plan_tier=plan_tier,
            created_at=now,
        )

    def authenticate(self, email: str, password: str) -> Optional[SaaSUser]:
        """Verify user credentials and return the user if valid."""
        email_clean = email.strip().lower()
        with self.store._lock:
            cur = self.store._conn.cursor()
            cur.execute(
                "SELECT id, email, password_hash, salt, api_key, plan_tier, created_at FROM saas_users WHERE email = ?",
                (email_clean,),
            )
            row = cur.fetchone()
            if not row:
                return None

            user_id, u_email, stored_hash, salt_hex, api_key, plan_tier, created_at = row
            salt = bytes.fromhex(salt_hex)
            test_hash = self._hash_password(password, salt)

            if hmac.compare_digest(stored_hash, test_hash):
                return SaaSUser(
                    id=user_id,
                    email=u_email,
                    api_key=api_key,
                    plan_tier=plan_tier,
                    created_at=created_at,
                )
        return None

    def get_by_api_key(self, api_key: str) -> Optional[SaaSUser]:
        """Look up user by their device pairing API key."""
        if not api_key:
            return None
        with self.store._lock:
            cur = self.store._conn.cursor()
            cur.execute(
                "SELECT id, email, api_key, plan_tier, created_at FROM saas_users WHERE api_key = ?",
                (api_key.strip(),),
            )
            row = cur.fetchone()
            if not row:
                return None
            return SaaSUser(
                id=row[0],
                email=row[1],
                api_key=row[2],
                plan_tier=row[3],
                created_at=row[4],
            )

    def get_or_create_default_user(self) -> SaaSUser:
        """Ensure a default user exists for immediate exploration without forced signup."""
        default_email = "demo@focuslens.io"
        with self.store._lock:
            cur = self.store._conn.cursor()
            cur.execute("SELECT id, email, api_key, plan_tier, created_at FROM saas_users WHERE email = ?", (default_email,))
            row = cur.fetchone()
            if row:
                return SaaSUser(id=row[0], email=row[1], api_key=row[2], plan_tier=row[3], created_at=row[4])

        return self.register(default_email, "FocusLensDemo2026!", plan_tier="pro")

    def register_device_seen(self, user_id: int, device_name: str, os_version: str = "macOS") -> None:
        """Update last seen timestamp for a synced MacBook device."""
        now = time.time()
        with self.store._lock:
            cur = self.store._conn.cursor()
            cur.execute(
                """
                INSERT INTO saas_devices (user_id, device_name, os_version, last_seen_at)
                VALUES (?, ?, ?, ?)
                """,
                (user_id, device_name, os_version, now),
            )
            self.store._conn.commit()
