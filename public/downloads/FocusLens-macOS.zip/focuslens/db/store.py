"""
focuslens.db.store
~~~~~~~~~~~~~~~~~~
Thread-safe SQLite wrapper for FocusLens.

All writes are serialised through a single sqlite3 connection opened with
check_same_thread=False and a threading.Lock guard, so the sampler thread
and the system-stats thread can both insert without conflict.
"""

from __future__ import annotations

import logging
import sqlite3
import threading
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_SCHEMA_FILE = Path(__file__).parent / "schema.sql"


class Store:
    """Manages the FocusLens SQLite database."""

    def __init__(self, db_path: Path) -> None:
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._path = db_path
        self._lock = threading.Lock()
        self._conn: Optional[sqlite3.Connection] = None
        self._connect()

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def _connect(self) -> None:
        self._conn = sqlite3.connect(
            str(self._path),
            check_same_thread=False,
            isolation_level=None,  # autocommit; we manage transactions manually
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._apply_schema()
        logger.info("Database opened: %s", self._path)

    def _apply_schema(self) -> None:
        schema_sql = _SCHEMA_FILE.read_text()
        with self._lock:
            self._conn.executescript(schema_sql)

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None
            logger.info("Database closed")

    # ------------------------------------------------------------------
    # Sessions
    # ------------------------------------------------------------------

    def start_session(self, started_at: float, note: str = "") -> int:
        """Insert a new session row and return its id."""
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO sessions (started_at, note) VALUES (?, ?)",
                (started_at, note),
            )
            self._conn.commit()
            session_id = cur.lastrowid
        logger.info("Session %d started", session_id)
        return session_id

    def stop_session(self, session_id: int, stopped_at: float) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE sessions SET stopped_at=? WHERE id=?",
                (stopped_at, session_id),
            )
            self._conn.commit()
        logger.info("Session %d stopped", session_id)

    # ------------------------------------------------------------------
    # Samples
    # ------------------------------------------------------------------

    def insert_sample(
        self,
        session_id: int,
        ts: float,
        active_app: Optional[str],
        window_title: Optional[str],
        browser_domain: Optional[str],
        idle_seconds: float,
        screen_locked: bool,
        kb_events: int,
        mouse_events: int,
    ) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO samples
                   (session_id, ts, active_app, window_title, browser_domain,
                    idle_seconds, screen_locked, kb_events, mouse_events)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (
                    session_id,
                    ts,
                    active_app,
                    window_title,
                    browser_domain,
                    idle_seconds,
                    1 if screen_locked else 0,
                    kb_events,
                    mouse_events,
                ),
            )
            self._conn.commit()

    # ------------------------------------------------------------------
    # System stats
    # ------------------------------------------------------------------

    def insert_system_stat(
        self,
        session_id: int,
        ts: float,
        cpu_pct: Optional[float],
        ram_pct: Optional[float],
        battery_pct: Optional[float],
        thermal_state: Optional[str],
    ) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO system_stats
                   (session_id, ts, cpu_pct, ram_pct, battery_pct, thermal_state)
                   VALUES (?,?,?,?,?,?)""",
                (session_id, ts, cpu_pct, ram_pct, battery_pct, thermal_state),
            )
            self._conn.commit()

    # ------------------------------------------------------------------
    # Queries (for metrics engine and dashboard)
    # ------------------------------------------------------------------

    def fetch_samples_for_day(self, date_str: str) -> list[tuple]:
        """
        Return all sample rows for a calendar day (YYYY-MM-DD, local time).

        Columns returned (in order):
          ts, active_app, window_title, browser_domain,
          idle_seconds, screen_locked, kb_events, mouse_events
        """
        from datetime import datetime, timedelta
        start = datetime.strptime(date_str, "%Y-%m-%d")
        end = start + timedelta(days=1)
        ts_start = start.timestamp()
        ts_end = end.timestamp()
        with self._lock:
            cur = self._conn.execute(
                """SELECT ts, active_app, window_title, browser_domain,
                          idle_seconds, screen_locked, kb_events, mouse_events
                   FROM samples
                   WHERE ts >= ? AND ts < ?
                   ORDER BY ts ASC""",
                (ts_start, ts_end),
            )
            return cur.fetchall()

    def fetch_system_stats_for_day(self, date_str: str) -> list[tuple]:
        """
        Return system_stats rows for a calendar day (YYYY-MM-DD, local time).

        Columns: ts, cpu_pct, ram_pct, battery_pct, thermal_state
        """
        from datetime import datetime, timedelta
        start = datetime.strptime(date_str, "%Y-%m-%d")
        end = start + timedelta(days=1)
        with self._lock:
            cur = self._conn.execute(
                """SELECT ts, cpu_pct, ram_pct, battery_pct, thermal_state
                   FROM system_stats
                   WHERE ts >= ? AND ts < ?
                   ORDER BY ts ASC""",
                (start.timestamp(), end.timestamp()),
            )
            return cur.fetchall()

    def tracked_dates(self, limit: int = 30) -> list[str]:
        """
        Return a list of distinct calendar dates (YYYY-MM-DD, local time)
        that have at least one sample, most-recent first.
        """
        with self._lock:
            cur = self._conn.execute(
                """SELECT DISTINCT date(ts, 'unixepoch', 'localtime') AS d
                   FROM samples
                   ORDER BY d DESC
                   LIMIT ?""",
                (limit,),
            )
            return [row[0] for row in cur.fetchall()]

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def delete_all_data(self) -> None:
        """Irreversibly delete every row from every table."""
        with self._lock:
            self._conn.executescript(
                """
                DELETE FROM system_stats;
                DELETE FROM samples;
                DELETE FROM sessions;
                """
            )
            self._conn.execute("VACUUM")
            self._conn.commit()
        logger.warning("All FocusLens data has been deleted")

    def row_counts(self) -> dict:
        """Return row counts for each table (useful for diagnostics)."""
        with self._lock:
            result = {}
            for table in ("sessions", "samples", "system_stats"):
                cur = self._conn.execute(f"SELECT COUNT(*) FROM {table}")
                result[table] = cur.fetchone()[0]
        return result
