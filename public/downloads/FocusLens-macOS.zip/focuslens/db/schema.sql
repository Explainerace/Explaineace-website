-- FocusLens SQLite schema
-- Version 1  (Phase 1)

CREATE TABLE IF NOT EXISTS sessions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at  REAL    NOT NULL,   -- Unix timestamp
    stopped_at  REAL,               -- NULL while running
    note        TEXT                -- optional label e.g. "Work session"
);

-- One row every ~3 seconds while tracking
CREATE TABLE IF NOT EXISTS samples (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id     INTEGER NOT NULL REFERENCES sessions(id),
    ts             REAL    NOT NULL,        -- Unix timestamp
    active_app     TEXT,                    -- e.g. "Safari"
    window_title   TEXT,                    -- "<blocked>" if on blocklist
    browser_domain TEXT,                    -- e.g. "github.com" or NULL
    idle_seconds   REAL    DEFAULT 0,       -- seconds since last HID event
    screen_locked  INTEGER DEFAULT 0,       -- 0=unlocked 1=locked
    kb_events      INTEGER DEFAULT 0,       -- keyboard event count delta
    mouse_events   INTEGER DEFAULT 0        -- mouse event count delta
);

-- One row every ~30 seconds while tracking
CREATE TABLE IF NOT EXISTS system_stats (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id    INTEGER NOT NULL REFERENCES sessions(id),
    ts            REAL    NOT NULL,
    cpu_pct       REAL,
    ram_pct       REAL,
    battery_pct   REAL,
    thermal_state TEXT                      -- "nominal","fair","serious","critical"
);

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_samples_session_ts    ON samples(session_id, ts);
CREATE INDEX IF NOT EXISTS idx_system_stats_session  ON system_stats(session_id, ts);
CREATE INDEX IF NOT EXISTS idx_samples_ts            ON samples(ts);
