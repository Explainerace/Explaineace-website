"""
focuslens.sync.server
~~~~~~~~~~~~~~~~~~~~~
Lightweight HTTP sync server for receiving telemetry from MacBook clients.
Runs in the cloud (Railway / VPS) and saves incoming batches into the database.
"""

from __future__ import annotations

import json
import logging
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional

from focuslens.db.store import Store

logger = logging.getLogger(__name__)


class SyncRequestHandler(BaseHTTPRequestHandler):
    store: Store
    api_key: Optional[str] = None

    def _send_json(self, status: int, data: dict) -> None:
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def do_GET(self) -> None:
        if self.path in ("/api/status", "/api/health", "/health"):
            counts = self.store.row_counts()
            self._send_json(200, {
                "status": "online",
                "service": "FocusLens Cloud Sync",
                "total_samples": counts.get("samples", 0),
                "total_sessions": counts.get("sessions", 0),
            })
        else:
            self._send_json(404, {"error": "Not found"})

    def do_POST(self) -> None:
        if self.path == "/api/sync":
            content_len = int(self.headers.get("Content-Length", 0))
            if content_len == 0:
                self._send_json(400, {"error": "Empty payload"})
                return

            try:
                body = self.rfile.read(content_len)
                payload = json.loads(body.decode("utf-8"))
            except Exception as err:
                self._send_json(400, {"error": f"Invalid JSON: {err}"})
                return

            # Check optional API Key
            if self.api_key:
                client_key = payload.get("api_key") or self.headers.get("Authorization", "").replace("Bearer ", "")
                if client_key != self.api_key:
                    self._send_json(401, {"error": "Unauthorized: invalid API key"})
                    return

            samples = payload.get("samples", [])
            stats = payload.get("system_stats", [])
            sessions = payload.get("sessions", [])

            # Insert sessions if provided
            for sess in sessions:
                try:
                    self.store.start_session(sess["started_at"], note=sess.get("note", "Synced Session"))
                except Exception:
                    pass

            # Insert samples
            inserted_samples = 0
            for s in samples:
                try:
                    self.store.insert_sample(
                        session_id=s.get("session_id", 1),
                        ts=s["ts"],
                        active_app=s.get("active_app"),
                        window_title=s.get("window_title"),
                        browser_domain=s.get("browser_domain"),
                        idle_seconds=s.get("idle_seconds", 0.0),
                        screen_locked=s.get("screen_locked", False),
                        kb_events=s.get("kb_events", 0),
                        mouse_events=s.get("mouse_events", 0),
                    )
                    inserted_samples += 1
                except Exception as err:
                    logger.debug("Failed to insert sample: %s", err)

            # Insert system stats
            inserted_stats = 0
            for st in stats:
                try:
                    self.store.insert_system_stat(
                        session_id=st.get("session_id", 1),
                        ts=st["ts"],
                        cpu_pct=st.get("cpu_pct"),
                        ram_pct=st.get("ram_pct"),
                        battery_pct=st.get("battery_pct"),
                        thermal_state=st.get("thermal_state"),
                    )
                    inserted_stats += 1
                except Exception:
                    pass

            self._send_json(200, {
                "status": "success",
                "synced_samples": inserted_samples,
                "synced_stats": inserted_stats,
            })
        else:
            self._send_json(404, {"error": "Not found"})


def run_sync_server(store: Store, port: int = 8000, api_key: Optional[str] = None) -> None:
    handler = type("ConfiguredHandler", (SyncRequestHandler,), {
        "store": store,
        "api_key": api_key,
    })
    server = HTTPServer(("0.0.0.0", port), handler)
    logger.info("Sync server listening on 0.0.0.0:%d", port)
    server.serve_forever()
