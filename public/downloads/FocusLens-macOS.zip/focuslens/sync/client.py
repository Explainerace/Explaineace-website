"""
focuslens.sync.client
~~~~~~~~~~~~~~~~~~~~~
Background sync agent for MacBook clients.
Streams newly collected local telemetry to the FocusLens cloud backend (Railway).
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
import urllib.request
import urllib.error
from pathlib import Path
from typing import Optional

from focuslens.db.store import Store

logger = logging.getLogger(__name__)

_APP_SUPPORT = Path.home() / "Library" / "Application Support" / "FocusLens"
_WATERMARK_FILE = _APP_SUPPORT / "sync_watermark.json"


class CloudSyncClient:
    """Uploads local telemetry batches to a remote FocusLens server."""

    def __init__(
        self,
        store: Store,
        sync_url: Optional[str] = None,
        api_key: Optional[str] = None,
        interval_seconds: float = 30.0,
    ) -> None:
        self.store = store
        self.sync_url = (sync_url or os.environ.get("FOCUSLENS_SYNC_URL", "")).rstrip("/")
        self.api_key = api_key or os.environ.get("FOCUSLENS_API_KEY", "")
        self.interval = interval_seconds
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    @property
    def is_configured(self) -> bool:
        return bool(self.sync_url)

    def _get_last_watermark(self) -> float:
        if not _WATERMARK_FILE.exists():
            return 0.0
        try:
            data = json.loads(_WATERMARK_FILE.read_text())
            return float(data.get("last_synced_ts", 0.0))
        except Exception:
            return 0.0

    def _save_watermark(self, ts: float) -> None:
        try:
            _WATERMARK_FILE.parent.mkdir(parents=True, exist_ok=True)
            _WATERMARK_FILE.write_text(json.dumps({"last_synced_ts": ts, "updated_at": time.time()}))
        except Exception as err:
            logger.debug("Failed to write sync watermark: %s", err)

    def sync_once(self) -> tuple[bool, int]:
        """Perform a single sync cycle. Returns (success, count_synced)."""
        if not self.is_configured:
            return False, 0

        last_ts = self._get_last_watermark()
        # Query local store for samples newer than watermark
        with self.store._lock:
            cur = self.store._conn.cursor()
            cur.execute(
                """
                SELECT id, session_id, ts, active_app, window_title, browser_domain,
                       idle_seconds, screen_locked, kb_events, mouse_events
                FROM samples
                WHERE ts > ?
                ORDER BY ts ASC
                LIMIT 500
                """,
                (last_ts,),
            )
            rows = cur.fetchall()

            cur.execute(
                """
                SELECT id, session_id, ts, cpu_pct, ram_pct, battery_pct, thermal_state
                FROM system_stats
                WHERE ts > ?
                ORDER BY ts ASC
                LIMIT 500
                """,
                (last_ts,),
            )
            stat_rows = cur.fetchall()

        if not rows and not stat_rows:
            return True, 0

        samples_payload = [
            {
                "session_id": r[1],
                "ts": r[2],
                "active_app": r[3],
                "window_title": r[4],
                "browser_domain": r[5],
                "idle_seconds": r[6],
                "screen_locked": bool(r[7]),
                "kb_events": r[8],
                "mouse_events": r[9],
            }
            for r in rows
        ]

        stats_payload = [
            {
                "session_id": r[1],
                "ts": r[2],
                "cpu_pct": r[3],
                "ram_pct": r[4],
                "battery_pct": r[5],
                "thermal_state": r[6],
            }
            for r in stat_rows
        ]

        payload = {
            "api_key": self.api_key,
            "samples": samples_payload,
            "system_stats": stats_payload,
        }

        endpoint = f"{self.sync_url}/api/sync"
        req = urllib.request.Request(
            endpoint,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=10.0) as resp:
                if resp.status == 200:
                    max_ts = max(
                        [r[2] for r in rows] + [r[2] for r in stat_rows]
                    )
                    self._save_watermark(max_ts)
                    logger.info("Successfully synced %d samples to %s", len(rows), self.sync_url)
                    return True, len(rows)
                return False, 0
        except urllib.error.URLError as err:
            logger.debug("Cloud sync unreachable: %s", err)
            return False, 0
        except Exception as err:
            logger.debug("Sync failed: %s", err)
            return False, 0

    def start(self) -> None:
        """Start the background sync loop."""
        if not self.is_configured:
            logger.info("Cloud sync disabled (no FOCUSLENS_SYNC_URL configured)")
            return

        def _loop():
            logger.info("Cloud sync started -> %s (every %ds)", self.sync_url, self.interval)
            while not self._stop_event.is_set():
                try:
                    self.sync_once()
                except Exception as err:
                    logger.debug("Sync loop exception: %s", err)
                self._stop_event.wait(self.interval)

        self._thread = threading.Thread(target=_loop, name="fl-cloud-sync", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop the background sync loop."""
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
